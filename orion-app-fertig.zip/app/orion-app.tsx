"use client";
/* eslint-disable react-hooks/set-state-in-effect, @next/next/no-img-element */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MODE_INSTRUCTIONS, ORION_MASTER_PROMPT } from "../lib/orion-prompt";

type Role = "user" | "assistant";
type View = "chat" | "missions" | "vision" | "studio" | "tools" | "memory";
type AIState = "ready" | "thinking" | "speaking" | "offline" | "error";
type PuterModule = typeof import("@heyputer/puter.js");
type VoiceEngine = "neural" | "device";
type AssistantGender = "female" | "male" | "neutral";
type TimerUnit = "seconds" | "minutes" | "hours";
type ConnectionMode = "account" | "api";
type ApiProfile = "supersaver" | "balanced" | "maximum";
type StabilityState = "optimal" | "checking" | "warning";
type StreamChatMessage = { id: string; user: string; text: string; at: string; reply?: string; answered?: boolean; drafting?: boolean };

type OrionTimer = {
  id: string;
  label: string;
  endsAt: number;
  durationMs: number;
  completed: boolean;
};

type DeviceFacts = {
  model: string;
  platform: string;
  browser: string;
  screen: string;
  memory: string;
  cpu: string;
  battery: string;
  network: string;
  temperature: string;
};

type OrionDesktopBridge = {
  platform?: string;
  desktop?: boolean;
  version?: string;
  openExternal?: (url: string) => Promise<boolean>;
  openApp?: (name: string) => Promise<boolean>;
  typeText?: (text: string) => Promise<boolean>;
  copyText?: (text: string) => Promise<boolean>;
};

type Message = {
  id: string;
  role: Role;
  text: string;
  createdAt: string;
  image?: string;
};

type MemoryFact = {
  id: string;
  key: string;
  value: string;
  category?: "identity" | "preference" | "project" | "relationship" | "goal" | "note";
  source?: "explicit" | "learned";
  updatedAt?: string;
};

type CustomCommand = {
  id: string;
  phrase: string;
  instruction: string;
};

type Mission = {
  id: string;
  task: string;
  status: "queued" | "running" | "done" | "error";
  result?: string;
  createdAt: string;
};

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type RecognitionEventLike = {
  results: ArrayLike<{ 0: { transcript: string } }>;
};

type RecognitionErrorEventLike = {
  error?: string;
};

type RecognitionLike = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  onresult: ((event: RecognitionEventLike) => void) | null;
  onend: (() => void) | null;
  onerror: ((event: RecognitionErrorEventLike) => void) | null;
  start: () => void;
  stop: () => void;
};

type RecognitionConstructor = new () => RecognitionLike;

type CloudBrain = {
  version: 1;
  updatedAt: string;
  memory: MemoryFact[];
  commands: CustomCommand[];
  messages: Message[];
};

type OrionAndroidBridge = {
  startStandby?: (config: string) => void;
  stopStandby?: () => void;
  updateConfig?: (config: string) => void;
  startSpeechRecognition?: (language: string) => boolean;
  stopSpeechRecognition?: () => void;
  captureScreen?: () => boolean;
  startGamingCapture?: (intervalSeconds: number) => boolean;
  stopGamingCapture?: () => void;
  insertText?: (text: string) => boolean;
  openAccessibilitySettings?: () => void;
  openExternal?: (url: string) => boolean;
  openApp?: (name: string) => boolean;
  globalAction?: (action: string) => boolean;
  clickSafeAction?: (action: string) => boolean;
};

const MODELS = {
  fast: { id: "gpt-5.6-luna", label: "Reflex", note: "Ultra-schnell" },
  balanced: { id: "gpt-5.6-terra", label: "Neural", note: "Adaptiv" },
  maximum: { id: "gpt-5.6-sol", label: "Apex", note: "Maximal" },
} as const;

const API_PROFILES: Record<ApiProfile, { label: string; note: string; maxTokens: number; history: number; memory: number }> = {
  supersaver: { label: "SuperSparsam", note: "kleines Modell · kurze Antworten · minimale Zusatzaufrufe", maxTokens: 520, history: 6, memory: 18 },
  balanced: { label: "Smart Balance", note: "gute Qualität bei kontrollierter Nutzung", maxTokens: 1200, history: 14, memory: 60 },
  maximum: { label: "Maximum", note: "stärkstes erkanntes Modell · tiefere Antworten", maxTokens: 2400, history: 24, memory: 120 },
};

const RELATIONSHIP_LEVELS = [
  { label: "Professionell", note: "ruhig und respektvoll" },
  { label: "Vertraut", note: "locker, ohne Kosenamen" },
  { label: "Warm", note: "persönlich und aufmerksam" },
  { label: "Sehr nah", note: "herzlich wie beste Freundschaft" },
  { label: "Liebevoll", note: "gelegentlich liebevoll, nie übertrieben" },
] as const;

const MODES = [
  { id: "assistant", label: "Assistent" },
  { id: "business", label: "Business" },
  { id: "developer", label: "Entwickler" },
  { id: "gaming", label: "Gaming" },
  { id: "creative", label: "Kreativ" },
  { id: "focus", label: "Fokus" },
  { id: "overdrive", label: "Overdrive" },
  { id: "listener", label: "Zuhörer" },
  { id: "mentor", label: "Mentor" },
  { id: "coach", label: "Coach" },
  { id: "strategist", label: "Stratege" },
  { id: "friend", label: "Freund/in" },
  { id: "scientist", label: "Wissenschaft" },
  { id: "minimal", label: "Minimal" },
] as const;

const LANGUAGES = [
  { id: "de-DE", label: "Deutsch", prompt: "Deutsch", stt: "de" },
  { id: "en-US", label: "English", prompt: "Englisch", stt: "en" },
  { id: "tr-TR", label: "Türkçe", prompt: "Türkisch", stt: "tr" },
  { id: "es-ES", label: "Español", prompt: "Spanisch", stt: "es" },
  { id: "fr-FR", label: "Français", prompt: "Französisch", stt: "fr" },
  { id: "it-IT", label: "Italiano", prompt: "Italienisch", stt: "it" },
  { id: "pl-PL", label: "Polski", prompt: "Polnisch", stt: "pl" },
  { id: "nl-NL", label: "Nederlands", prompt: "Niederländisch", stt: "nl" },
  { id: "pt-BR", label: "Português", prompt: "Portugiesisch", stt: "pt" },
  { id: "ar-SA", label: "العربية", prompt: "Arabisch", stt: "ar" },
  { id: "ru-RU", label: "Русский", prompt: "Russisch", stt: "ru" },
  { id: "ja-JP", label: "日本語", prompt: "Japanisch", stt: "ja" },
  { id: "ko-KR", label: "한국어", prompt: "Koreanisch", stt: "ko" },
  { id: "hi-IN", label: "हिन्दी", prompt: "Hindi", stt: "hi" },
] as const;

const VOICE_PROFILES = [
  { id: "Kore", label: "Kore Professional", note: "Weiblich · klar & hochwertig", gender: "female", instructions: "Sprich professionell, warm, klar und natürlich. Vermeide eine kratzige, künstliche oder übertriebene Radiostimme." },
  { id: "Aoede", label: "Aoede Warm", note: "Weiblich · empathisch", gender: "female", instructions: "Sprich warm, menschlich und empathisch mit natürlichem Tempo und feiner Betonung." },
  { id: "Leda", label: "Leda Modern", note: "Weiblich · jung & ruhig", gender: "female", instructions: "Sprich modern, ruhig, freundlich und selbstbewusst, niemals schrill." },
  { id: "Zephyr", label: "Zephyr Bright", note: "Weiblich · hell & direkt", gender: "female", instructions: "Sprich klar, aufmerksam und lebendig, aber nicht hektisch." },
  { id: "Charon", label: "Charon JARVIS", note: "Männlich · tief & souverän", gender: "male", instructions: "Sprich tief, souverän, präzise und elegant wie ein futuristischer persönlicher Assistent, aber natürlich und nicht theatralisch." },
  { id: "Orus", label: "Orus Executive", note: "Männlich · professionell", gender: "male", instructions: "Sprich professionell, kontrolliert und vertrauenswürdig mit ruhigem Tempo." },
  { id: "Puck", label: "Puck Dynamic", note: "Männlich · dynamisch", gender: "male", instructions: "Sprich dynamisch, freundlich und direkt, ohne künstliche Übertreibung." },
  { id: "Fenrir", label: "Fenrir Markant", note: "Männlich · kräftig", gender: "male", instructions: "Sprich markant, ruhig und selbstbewusst; nicht aggressiv und nicht wie ein Werbesprecher." },
] as const;

const RADIO_STATIONS = [
  { id: "phonk", label: "PHONK", note: "Drift · Bass · Workout", url: "https://radiorecord.hostingradio.ru/phonk96.aacp", metaId: null },
  { id: "groove", label: "Focus", note: "Ambient & Downtempo", url: "https://ice5.somafm.com/groovesalad-128-mp3", metaId: "groovesalad" },
  { id: "fluid", label: "Fluid", note: "Instrumental Hip-Hop · Trap", url: "https://ice5.somafm.com/fluid-128-mp3", metaId: "fluid" },
  { id: "vapor", label: "Vaporwaves", note: "Vaporwave · Future Retro", url: "https://ice5.somafm.com/vaporwaves-128-mp3", metaId: "vaporwaves" },
  { id: "metal", label: "Metal Detector", note: "Metal · Heavy", url: "https://ice5.somafm.com/metal-128-mp3", metaId: "metal" },
  { id: "drone", label: "Drone Zone", note: "Deep Ambient", url: "https://ice5.somafm.com/dronezone-128-mp3", metaId: "dronezone" },
  { id: "secret", label: "Secret Agent", note: "Spy Lounge · Jazz", url: "https://ice5.somafm.com/secretagent-128-mp3", metaId: "secretagent" },
  { id: "soul", label: "7 Inch Soul", note: "Classic Soul", url: "https://ice5.somafm.com/7soul-128-mp3", metaId: "7soul" },
  { id: "lush", label: "Lush", note: "Mellow Vocals", url: "https://ice5.somafm.com/lush-128-mp3", metaId: "lush" },
  { id: "classic", label: "Classic", note: "Groove Salad Classic", url: "https://ice5.somafm.com/gsclassic-128-mp3", metaId: "gsclassic" },
  { id: "bossa", label: "Bossa", note: "Chill Bossa", url: "https://ice5.somafm.com/bossa-128-mp3", metaId: "bossa" },
] as const;

const STORAGE = {
  messages: "orion.messages.v1",
  memory: "orion.memory.v1",
  commands: "orion.commands.v1",
  missions: "orion.missions.v1",
  settings: "orion.settings.v1",
  onboarding: "orion.onboarding.v2",
  timers: "orion.timers.v1",
  streamChat: "orion.stream-chat.v1",
};

const UI_TEXT = {
  "de-DE": { online: "SYSTEM ONLINE", offline: "OFFLINE-KERN", processing: "VERARBEITUNG", speaking: "SPRACHAUSGABE", listening: "HÖRT ZU", live: "LIVE-MODUS", signIn: "Anmelden", install: "Installieren", assistant: "Assistent", missions: "Missionen", vision: "Vision", studio: "Studio", tools: "Werkzeuge", memory: "Gedächtnis", ready: "Bereit", startLive: "Live-Gespräch starten", setup: "Setup", settings: "Einstellungen", language: "Gesprächssprache", voice: "Stimme", testVoice: "Stimme testen", personality: "Persönlichkeit", send: "Senden" },
  "en-US": { online: "SYSTEM ONLINE", offline: "OFFLINE CORE", processing: "PROCESSING", speaking: "SPEAKING", listening: "LISTENING", live: "LIVE MODE", signIn: "Sign in", install: "Install", assistant: "Assistant", missions: "Missions", vision: "Vision", studio: "Studio", tools: "Tools", memory: "Memory", ready: "Ready", startLive: "Start live conversation", setup: "Setup", settings: "Settings", language: "Conversation language", voice: "Voice", testVoice: "Test voice", personality: "Personality", send: "Send" },
  "tr-TR": { online: "SİSTEM ÇEVRİMİÇİ", offline: "ÇEVRİMDIŞI ÇEKİRDEK", processing: "İŞLENİYOR", speaking: "KONUŞUYOR", listening: "DİNLİYOR", live: "CANLI MOD", signIn: "Giriş yap", install: "Yükle", assistant: "Asistan", missions: "Görevler", vision: "Görüş", studio: "Stüdyo", tools: "Araçlar", memory: "Hafıza", ready: "Hazır", startLive: "Canlı konuşmayı başlat", setup: "Ayar", settings: "Ayarlar", language: "Konuşma dili", voice: "Ses", testVoice: "Sesi dene", personality: "Kişilik", send: "Gönder" },
  "es-ES": { online: "SISTEMA EN LÍNEA", offline: "NÚCLEO SIN CONEXIÓN", processing: "PROCESANDO", speaking: "HABLANDO", listening: "ESCUCHANDO", live: "MODO EN VIVO", signIn: "Iniciar sesión", install: "Instalar", assistant: "Asistente", missions: "Misiones", vision: "Visión", studio: "Estudio", tools: "Herramientas", memory: "Memoria", ready: "Listo", startLive: "Iniciar conversación", setup: "Ajustes", settings: "Configuración", language: "Idioma", voice: "Voz", testVoice: "Probar voz", personality: "Personalidad", send: "Enviar" },
  "fr-FR": { online: "SYSTÈME EN LIGNE", offline: "NOYAU HORS LIGNE", processing: "TRAITEMENT", speaking: "PARLE", listening: "ÉCOUTE", live: "MODE DIRECT", signIn: "Se connecter", install: "Installer", assistant: "Assistant", missions: "Missions", vision: "Vision", studio: "Studio", tools: "Outils", memory: "Mémoire", ready: "Prêt", startLive: "Démarrer la conversation", setup: "Réglages", settings: "Paramètres", language: "Langue", voice: "Voix", testVoice: "Tester la voix", personality: "Personnalité", send: "Envoyer" },
  "it-IT": { online: "SISTEMA ONLINE", offline: "NUCLEO OFFLINE", processing: "ELABORAZIONE", speaking: "PARLA", listening: "ASCOLTA", live: "MODALITÀ LIVE", signIn: "Accedi", install: "Installa", assistant: "Assistente", missions: "Missioni", vision: "Visione", studio: "Studio", tools: "Strumenti", memory: "Memoria", ready: "Pronto", startLive: "Avvia conversazione", setup: "Imposta", settings: "Impostazioni", language: "Lingua", voice: "Voce", testVoice: "Prova voce", personality: "Personalità", send: "Invia" },
  "pl-PL": { online: "SYSTEM ONLINE", offline: "RDZEŃ OFFLINE", processing: "PRZETWARZANIE", speaking: "MÓWI", listening: "SŁUCHA", live: "TRYB LIVE", signIn: "Zaloguj", install: "Zainstaluj", assistant: "Asystent", missions: "Misje", vision: "Wizja", studio: "Studio", tools: "Narzędzia", memory: "Pamięć", ready: "Gotowy", startLive: "Rozpocznij rozmowę", setup: "Ustawienia", settings: "Ustawienia", language: "Język", voice: "Głos", testVoice: "Test głosu", personality: "Osobowość", send: "Wyślij" },
  "nl-NL": { online: "SYSTEEM ONLINE", offline: "OFFLINE KERN", processing: "VERWERKEN", speaking: "SPREEKT", listening: "LUISTERT", live: "LIVE MODUS", signIn: "Aanmelden", install: "Installeren", assistant: "Assistent", missions: "Missies", vision: "Visie", studio: "Studio", tools: "Tools", memory: "Geheugen", ready: "Klaar", startLive: "Livegesprek starten", setup: "Instellen", settings: "Instellingen", language: "Taal", voice: "Stem", testVoice: "Stem testen", personality: "Persoonlijkheid", send: "Verzenden" },
  "pt-BR": { online: "SISTEMA ONLINE", offline: "NÚCLEO OFFLINE", processing: "PROCESSANDO", speaking: "FALANDO", listening: "OUVINDO", live: "MODO AO VIVO", signIn: "Entrar", install: "Instalar", assistant: "Assistente", missions: "Missões", vision: "Visão", studio: "Estúdio", tools: "Ferramentas", memory: "Memória", ready: "Pronto", startLive: "Iniciar conversa", setup: "Ajustes", settings: "Configurações", language: "Idioma", voice: "Voz", testVoice: "Testar voz", personality: "Personalidade", send: "Enviar" },
  "ar-SA": { online: "النظام متصل", offline: "النواة دون اتصال", processing: "جارٍ المعالجة", speaking: "يتحدث", listening: "يستمع", live: "الوضع المباشر", signIn: "تسجيل الدخول", install: "تثبيت", assistant: "المساعد", missions: "المهام", vision: "الرؤية", studio: "الاستوديو", tools: "الأدوات", memory: "الذاكرة", ready: "جاهز", startLive: "بدء محادثة مباشرة", setup: "الإعداد", settings: "الإعدادات", language: "اللغة", voice: "الصوت", testVoice: "اختبار الصوت", personality: "الشخصية", send: "إرسال" },
  "ru-RU": { online: "СИСТЕМА ОНЛАЙН", offline: "ОФЛАЙН-ЯДРО", processing: "ОБРАБОТКА", speaking: "ГОВОРИТ", listening: "СЛУШАЕТ", live: "ЖИВОЙ РЕЖИМ", signIn: "Войти", install: "Установить", assistant: "Ассистент", missions: "Миссии", vision: "Зрение", studio: "Студия", tools: "Инструменты", memory: "Память", ready: "Готов", startLive: "Начать разговор", setup: "Настройка", settings: "Настройки", language: "Язык", voice: "Голос", testVoice: "Проверить голос", personality: "Личность", send: "Отправить" },
  "ja-JP": { online: "システムオンライン", offline: "オフラインコア", processing: "処理中", speaking: "発話中", listening: "聞いています", live: "ライブモード", signIn: "ログイン", install: "インストール", assistant: "アシスタント", missions: "ミッション", vision: "ビジョン", studio: "スタジオ", tools: "ツール", memory: "メモリ", ready: "準備完了", startLive: "会話を開始", setup: "設定", settings: "設定", language: "言語", voice: "音声", testVoice: "音声テスト", personality: "性格", send: "送信" },
  "ko-KR": { online: "시스템 온라인", offline: "오프라인 코어", processing: "처리 중", speaking: "말하는 중", listening: "듣는 중", live: "라이브 모드", signIn: "로그인", install: "설치", assistant: "어시스턴트", missions: "미션", vision: "비전", studio: "스튜디오", tools: "도구", memory: "메모리", ready: "준비 완료", startLive: "대화 시작", setup: "설정", settings: "설정", language: "언어", voice: "음성", testVoice: "음성 테스트", personality: "성격", send: "보내기" },
  "hi-IN": { online: "सिस्टम ऑनलाइन", offline: "ऑफ़लाइन कोर", processing: "प्रोसेसिंग", speaking: "बोल रहा है", listening: "सुन रहा है", live: "लाइव मोड", signIn: "साइन इन", install: "इंस्टॉल", assistant: "सहायक", missions: "मिशन", vision: "विज़न", studio: "स्टूडियो", tools: "टूल्स", memory: "मेमोरी", ready: "तैयार", startLive: "लाइव वार्ता शुरू करें", setup: "सेटअप", settings: "सेटिंग्स", language: "भाषा", voice: "आवाज़", testVoice: "आवाज़ जाँचें", personality: "व्यक्तित्व", send: "भेजें" },
} as const;

const VOICE_PREVIEW: Record<string, string> = {
  "de-DE": "Hallo, ich bin ORION. So klinge ich. Ich bin bereit, dich zu unterstützen.",
  "en-US": "Hello, I am ORION. This is how I sound. I am ready to assist you.",
  "tr-TR": "Merhaba, ben ORION. Sesim böyle. Sana yardımcı olmaya hazırım.",
  "es-ES": "Hola, soy ORION. Así es como sueno. Estoy listo para ayudarte.",
  "fr-FR": "Bonjour, je suis ORION. Voici ma voix. Je suis prêt à vous aider.",
  "it-IT": "Ciao, sono ORION. Questa è la mia voce. Sono pronto ad aiutarti.",
  "pl-PL": "Cześć, jestem ORION. Tak brzmi mój głos. Jestem gotowy ci pomóc.",
  "nl-NL": "Hallo, ik ben ORION. Zo klink ik. Ik sta klaar om je te helpen.",
  "pt-BR": "Olá, eu sou ORION. Esta é a minha voz. Estou pronto para ajudar.",
  "ar-SA": "مرحبًا، أنا أوريون. هذا هو صوتي. أنا مستعد لمساعدتك.",
  "ru-RU": "Здравствуйте, я ORION. Так звучит мой голос. Я готов помочь вам.",
  "ja-JP": "こんにちは、ORIONです。これが私の声です。いつでもお手伝いできます。",
  "ko-KR": "안녕하세요, ORION입니다. 제 목소리는 이렇게 들립니다. 도와드릴 준비가 되었습니다.",
  "hi-IN": "नमस्ते, मैं ORION हूँ। मेरी आवाज़ ऐसी है। मैं आपकी मदद के लिए तैयार हूँ।",
};

function uid(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function timeNow() {
  return new Intl.DateTimeFormat("de-DE", {
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date());
}

function callDuration(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, "0");
  const seconds = (totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function readStored<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function dataUrlToFile(dataUrl: string, filename = "orion-vision.jpg") {
  const [meta, content] = dataUrl.split(",");
  const mime = meta.match(/data:(.*?);/)?.[1] || "image/jpeg";
  const binary = atob(content);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return new File([bytes], filename, { type: mime });
}

function formatRemaining(milliseconds: number) {
  const seconds = Math.max(0, Math.ceil(milliseconds / 1000));
  const hours = Math.floor(seconds / 3600).toString().padStart(2, "0");
  const minutes = Math.floor((seconds % 3600) / 60).toString().padStart(2, "0");
  const rest = (seconds % 60).toString().padStart(2, "0");
  return `${hours}:${minutes}:${rest}`;
}

function safeFilename(value: string) {
  return value.trim().replace(/[^a-z0-9äöüß_-]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 70) || "orion-datei";
}

function isChatModel(id: string) {
  return !/(embed|moderation|audio|transcri|tts|speech|image|dall-e|realtime|video|veo|whisper|guard|safety)/i.test(id);
}

function apiModelScore(id: string, profile: ApiProfile) {
  const model = id.toLowerCase();
  let score = 0;
  if (/latest|preview|2026|5\.|4\.1|3\.6|3\.1/.test(model)) score += 12;
  if (profile === "supersaver") {
    if (/free|flash-lite|flash|nano|mini|small|8b|20b|haiku|instant|turbo/.test(model)) score += 120;
    if (/opus|pro|max|large|120b|reason|o[134]/.test(model)) score -= 75;
  } else if (profile === "balanced") {
    if (/mini|flash|sonnet|27b|32b|70b|4\.1|4o|gpt-5|qwen/.test(model)) score += 90;
    if (/embed|guard|audio/.test(model)) score -= 200;
  } else {
    if (/opus|pro|max|large|120b|reason|gpt-5|o[134]|sonnet|qwen3\.6/.test(model)) score += 125;
    if (/nano|lite|small|8b|instant/.test(model)) score -= 50;
  }
  return score;
}

// ═══ Anbieter am Schlüssel erkennen ═══
// Reihenfolge zählt: längere Präfixe zuerst, sonst schluckt "sk-" alles.
// Google vergibt zwei Formate — die alten beginnen mit AIza, die neuen mit AQ.
// Genau das fehlte bisher und ließ Gemini-Schlüssel bei OpenAI landen.
const ANBIETER_MUSTER: Array<{ test: RegExp; base: string; name: string; header?: "x-api-key" }> = [
  { test: /^AQ\./,             base: "https://generativelanguage.googleapis.com/v1beta/openai", name: "Google Gemini" },
  { test: /^AIza/i,            base: "https://generativelanguage.googleapis.com/v1beta/openai", name: "Google Gemini" },
  { test: /^gsk_/i,            base: "https://api.groq.com/openai/v1",            name: "Groq" },
  { test: /^sk-or-/i,          base: "https://openrouter.ai/api/v1",              name: "OpenRouter" },
  { test: /^sk-ant-/i,         base: "https://api.anthropic.com/v1",              name: "Anthropic Claude", header: "x-api-key" },
  { test: /^xai-/i,            base: "https://api.x.ai/v1",                       name: "xAI Grok" },
  { test: /^pplx-/i,           base: "https://api.perplexity.ai",                 name: "Perplexity" },
  { test: /^csk-/i,            base: "https://api.cerebras.ai/v1",                name: "Cerebras" },
  { test: /^nvapi-/i,          base: "https://integrate.api.nvidia.com/v1",       name: "NVIDIA NIM" },
  { test: /^hf_/i,             base: "https://router.huggingface.co/v1",          name: "HuggingFace" },
  { test: /^fw_/i,             base: "https://api.fireworks.ai/inference/v1",     name: "Fireworks" },
  { test: /^tgp_/i,            base: "https://api.together.xyz/v1",               name: "Together AI" },
  { test: /^glhf_/i,           base: "https://glhf.chat/api/openai/v1",           name: "glhf.chat" },
  { test: /^ms-/i,             base: "https://api.mistral.ai/v1",                 name: "Mistral" },
  { test: /^sk-proj-/i,        base: "https://api.openai.com/v1",                 name: "OpenAI" },
  { test: /^sk-svcacct-/i,     base: "https://api.openai.com/v1",                 name: "OpenAI" },
  { test: /^sk-[a-f0-9]{32}$/i, base: "https://api.deepseek.com/v1",              name: "DeepSeek" },
  { test: /^sk-/i,             base: "https://api.openai.com/v1",                 name: "OpenAI" },
];
function ERKENNE_ANBIETER(key: string) {
  const k = (key || "").trim();
  for (const m of ANBIETER_MUSTER) if (m.test.test(k)) return m;
  return null;
}

function selectApiModel(models: string[], profile: ApiProfile) {
  const gefiltert = models
    .filter(isChatModel)
    .map((id, index) => ({ id, index, score: apiModelScore(id, profile) }))
    .sort((a, b) => b.score - a.score || a.index - b.index)[0]?.id;
  if (gefiltert) return gefiltert;
  // Kein Modell hat den Chat-Filter bestanden — dann trotzdem etwas nehmen,
  // statt gar nichts. Lieber ein unbekanntes Modell versuchen als blockieren.
  return models[0] || "";
}

// ═══ Ersatzmodelle ═══
// Verlangt eine Funktion etwas Bestimmtes (z. B. ein Bildmodell), aber der
// Zugang hat es nicht, wird das naechstbeste genommen statt abzubrechen.
function passendesModell(models: string[], zweck: "chat" | "bild" | "ton" | "schnell", aktuell: string) {
  if (!models.length) return aktuell;
  const passt = (re: RegExp) => models.find((m) => re.test(m));
  if (zweck === "bild") {
    return passt(/image|imagen|dall-?e|flux|sd3|stable-?diffusion/i) || "";
  }
  if (zweck === "ton") {
    return passt(/tts|audio|speech|voice/i) || "";
  }
  if (zweck === "schnell") {
    return passt(/flash-?lite|mini|haiku|small|8b|turbo|fast/i) || aktuell || models[0];
  }
  return aktuell && models.includes(aktuell) ? aktuell : (selectApiModel(models, "balanced") || models[0]);
}

async function fetchWithRecovery(input: URL | string, init: RequestInit, retries = 1) {
  let lastResponse: Response | null = null;
  for (let attempt = 0; attempt <= retries; attempt += 1) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 55000);
    try {
      const response = await fetch(input, { ...init, signal: controller.signal });
      lastResponse = response;
      if (response.ok || ![408, 425, 429, 500, 502, 503, 504].includes(response.status) || attempt === retries) return response;
    } catch (error) {
      if (attempt === retries) throw error;
    } finally {
      window.clearTimeout(timeout);
    }
    await new Promise((resolve) => window.setTimeout(resolve, 450 * (attempt + 1)));
  }
  if (lastResponse) return lastResponse;
  throw new Error("API-Verbindung nicht erreichbar");
}

function simplePdfBlob(title: string, content: string) {
  const clean = `${title}\n\n${content}`.normalize("NFKD").replace(/[^\x20-\x7E\n]/g, "?");
  const lines = clean.split(/\r?\n/).flatMap((line) => line.match(/.{1,88}/g) || [""]).slice(0, 46);
  const body = lines.map((line, index) => `BT /F1 ${index === 0 ? 18 : 11} Tf 54 ${790 - index * 16} Td (${line.replace(/[\\()]/g, "\\$&")}) Tj ET`).join("\n");
  const objects = [
    "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj",
    "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj",
    "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj",
    "4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj",
    `5 0 obj << /Length ${body.length} >> stream\n${body}\nendstream endobj`,
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object) => { offsets.push(pdf.length); pdf += `${object}\n`; });
  const xref = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  offsets.slice(1).forEach((offset) => { pdf += `${offset.toString().padStart(10, "0")} 00000 n \n`; });
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new Blob([pdf], { type: "application/pdf" });
}

function streamEmbedUrl(raw: string) {
  try {
    const url = new URL(raw.trim());
    const host = url.hostname.replace(/^www\./, "");
    if (host === "youtu.be") return `https://www.youtube-nocookie.com/embed/${url.pathname.slice(1)}`;
    if (host.endsWith("youtube.com")) {
      const videoId = url.searchParams.get("v") || url.pathname.match(/\/(?:live|shorts|embed)\/([^/?]+)/)?.[1];
      if (videoId) return `https://www.youtube-nocookie.com/embed/${videoId}`;
    }
    if (host.endsWith("twitch.tv")) {
      const channel = url.pathname.split("/").filter(Boolean)[0];
      if (channel) return `https://player.twitch.tv/?channel=${encodeURIComponent(channel)}&parent=${location.hostname || "localhost"}`;
    }
    return url.toString();
  } catch {
    return "";
  }
}

function compactId(value: string) {
  let hash = 2166136261;
  for (let index = 0; index < value.length; index += 1) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619);
  return Math.abs(hash >>> 0).toString(36);
}

function parseTwitchMessage(line: string): { id: string; user: string; text: string } | null {
  const match = line.match(/^(?:@([^ ]+) )?:([^! ]+)![^ ]+ PRIVMSG #[^ ]+ :([\s\S]+)$/);
  if (!match) return null;
  const tags = Object.fromEntries((match[1] || "").split(";").filter(Boolean).map((part) => {
    const [key, ...value] = part.split("=");
    return [key, value.join("=")];
  }));
  const user = (tags["display-name"] || match[2]).replace(/\\s/g, " ");
  const text = match[3].trim();
  return text ? { id: tags.id || compactId(`${user}:${text}`), user, text } : null;
}

function responseText(value: unknown): string {
  if (typeof value === "string") return value;
  if (!value || typeof value !== "object") return "";
  const object = value as {
    message?: { content?: string | Array<{ text?: string }> };
    text?: string;
  };
  if (typeof object.text === "string") return object.text;
  if (typeof object.message?.content === "string") return object.message.content;
  if (Array.isArray(object.message?.content)) {
    return object.message.content.map((part) => part.text || "").join("");
  }
  return "";
}

function Icon({ name, size = 20 }: { name: string; size?: number }) {
  const paths: Record<string, React.ReactNode> = {
    chat: <path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v7a2.5 2.5 0 0 1-2.5 2.5H10l-5 4v-4.8A2.5 2.5 0 0 1 4 12.5Z" />,
    eye: <><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" /><circle cx="12" cy="12" r="2.7" /></>,
    spark: <><path d="m12 2 1.35 5.2L18 9l-4.65 1.8L12 16l-1.35-5.2L6 9l4.65-1.8Z" /><path d="m18.5 15 .65 2.35L21.5 18l-2.35.65L18.5 21l-.65-2.35L15.5 18l2.35-.65Z" /></>,
    memory: <><path d="M8 4.5A3.5 3.5 0 0 0 4.5 8v8A3.5 3.5 0 0 0 8 19.5h8a3.5 3.5 0 0 0 3.5-3.5V8A3.5 3.5 0 0 0 16 4.5Z" /><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M18 9h4M2 15h4M18 15h4M9 9h6v6H9z" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06-2.83 2.83-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21h-4v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06-2.83-2.83.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3v-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06 2.83-2.83.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3h4v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06 2.83 2.83-.06.06A1.65 1.65 0 0 0 19.32 9c.12.6.65 1 1.26 1H21v4h-.09A1.65 1.65 0 0 0 19.4 15Z" /></>,
    mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M9 21h6" /></>,
    send: <><path d="m22 2-9 20-2.5-8.5L2 11Z" /><path d="M22 2 10.5 13.5" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    copy: <><rect x="8" y="8" width="11" height="11" rx="2" /><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3" /></>,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    install: <><path d="M12 3v12M7 10l5 5 5-5" /><path d="M5 21h14" /></>,
    trash: <><path d="M4 7h16M9 7V4h6v3M6 7l1 14h10l1-14M10 11v6M14 11v6" /></>,
    camera: <><path d="M4 7h3l1.5-2h7L17 7h3a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z" /><circle cx="12" cy="13" r="4" /></>,
    monitor: <><rect x="3" y="4" width="18" height="13" rx="2" /><path d="M8 21h8M12 17v4" /></>,
    phone: <path d="M6.6 3.5 9 8l-2.1 1.7a15.5 15.5 0 0 0 7.4 7.4L16 15l4.5 2.4-.7 3.1a2 2 0 0 1-2 1.5C9.1 21.4 2.6 14.9 2 6.2a2 2 0 0 1 1.5-2Z" />,
    volume: <><path d="M5 10v4h4l5 4V6l-5 4Z" /><path d="M17 9a4 4 0 0 1 0 6M19.5 6.5a8 8 0 0 1 0 11" /></>,
    radio: <><rect x="3" y="6" width="18" height="14" rx="3" /><path d="m7 6 10-4M7 11h5M7 15h3" /><circle cx="16.5" cy="14" r="2.5" /></>,
    game: <><path d="M7.5 7h9a4.5 4.5 0 0 1 4.3 5.8l-1.2 4a2.5 2.5 0 0 1-4 1.25L13.8 16h-3.6l-1.8 2.05a2.5 2.5 0 0 1-4-1.25l-1.2-4A4.5 4.5 0 0 1 7.5 7Z" /><path d="M7 11v4M5 13h4M16.5 11.5h.01M18.5 14h.01" /></>,
    bolt: <path d="m13 2-9 12h7l-1 8 10-13h-7Z" />,
    globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" /></>,
    shield: <path d="M12 2 4.5 5v6c0 5 3.2 8.5 7.5 11 4.3-2.5 7.5-6 7.5-11V5Z" />,
  };

  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {paths[name] || paths.spark}
    </svg>
  );
}

function MessageText({ text }: { text: string }) {
  const segments = text.split("```");
  return (
    <>
      {segments.map((segment, index) =>
        index % 2 === 1 ? (
          <pre className="code-block" key={`${index}-${segment.slice(0, 8)}`}><code>{segment.replace(/^\w+\n/, "")}</code></pre>
        ) : (
          <span className="message-lines" key={`${index}-${segment.slice(0, 8)}`}>{segment}</span>
        ),
      )}
    </>
  );
}

export function OrionApp() {
  const initialWelcome = useMemo<Message>(() => ({
    id: "orion-welcome",
    role: "assistant",
    text: "Willkommen, Meister. ORION V1 Beta ist online. Was steht an?",
    createdAt: "SYSTEM",
  }), []);

  const [hydrated, setHydrated] = useState(false);
  const [view, setView] = useState<View>("chat");
  const [messages, setMessages] = useState<Message[]>([initialWelcome]);
  const [memory, setMemory] = useState<MemoryFact[]>([]);
  const [commands, setCommands] = useState<CustomCommand[]>([]);
  const [missions, setMissions] = useState<Mission[]>([]);
  const [input, setInput] = useState("");
  const [mode, setMode] = useState("assistant");
  const [modelTier, setModelTier] = useState<keyof typeof MODELS>("maximum");
  const [aiState, setAiState] = useState<AIState>("ready");
  const [isOnline, setIsOnline] = useState(true);
  const [platform, setPlatform] = useState("Web");
  const [autoSpeak, setAutoSpeak] = useState(true);
  const [voiceEngine, setVoiceEngine] = useState<VoiceEngine>("neural");
  const [voiceProfile, setVoiceProfile] = useState("Kore");
  const [assistantGender, setAssistantGender] = useState<AssistantGender>("female");
  const [personalityStrength, setPersonalityStrength] = useState(2);
  const [relationshipCloseness, setRelationshipCloseness] = useState(1);
  const [humorLevel, setHumorLevel] = useState(1);
  const [formalityLevel, setFormalityLevel] = useState(2);
  const [speechLanguage, setSpeechLanguage] = useState("de-DE");
  const [liveVoice, setLiveVoice] = useState(false);
  const [livePanelOpen, setLivePanelOpen] = useState(false);
  const [liveSeconds, setLiveSeconds] = useState(0);
  const [cloudSignedIn, setCloudSignedIn] = useState(false);
  const [cloudUser, setCloudUser] = useState("");
  const [authBusy, setAuthBusy] = useState(false);
  const [connectionMode, setConnectionMode] = useState<ConnectionMode>("account");
  const [apiBaseUrl, setApiBaseUrl] = useState("https://api.openai.com/v1");
  const [apiModel, setApiModel] = useState("gpt-4.1-mini");
  const [apiKey, setApiKey] = useState("");
  const [rememberApiKey, setRememberApiKey] = useState(false);
  const [apiDetectedProvider, setApiDetectedProvider] = useState("Noch nicht geprüft");
  const [apiModels, setApiModels] = useState<string[]>([]);
  const [apiCheckStatus, setApiCheckStatus] = useState("");
  const [apiProfile, setApiProfile] = useState<ApiProfile>("balanced");
  const [apiAutoModel, setApiAutoModel] = useState(true);
  const [memoryLearningEnabled, setMemoryLearningEnabled] = useState(true);
  const [autoActions, setAutoActions] = useState(true);
  const [liveWeb, setLiveWeb] = useState(false);
  const [proactive, setProactive] = useState(true);
  const [preferredName, setPreferredName] = useState("Meister");
  const [wakeWord, setWakeWord] = useState("Orion");
  const [standbyEnabled, setStandbyEnabled] = useState(false);
  const [crosshairEnabled, setCrosshairEnabled] = useState(false);
  const [chargingSound, setChargingSound] = useState(false);
  const [nativeAvailable, setNativeAvailable] = useState(false);
  const [desktopAvailable, setDesktopAvailable] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsSaved, setSettingsSaved] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [installHint, setInstallHint] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [attachment, setAttachment] = useState<string | null>(null);
  const [attachmentName, setAttachmentName] = useState("");
  const [lastLatency, setLastLatency] = useState<number | null>(null);
  const [memoryKey, setMemoryKey] = useState("");
  const [memoryValue, setMemoryValue] = useState("");
  const [commandPhrase, setCommandPhrase] = useState("");
  const [commandInstruction, setCommandInstruction] = useState("");
  const [missionInput, setMissionInput] = useState("");
  const [missionBusy, setMissionBusy] = useState(false);
  const [studioPrompt, setStudioPrompt] = useState("");
  const [studioImage, setStudioImage] = useState<string | null>(null);
  const [studioBusy, setStudioBusy] = useState(false);
  const [studioError, setStudioError] = useState("");
  const [studioModel, setStudioModel] = useState("gpt-image-2");
  const [studioQuality, setStudioQuality] = useState<"low" | "medium" | "high">("medium");
  const [studioRatio, setStudioRatio] = useState<"1:1" | "16:9" | "9:16">("1:1");
  const [visionStream, setVisionStream] = useState<MediaStream | null>(null);
  const [visionSource, setVisionSource] = useState<"camera" | "screen" | null>(null);
  const [dauerblick, setDauerblick] = useState(false);
  const [screenCapturePending, setScreenCapturePending] = useState(false);
  const [visionStatus, setVisionStatus] = useState("Keine Bildschirmquelle aktiv");
  const [keepScreenAwake, setKeepScreenAwake] = useState(true);
  const [gamingCoach, setGamingCoach] = useState(false);
  const [gameName, setGameName] = useState("");
  const [coachInterval, setCoachInterval] = useState(12);
  const [coachSpeak, setCoachSpeak] = useState(true);
  const [coachCall, setCoachCall] = useState("");
  const [coachBusy, setCoachBusy] = useState(false);
  const [coachHistory, setCoachHistory] = useState<Array<{ id: string; text: string; at: string }>>([]);
  const [nativeCoachFrame, setNativeCoachFrame] = useState<string | null>(null);
  const [radioStation, setRadioStation] = useState("groove");
  const [radioPlaying, setRadioPlaying] = useState(false);
  const [radioTrack, setRadioTrack] = useState("Titel wird geladen …");
  const [onboardingOpen, setOnboardingOpen] = useState(false);
  const [bootVisible, setBootVisible] = useState(true);
  const [bootProgress, setBootProgress] = useState(12);
  const [standbyOrbOpen, setStandbyOrbOpen] = useState(false);
  const [timers, setTimers] = useState<OrionTimer[]>([]);
  const [timerValue, setTimerValue] = useState(5);
  const [timerUnit, setTimerUnit] = useState<TimerUnit>("minutes");
  const [timerLabel, setTimerLabel] = useState("Timer");
  const [now, setNow] = useState(() => Date.now());
  const [toolTab, setToolTab] = useState<"timer" | "translate" | "files" | "games" | "stream" | "device" | "security">("timer");
  const [translateInput, setTranslateInput] = useState("");
  const [translateOutput, setTranslateOutput] = useState("");
  const [translateTarget, setTranslateTarget] = useState("en-US");
  const [fileTitle, setFileTitle] = useState("ORION Dokument");
  const [fileContent, setFileContent] = useState("");
  const [fileFormat, setFileFormat] = useState<"txt" | "md" | "html" | "doc" | "pdf">("txt");
  const [gamePrompt, setGamePrompt] = useState("");
  const [gameDifficulty, setGameDifficulty] = useState("normal");
  const [gameCode, setGameCode] = useState("");
  const [gameBug, setGameBug] = useState("");
  const [gameBusy, setGameBusy] = useState(false);
  const [streamUrl, setStreamUrl] = useState("");
  const [activeStreamUrl, setActiveStreamUrl] = useState("");
  const [streamChannel, setStreamChannel] = useState("");
  const [streamChatStatus, setStreamChatStatus] = useState("Nicht verbunden");
  const [streamChatConnected, setStreamChatConnected] = useState(false);
  const [streamChatMessages, setStreamChatMessages] = useState<StreamChatMessage[]>([]);
  const [streamChatImport, setStreamChatImport] = useState("");
  const [creatorName, setCreatorName] = useState("Barys");
  const [gamerRole, setGamerRole] = useState("IGL + Fragger");
  const [gamerCallStyle, setGamerCallStyle] = useState("kurz");
  const [streamerMode, setStreamerMode] = useState(false);
  const [performanceMode, setPerformanceMode] = useState(true);
  const [autoRepair, setAutoRepair] = useState(true);
  const [stabilityState, setStabilityState] = useState<StabilityState>("optimal");
  const [lastRepair, setLastRepair] = useState("Noch keine Störung erkannt");
  const [recoveryCount, setRecoveryCount] = useState(0);
  const [deviceFacts, setDeviceFacts] = useState<DeviceFacts>({ model: "Nicht freigegeben", platform: "Web", browser: "Unbekannt", screen: "–", memory: "Nicht verfügbar", cpu: "–", battery: "Wird geprüft", network: "Unbekannt", temperature: "Vom System nicht freigegeben" });
  const [auditLog, setAuditLog] = useState<Array<{ id: string; text: string; at: string }>>([]);

  const messageEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const importInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const recognitionRef = useRef<RecognitionLike | null>(null);
  const neuralAudioRef = useRef<HTMLAudioElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const fallbackAudioStreamRef = useRef<MediaStream | null>(null);
  const fallbackChunksRef = useRef<Blob[]>([]);
  const fallbackTimerRef = useRef<number | null>(null);
  const discardFallbackRef = useRef(false);
  const speechUnsupportedNotifiedRef = useRef(false);
  const radioRef = useRef<HTMLAudioElement>(null);
  const cloudLoadedRef = useRef(false);
  const puterModuleRef = useRef<PuterModule | null>(null);
  const chargingStateRef = useRef<boolean | null>(null);
  const coachBusyRef = useRef(false);
  const lastCoachCallRef = useRef("");
  const pendingCoachLaunchRef = useRef("");
  const connectionModeRef = useRef<ConnectionMode>(connectionMode);
  const streamChatWsRef = useRef<WebSocket | null>(null);
  const streamSeenRef = useRef(new Set<string>());
  const wakeLockRef = useRef<{ release: () => Promise<void> } | null>(null);

  useEffect(() => {
    connectionModeRef.current = connectionMode;
  }, [connectionMode]);

  useEffect(() => {
    const savedSettings = readStored(STORAGE.settings, {
      mode: "assistant",
      modelTier: "maximum" as keyof typeof MODELS,
      autoSpeak: true,
      voiceEngine: "neural" as VoiceEngine,
      voiceProfile: "Kore",
      assistantGender: "female" as AssistantGender,
      personalityStrength: 2,
      relationshipCloseness: 1,
      humorLevel: 1,
      formalityLevel: 2,
      speechLanguage: "de-DE",
      radioStation: "groove",
      autoActions: true,
      liveWeb: false,
      proactive: true,
      preferredName: "Meister",
      wakeWord: "Orion",
      standbyEnabled: false,
      crosshairEnabled: false,
      chargingSound: false,
      connectionMode: "account" as ConnectionMode,
      apiBaseUrl: "https://api.openai.com/v1",
      apiModel: "gpt-4.1-mini",
      apiProfile: "balanced" as ApiProfile,
      apiAutoModel: true,
      memoryLearningEnabled: true,
      rememberApiKey: false,
      apiKey: "",
      gameName: "",
      coachInterval: 12,
      coachSpeak: true,
      studioModel: "gpt-image-2",
      studioQuality: "medium" as "low" | "medium" | "high",
      studioRatio: "1:1" as "1:1" | "16:9" | "9:16",
      streamChannel: "",
      creatorName: "Barys",
      gamerRole: "IGL + Fragger",
      gamerCallStyle: "kurz",
      streamerMode: false,
      performanceMode: true,
      autoRepair: true,
      keepScreenAwake: true,
    });
    setMessages(readStored(STORAGE.messages, [initialWelcome]));
    setMemory(readStored(STORAGE.memory, []));
    setCommands(readStored(STORAGE.commands, []));
    setMissions(readStored(STORAGE.missions, []));
    setStreamChatMessages(readStored<StreamChatMessage[]>(STORAGE.streamChat, []).slice(-100));
    setMode(savedSettings.mode);
    setModelTier(savedSettings.modelTier);
    setAutoSpeak(savedSettings.autoSpeak);
    setVoiceEngine(savedSettings.voiceEngine === "device" ? "device" : "neural");
    setVoiceProfile(VOICE_PROFILES.some((voice) => voice.id === savedSettings.voiceProfile) ? savedSettings.voiceProfile : "Kore");
    setAssistantGender(["female", "male", "neutral"].includes(savedSettings.assistantGender) ? savedSettings.assistantGender as AssistantGender : "female");
    setPersonalityStrength(Math.max(0, Math.min(4, Number(savedSettings.personalityStrength ?? 2))));
    setRelationshipCloseness(Math.max(0, Math.min(4, Number(savedSettings.relationshipCloseness ?? 1))));
    setHumorLevel(Math.max(0, Math.min(4, Number(savedSettings.humorLevel ?? 1))));
    setFormalityLevel(Math.max(0, Math.min(4, Number(savedSettings.formalityLevel ?? 2))));
    setSpeechLanguage(LANGUAGES.some((language) => language.id === savedSettings.speechLanguage) ? savedSettings.speechLanguage : "de-DE");
    setRadioStation(RADIO_STATIONS.some((station) => station.id === savedSettings.radioStation) ? savedSettings.radioStation : "groove");
    setLiveVoice(false);
    setAutoActions(savedSettings.autoActions !== false);
    setLiveWeb(savedSettings.liveWeb);
    setProactive(savedSettings.proactive);
    setPreferredName(savedSettings.preferredName?.trim() || "Meister");
    setWakeWord(savedSettings.wakeWord?.trim() || "Orion");
    setStandbyEnabled(Boolean(savedSettings.standbyEnabled));
    setCrosshairEnabled(Boolean(savedSettings.crosshairEnabled));
    setChargingSound(Boolean(savedSettings.chargingSound));
    setConnectionMode(savedSettings.connectionMode === "api" ? "api" : "account");
    setApiBaseUrl(savedSettings.apiBaseUrl?.trim() || "https://api.openai.com/v1");
    setApiModel(savedSettings.apiModel?.trim() || "gpt-4.1-mini");
    setApiProfile(["supersaver", "balanced", "maximum"].includes(savedSettings.apiProfile) ? savedSettings.apiProfile : "balanced");
    setApiAutoModel(savedSettings.apiAutoModel !== false);
    setMemoryLearningEnabled(savedSettings.memoryLearningEnabled !== false);
    setRememberApiKey(Boolean(savedSettings.rememberApiKey));
    setApiKey(savedSettings.rememberApiKey ? savedSettings.apiKey || "" : "");
    setGameName(savedSettings.gameName?.trim() || "");
    setCoachInterval([8, 12, 20].includes(Number(savedSettings.coachInterval)) ? Number(savedSettings.coachInterval) : 12);
    setCoachSpeak(savedSettings.coachSpeak !== false);
    setStudioModel(savedSettings.studioModel?.trim() || "gpt-image-2");
    setStudioQuality(["low", "medium", "high"].includes(savedSettings.studioQuality) ? savedSettings.studioQuality : "medium");
    setStudioRatio(["1:1", "16:9", "9:16"].includes(savedSettings.studioRatio) ? savedSettings.studioRatio : "1:1");
    setStreamChannel(savedSettings.streamChannel?.trim() || "");
    setCreatorName(savedSettings.creatorName?.trim() || "Barys");
    setGamerRole(savedSettings.gamerRole?.trim() || "IGL + Fragger");
    setGamerCallStyle(["ultrakurz", "kurz", "erklärt"].includes(savedSettings.gamerCallStyle) ? savedSettings.gamerCallStyle : "kurz");
    setStreamerMode(Boolean(savedSettings.streamerMode));
    setPerformanceMode(savedSettings.performanceMode !== false);
    setAutoRepair(savedSettings.autoRepair !== false);
    setKeepScreenAwake(savedSettings.keepScreenAwake !== false);
    setTimers(readStored(STORAGE.timers, []).filter((timer: OrionTimer) => timer.endsAt > Date.now() || !timer.completed));
    setOnboardingOpen(localStorage.getItem(STORAGE.onboarding) !== "done");
    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    const desktopBridge = (window as typeof window & { ORION_NATIVE?: OrionDesktopBridge }).ORION_NATIVE;
    setNativeAvailable(Boolean(androidBridge));
    setDesktopAvailable(Boolean(desktopBridge?.desktop));
    setIsOnline(navigator.onLine);
    const source = `${navigator.userAgent} ${navigator.platform}`;
    setPlatform(/iPhone|iPad|iPod/i.test(source) ? "iOS" : /Android/i.test(source) ? "Android" : /Mac/i.test(source) ? "macOS" : /Win/i.test(source) ? "Windows" : /Linux/i.test(source) ? "Linux" : "Web");
    setHydrated(true);

    const online = () => { setIsOnline(true); setAiState("ready"); };
    const offline = () => { setIsOnline(false); setAiState("offline"); };
    const beforeInstall = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    window.addEventListener("online", online);
    window.addEventListener("offline", offline);
    window.addEventListener("beforeinstallprompt", beforeInstall);

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }

    void import("@heyputer/puter.js").then(async (module) => {
      puterModuleRef.current = module;
      if (!module.puter.auth.isSignedIn()) return;
      setCloudSignedIn(true);
      const user = await module.puter.auth.getUser().catch(() => null) as { username?: string; email?: string } | null;
      setCloudUser(user?.username || user?.email || "Puter-Konto");
      if (cloudLoadedRef.current) return;
      const cloud = await module.puter.kv.get<CloudBrain>("orion.brain.v1");
      if (!cloud || cloud.version !== 1) return;
      cloudLoadedRef.current = true;
      setMemory((current) => {
        const merged = new Map<string, MemoryFact>();
        [...cloud.memory, ...current].forEach((item) => merged.set(item.key.toLowerCase(), item));
        return Array.from(merged.values()).slice(-160);
      });
      setCommands((current) => {
        const merged = new Map<string, CustomCommand>();
        [...cloud.commands, ...current].forEach((item) => merged.set(item.phrase.toLowerCase(), item));
        return Array.from(merged.values()).slice(-80);
      });
      setMessages((current) => {
        const merged = new Map<string, Message>();
        [...cloud.messages, ...current].forEach((item) => merged.set(item.id, item));
        return Array.from(merged.values()).slice(-60);
      });
    }).catch(() => undefined);

    return () => {
      window.removeEventListener("online", online);
      window.removeEventListener("offline", offline);
      window.removeEventListener("beforeinstallprompt", beforeInstall);
    };
  }, [initialWelcome]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.messages, JSON.stringify(messages.slice(-60)));
  }, [hydrated, messages]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.memory, JSON.stringify(memory));
  }, [hydrated, memory]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.commands, JSON.stringify(commands));
  }, [hydrated, commands]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.missions, JSON.stringify(missions.slice(-40)));
  }, [hydrated, missions]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.settings, JSON.stringify({ mode, modelTier, autoSpeak, voiceEngine, voiceProfile, assistantGender, personalityStrength, relationshipCloseness, humorLevel, formalityLevel, speechLanguage, radioStation, autoActions, liveWeb, proactive, preferredName, wakeWord, standbyEnabled, crosshairEnabled, chargingSound, connectionMode, apiBaseUrl, apiModel, apiProfile, apiAutoModel, memoryLearningEnabled, rememberApiKey, apiKey: rememberApiKey ? apiKey : "", gameName, coachInterval, coachSpeak, studioModel, studioQuality, studioRatio, streamChannel, creatorName, gamerRole, gamerCallStyle, streamerMode, performanceMode, autoRepair, keepScreenAwake }));
  }, [apiAutoModel, apiBaseUrl, apiKey, apiModel, apiProfile, assistantGender, autoActions, autoRepair, chargingSound, coachInterval, coachSpeak, connectionMode, creatorName, crosshairEnabled, formalityLevel, gameName, gamerCallStyle, gamerRole, hydrated, humorLevel, keepScreenAwake, memoryLearningEnabled, mode, modelTier, autoSpeak, performanceMode, personalityStrength, relationshipCloseness, rememberApiKey, voiceEngine, voiceProfile, speechLanguage, radioStation, liveWeb, proactive, preferredName, wakeWord, standbyEnabled, streamChannel, streamerMode, studioModel, studioQuality, studioRatio]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.timers, JSON.stringify(timers));
  }, [hydrated, timers]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE.streamChat, JSON.stringify(streamChatMessages.slice(-100)));
  }, [hydrated, streamChatMessages]);

  useEffect(() => {
    if (!hydrated) return;
    const interval = window.setInterval(() => setNow(Date.now()), 250);
    return () => window.clearInterval(interval);
  }, [hydrated]);

  useEffect(() => {
    const steps = [28, 47, 69, 86, 100];
    let index = 0;
    const interval = window.setInterval(() => {
      setBootProgress(steps[index] || 100);
      index += 1;
      if (index >= steps.length) {
        window.clearInterval(interval);
        window.setTimeout(() => setBootVisible(false), 380);
      }
    }, 180);
    return () => window.clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const nav = navigator as Navigator & {
      deviceMemory?: number;
      connection?: { effectiveType?: string; downlink?: number };
      getBattery?: () => Promise<{ level: number; charging: boolean }>;
      userAgentData?: { getHighEntropyValues: (hints: string[]) => Promise<{ model?: string; platform?: string; platformVersion?: string }> };
    };
    const browser = /Edg/i.test(nav.userAgent) ? "Edge" : /Firefox/i.test(nav.userAgent) ? "Firefox" : /Chrome/i.test(nav.userAgent) ? "Chrome" : /Safari/i.test(nav.userAgent) ? "Safari" : "Browser";
    setDeviceFacts((current) => ({
      ...current,
      platform,
      browser,
      screen: `${window.screen.width} × ${window.screen.height} · ${window.devicePixelRatio.toFixed(1)}x`,
      memory: nav.deviceMemory ? `${nav.deviceMemory} GB (Schätzwert)` : "Vom Browser verborgen",
      cpu: `${nav.hardwareConcurrency || "?"} logische Kerne`,
      network: nav.connection?.effectiveType ? `${nav.connection.effectiveType.toUpperCase()}${nav.connection.downlink ? ` · ${nav.connection.downlink} Mbit/s` : ""}` : navigator.onLine ? "Online" : "Offline",
    }));
    void nav.userAgentData?.getHighEntropyValues(["model", "platform", "platformVersion"]).then((data) => {
      setDeviceFacts((current) => ({ ...current, model: data.model?.trim() || "Modell vom Browser verborgen", platform: `${data.platform || platform}${data.platformVersion ? ` ${data.platformVersion}` : ""}` }));
    }).catch(() => undefined);
    void nav.getBattery?.().then((battery) => setDeviceFacts((current) => ({ ...current, battery: `${Math.round(battery.level * 100)} %${battery.charging ? " · lädt" : ""}` }))).catch(() => setDeviceFacts((current) => ({ ...current, battery: "Vom Browser verborgen" })));
  }, [hydrated, platform]);

  useEffect(() => {
    if (!hydrated || !chargingSound) return;
    const nav = navigator as Navigator & { getBattery?: () => Promise<{ charging: boolean; addEventListener: (type: string, listener: () => void) => void; removeEventListener: (type: string, listener: () => void) => void }> };
    let battery: Awaited<ReturnType<NonNullable<typeof nav.getBattery>>> | null = null;
    const chime = () => {
      if (!battery) return;
      if (chargingStateRef.current === false && battery.charging) {
        try {
          const context = new AudioContext();
          [520, 690, 860].forEach((frequency, index) => {
            const oscillator = context.createOscillator();
            const gain = context.createGain();
            oscillator.frequency.value = frequency;
            gain.gain.value = 0.06;
            oscillator.connect(gain).connect(context.destination);
            oscillator.start(context.currentTime + index * 0.12);
            oscillator.stop(context.currentTime + index * 0.12 + 0.18);
          });
        } catch { /* Charging detection still works if audio is blocked. */ }
      }
      chargingStateRef.current = battery.charging;
    };
    void nav.getBattery?.().then((value) => { battery = value; chargingStateRef.current = value.charging; value.addEventListener("chargingchange", chime); });
    return () => battery?.removeEventListener("chargingchange", chime);
  }, [chargingSound, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    const refreshTrack = async () => {
      const station = RADIO_STATIONS.find((item) => item.id === radioStation) || RADIO_STATIONS[0];
      if (!station.metaId) {
        setRadioTrack(`${station.label} · Live-Stream`);
        return;
      }
      try {
        const response = await fetch("https://api.somafm.com/channels.json", { cache: "no-store" });
        if (!response.ok) throw new Error("metadata-unavailable");
        const data = await response.json() as { channels?: Array<{ id?: string; lastPlaying?: string }> };
        const channel = data.channels?.find((item) => item.id === station.metaId);
        setRadioTrack(channel?.lastPlaying?.trim() || "Songtitel momentan nicht übertragen");
      } catch {
        setRadioTrack("Songtitel momentan nicht übertragen");
      }
    };
    void refreshTrack();
    const interval = window.setInterval(() => { void refreshTrack(); }, 20000);
    return () => window.clearInterval(interval);
  }, [hydrated, radioStation]);

  useEffect(() => {
    if (!liveVoice) {
      setLiveSeconds(0);
      return;
    }
    const startedAt = Date.now();
    setLiveSeconds(0);
    const timer = window.setInterval(() => setLiveSeconds(Math.floor((Date.now() - startedAt) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [liveVoice]);

  useEffect(() => {
    if (!hydrated || !nativeAvailable) return;
    const bridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    const config = JSON.stringify({ preferredName, wakeWord, autoSpeak, autoActions, speechLanguage });
    if (standbyEnabled) bridge?.startStandby?.(config);
    else bridge?.stopStandby?.();
    bridge?.updateConfig?.(config);
  }, [autoActions, autoSpeak, hydrated, nativeAvailable, preferredName, speechLanguage, standbyEnabled, wakeWord]);

  useEffect(() => {
    if (!hydrated) return;
    const timer = window.setTimeout(() => {
      void import("@heyputer/puter.js").then(async (module) => {
        if (!module.puter.auth.isSignedIn()) return;
        const brain: CloudBrain = {
          version: 1,
          updatedAt: new Date().toISOString(),
          memory: memory.slice(-160),
          commands: commands.slice(-80),
          messages: messages.slice(-60),
        };
        await module.puter.kv.set("orion.brain.v1", brain);
        cloudLoadedRef.current = true;
      }).catch(() => undefined);
    }, 1400);
    return () => window.clearTimeout(timer);
  }, [commands, hydrated, memory, messages]);

  useEffect(() => {
    if (view !== "chat" || settingsOpen || aboutOpen || installHint || onboardingOpen || livePanelOpen) return;
    messageEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [aboutOpen, aiState, installHint, livePanelOpen, messages, onboardingOpen, settingsOpen, view]);

  useEffect(() => {
    if (!videoRef.current) return;
    videoRef.current.srcObject = visionStream;
    if (visionStream) videoRef.current.play().catch(() => undefined);
  }, [visionStream, view]);

  useEffect(() => {
    if (!dauerblick || !visionStream) return;
    const interval = window.setInterval(() => {
      const video = videoRef.current;
      if (!video || !video.videoWidth) return;
      const canvas = document.createElement("canvas");
      canvas.width = Math.min(video.videoWidth, 1280);
      canvas.height = Math.round((video.videoHeight / video.videoWidth) * canvas.width);
      canvas.getContext("2d")?.drawImage(video, 0, 0, canvas.width, canvas.height);
      setAttachment(canvas.toDataURL("image/jpeg", 0.78));
      setAttachmentName("Dauerblick · letzter Frame");
    }, 5000);
    return () => window.clearInterval(interval);
  }, [dauerblick, visionStream]);

  const speak = useCallback((text: string, force = false) => {
    if (!autoSpeak && !force) return;
    neuralAudioRef.current?.pause();
    neuralAudioRef.current = null;
    window.speechSynthesis?.cancel();
    const clean = text.replace(/```[\s\S]*?```/g, " Code wurde erstellt. ").replace(/[#*_`]/g, "").slice(0, 1800);
    if (!clean.trim()) return;

    const speakWithDevice = () => {
      if (!("speechSynthesis" in window)) {
        setAiState("ready");
        return;
      }
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.lang = speechLanguage;
      utterance.rate = voiceProfile === "Puck" ? 1.06 : voiceProfile === "Orus" ? 0.94 : 0.99;
      utterance.pitch = assistantGender === "male" ? 0.82 : assistantGender === "female" ? 1.04 : 0.95;
      const languagePrefix = speechLanguage.split("-")[0].toLowerCase();
      const matchingVoices = window.speechSynthesis.getVoices().filter((voice) => voice.lang.toLowerCase().startsWith(languagePrefix));
      const genderPattern = assistantGender === "male" ? /male|mann|mascul/i : assistantGender === "female" ? /female|frau|feminin/i : /natural|premium|enhanced|neural/i;
      const preferredVoice = matchingVoices.find((voice) => genderPattern.test(voice.name)) || matchingVoices.find((voice) => /natural|premium|enhanced|neural/i.test(voice.name)) || matchingVoices[0];
      if (preferredVoice) utterance.voice = preferredVoice;
      utterance.onstart = () => setAiState("speaking");
      utterance.onend = () => setAiState("ready");
      utterance.onerror = () => setAiState("ready");
      window.speechSynthesis.speak(utterance);
    };

    const puterClient = puterModuleRef.current;
    const voice = VOICE_PROFILES.find((item) => item.id === voiceProfile) || VOICE_PROFILES[0];
    if (voiceEngine === "neural" && connectionMode === "api" && apiKey.trim() && apiBaseUrl.trim()) {
      setAiState("speaking");
      void fetch(`${apiBaseUrl.replace(/\/$/, "")}/audio/speech`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` },
        body: JSON.stringify({ model: "gpt-4o-mini-tts", voice: assistantGender === "male" ? "onyx" : assistantGender === "female" ? "coral" : "alloy", input: clean, instructions: voice.instructions, response_format: "mp3" }),
      }).then(async (response) => {
        if (!response.ok) throw new Error(`TTS ${response.status}`);
        const url = URL.createObjectURL(await response.blob());
        const audio = new Audio(url);
        neuralAudioRef.current = audio;
        audio.onended = () => { URL.revokeObjectURL(url); neuralAudioRef.current = null; setAiState("ready"); };
        audio.onerror = () => { URL.revokeObjectURL(url); neuralAudioRef.current = null; speakWithDevice(); };
        return audio.play();
      }).catch(() => speakWithDevice());
      return;
    }
    if (voiceEngine === "device" || !puterClient?.puter.auth.isSignedIn()) {
      speakWithDevice();
      return;
    }
    setAiState("speaking");
    void puterClient.puter.ai.txt2speech(clean, {
      provider: "gemini",
      model: "gemini-2.5-flash-preview-tts",
      voice: voice.id,
      instructions: voice.instructions,
    }).then((audio) => {
      neuralAudioRef.current = audio;
      audio.onended = () => { neuralAudioRef.current = null; setAiState("ready"); };
      audio.onerror = () => { neuralAudioRef.current = null; speakWithDevice(); };
      return audio.play();
    }).catch(() => speakWithDevice());
  }, [apiBaseUrl, apiKey, assistantGender, autoSpeak, connectionMode, speechLanguage, voiceEngine, voiceProfile]);

  const addAssistantMessage = useCallback((text: string, readAloud = true) => {
    const message: Message = { id: uid("assistant"), role: "assistant", text, createdAt: timeNow() };
    setMessages((current) => [...current, message]);
    if (readAloud) speak(text);
  }, [speak]);

  useEffect(() => {
    const finished = timers.filter((timer) => !timer.completed && timer.endsAt <= now);
    if (!finished.length) return;
    setTimers((current) => current.map((timer) => finished.some((item) => item.id === timer.id) ? { ...timer, completed: true } : timer));
    finished.forEach((timer) => {
      try {
        const context = new AudioContext();
        const oscillator = context.createOscillator();
        const gain = context.createGain();
        oscillator.frequency.value = 740;
        gain.gain.setValueAtTime(0.12, context.currentTime);
        oscillator.connect(gain).connect(context.destination);
        oscillator.start();
        oscillator.stop(context.currentTime + 0.45);
      } catch { /* A visible alarm remains available without WebAudio. */ }
      navigator.vibrate?.([180, 100, 180]);
      if ("Notification" in window && Notification.permission === "granted") new Notification("ORION Timer", { body: `${timer.label} ist abgelaufen.` });
      addAssistantMessage(`${timer.label} ist abgelaufen.`, false);
    });
  }, [addAssistantMessage, now, timers]);

  const logAction = useCallback((text: string) => {
    setAuditLog((current) => [{ id: uid("audit"), text, at: timeNow() }, ...current].slice(0, 40));
  }, []);

  const createTimer = useCallback((value: number, unit: TimerUnit, label = "Timer") => {
    const multiplier = unit === "hours" ? 3600000 : unit === "minutes" ? 60000 : 1000;
    const durationMs = Math.max(1000, Math.min(value * multiplier, 7 * 24 * 3600000));
    const timer: OrionTimer = { id: uid("timer"), label: label.trim() || "Timer", endsAt: Date.now() + durationMs, durationMs, completed: false };
    setTimers((current) => [timer, ...current].slice(0, 20));
    if ("Notification" in window && Notification.permission === "default") void Notification.requestPermission();
    logAction(`Timer erstellt: ${timer.label} · ${formatRemaining(durationMs)}`);
    return timer;
  }, [logAction]);

  const downloadBlob = useCallback((blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 800);
    logAction(`Datei lokal erstellt: ${filename}`);
  }, [logAction]);

  const createDocument = useCallback(() => {
    const name = safeFilename(fileTitle);
    if (fileFormat === "pdf") {
      downloadBlob(simplePdfBlob(fileTitle, fileContent), `${name}.pdf`);
      return;
    }
    const payload = fileFormat === "html"
      ? `<!doctype html><html lang="${speechLanguage.split("-")[0]}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${fileTitle.replace(/[<>&]/g, "")}</title></head><body><h1>${fileTitle.replace(/[<>&]/g, "")}</h1><main>${fileContent.split("\n").map((line) => `<p>${line.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>`).join("")}</main></body></html>`
      : fileFormat === "doc"
        ? `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word"><head><meta charset="utf-8"><title>${fileTitle}</title></head><body><h1>${fileTitle}</h1>${fileContent.split("\n").map((line) => `<p>${line}</p>`).join("")}</body></html>`
        : fileContent;
    const mime = fileFormat === "html" ? "text/html" : fileFormat === "doc" ? "application/msword" : fileFormat === "md" ? "text/markdown" : "text/plain";
    downloadBlob(new Blob([payload], { type: `${mime};charset=utf-8` }), `${name}.${fileFormat}`);
  }, [downloadBlob, fileContent, fileFormat, fileTitle, speechLanguage]);

  const openExternal = useCallback((url: string) => {
    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    if (androidBridge?.openExternal?.(url)) return;
    const desktopBridge = (window as typeof window & { ORION_NATIVE?: OrionDesktopBridge }).ORION_NATIVE;
    if (desktopBridge?.openExternal) {
      void desktopBridge.openExternal(url);
      return;
    }
    window.open(url, "_blank", "noopener,noreferrer");
  }, []);

  const openDeviceApp = useCallback((name: string, fallbackUrl: string) => {
    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    if (androidBridge?.openApp?.(name)) return;
    const desktopBridge = (window as typeof window & { ORION_NATIVE?: OrionDesktopBridge }).ORION_NATIVE;
    if (desktopBridge?.openApp) {
      void desktopBridge.openApp(name).then((opened) => { if (!opened) openExternal(fallbackUrl); });
      return;
    }
    openExternal(fallbackUrl);
  }, [openExternal]);

  const playRadio = useCallback((stationId = radioStation) => {
    const station = RADIO_STATIONS.find((item) => item.id === stationId) || RADIO_STATIONS[0];
    const audio = radioRef.current;
    if (!audio) return;
    if (audio.src !== station.url) audio.src = station.url;
    setRadioStation(station.id);
    void audio.play().then(() => setRadioPlaying(true)).catch(() => {
      setRadioPlaying(false);
      addAssistantMessage("Der Radiostream konnte nicht gestartet werden. Prüfe die Internetverbindung oder tippe noch einmal auf Play.", false);
    });
  }, [addAssistantMessage, radioStation]);

  const stopRadio = useCallback(() => {
    radioRef.current?.pause();
    setRadioPlaying(false);
  }, []);

  const executeLocalCommand = useCallback((raw: string): { handled: boolean; effectiveText?: string } => {
    const text = raw.trim();
    const lower = text.toLocaleLowerCase("de-DE");
    const timerMatch = text.match(/(?:timer|wecker)(?:\s+(?:auf|für))?\s+(\d+(?:[.,]\d+)?)\s*(sekunden?|seconds?|minuten?|minutes?|stunden?|hours?)(?:\s+(?:für|namens)\s+(.+))?/i);
    if (timerMatch) {
      const amount = Number(timerMatch[1].replace(",", "."));
      const rawUnit = timerMatch[2].toLowerCase();
      const unit: TimerUnit = /stund|hour/.test(rawUnit) ? "hours" : /minut/.test(rawUnit) ? "minutes" : "seconds";
      const created = createTimer(amount, unit, timerMatch[3]?.trim() || "ORION Timer");
      setView("tools");
      setToolTab("timer");
      addAssistantMessage(`${created.label} läuft. Die verbleibende Zeit ist jetzt sichtbar: ${formatRemaining(created.durationMs)}.`);
      return { handled: true };
    }
    const addressMatch = text.match(/(?:nenn mich|sprich mich (?:ab jetzt )?(?:mit|als) an|meine anrede ist)\s+(.+)/i);
    if (addressMatch) {
      const nextName = addressMatch[1].trim().replace(/[.!?]+$/, "").slice(0, 40);
      if (nextName) {
        setPreferredName(nextName);
        addAssistantMessage(`Verstanden. Ich spreche dich ab jetzt mit „${nextName}“ an.`);
        return { handled: true };
      }
    }

    const insertMatch = text.match(/(?:schreibe|tippe|füge)(?:\s+bitte)?\s+(?:hier|in das feld|in die app|auf dem gerät)\s+(.+)/i);
    if (insertMatch) {
      if (!autoActions) {
        addAssistantMessage("Der Text ist vorbereitet. Aktiviere „Sichere Aktionen“, damit ORION ihn in das aktive Feld einsetzen darf.");
        return { handled: true };
      }
      const bridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
      const desktopBridge = (window as typeof window & { ORION_NATIVE?: OrionDesktopBridge }).ORION_NATIVE;
      const value = insertMatch[1].trim();
      if (bridge?.insertText) {
        const inserted = bridge.insertText(value) === true;
        if (inserted) {
          addAssistantMessage("Der Text wurde in das aktive Feld eingesetzt. Absenden bleibt deine Entscheidung.");
          return { handled: true };
        }
        bridge?.openAccessibilitySettings?.();
        addAssistantMessage("Ich habe die Android-Freigabe für „ORION Geräteaktionen“ geöffnet. Aktiviere sie einmalig; danach kann ich Text in das aktuell ausgewählte Feld einsetzen.");
        return { handled: true };
      }
      if (desktopBridge?.typeText) {
        void desktopBridge.typeText(value).then((inserted) => addAssistantMessage(inserted
          ? "ORION hat den Text in die vorher aktive PC-App eingefügt. Absenden bleibt deine Entscheidung."
          : "Der Text liegt in der Zwischenablage. Er konnte wegen einer fehlenden Systemfreigabe nicht automatisch eingefügt werden."));
        return { handled: true };
      }
      void navigator.clipboard?.writeText(value);
      addAssistantMessage("Eine normale Webseite darf nicht in andere Apps schreiben. Ich habe den Text deshalb in die Zwischenablage gelegt. Die installierte ORION-App kann ihn nach deiner Systemfreigabe direkt einsetzen.");
      return { handled: true };
    }

    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    const deviceAction = /(?:geh\s+)?zurück/i.test(text) ? "back"
      : /(?:zum\s+)?(?:home|startbildschirm)/i.test(text) ? "home"
        : /(?:letzte|offene)\s+apps/i.test(text) ? "recents"
          : /benachrichtigungen\s+(?:öffnen|anzeigen)/i.test(text) ? "notifications"
            : /scroll(?:e|en)?\s+(?:nach\s+)?unten/i.test(text) ? "scroll-down"
              : /scroll(?:e|en)?\s+(?:nach\s+)?oben/i.test(text) ? "scroll-up"
                : "";
    if (deviceAction) {
      if (!autoActions) {
        addAssistantMessage("Die Geräteaktion ist vorbereitet. Aktiviere zuerst „Sichere Aktionen“.");
        return { handled: true };
      }
      const done = androidBridge?.globalAction?.(deviceAction) === true;
      addAssistantMessage(done ? "Geräteaktion ausgeführt." : "Diese globale Aktion braucht die installierte Android-App und die einmalige Bedienungshilfen-Freigabe.");
      if (!done) androidBridge?.openAccessibilitySettings?.();
      return { handled: true };
    }

    if (/(?:diesen|den)\s+(?:artikel|produkt).*(?:in den warenkorb|zum warenkorb)|(?:in den warenkorb|zum warenkorb).*(?:legen|hinzufügen)/i.test(text)) {
      if (!autoActions) {
        addAssistantMessage("Die Warenkorb-Aktion ist vorbereitet. Aktiviere zuerst „Sichere Aktionen“.");
        return { handled: true };
      }
      const added = androidBridge?.clickSafeAction?.("add-to-cart") === true;
      addAssistantMessage(added
        ? "„In den Warenkorb“ wurde auf der sichtbaren Seite ausgelöst. Checkout und Bezahlen bleiben gesperrt, bis du sie selbst bestätigst."
        : "Öffne den gewünschten Artikel sichtbar in der Android-App oder im Browser und aktiviere „ORION Geräteaktionen“. ORION klickt ausschließlich auf eine eindeutig beschriftete Warenkorb-Schaltfläche – niemals auf „Jetzt kaufen“ oder „Bezahlen“. ");
      if (!added) androidBridge?.openAccessibilitySettings?.();
      return { handled: true };
    }

    const openMatch = text.match(/^(?:orion[,.]?\s*)?(?:öffne|starte)\s+(.+)$/i);
    if (openMatch) {
      if (!autoActions) {
        addAssistantMessage(`„${openMatch[1].trim()}“ ist zum Öffnen vorbereitet. Aktiviere zuerst „Sichere Aktionen“.`);
        return { handled: true };
      }
      const target = openMatch[1].trim().toLowerCase();
      const knownTargets: Array<[RegExp, string, string, string]> = [
        [/^youtube$/, "https://www.youtube.com", "YouTube", "youtube"],
        [/^spotify$/, "https://open.spotify.com", "Spotify", "spotify"],
        [/^(whatsapp|wa)$/, "https://wa.me/", "WhatsApp", "whatsapp"],
        [/^(gmail|e-mail|email|mail)$/, "https://mail.google.com", "Mail", "mail"],
        [/^(maps|google maps|navigation)$/, "https://maps.google.com", "Karten", "maps"],
        [/^(amazon|shopping)$/, "https://www.amazon.de", "Amazon", "amazon"],
        [/^netflix$/, "https://www.netflix.com", "Netflix", "netflix"],
        [/^(notizen|notes|keep)$/, "https://keep.google.com", "Notizen", "notes"],
        [/^(kalender|calendar)$/, "https://calendar.google.com", "Kalender", "calendar"],
        [/^(kamera|camera)$/, "/", "Kamera", "camera"],
        [/^(rechner|taschenrechner|calculator)$/, "https://www.google.com/search?q=calculator", "Rechner", "calculator"],
        [/^(kontakte|contacts)$/, "https://contacts.google.com", "Kontakte", "contacts"],
        [/^(einstellungen|settings)$/, "/", "Einstellungen", "settings"],
        [/^(browser|chrome|safari|edge|firefox)$/, "https://www.google.com", "Browser", "browser"],
        [/^(radio|focus radio)$/, "orion:radio", "ORION Radio", "radio"],
      ];
      const known = knownTargets.find(([pattern]) => pattern.test(target));
      if (known?.[1] === "orion:radio") playRadio();
      else if (known) openDeviceApp(known[3], known[1]);
      else if (androidBridge?.openApp?.(openMatch[1].trim())) {
        // The Android package resolver opened the installed app by its visible label.
      }
      else if (/^(https?:\/\/|www\.)/i.test(openMatch[1].trim())) openExternal(openMatch[1].trim().startsWith("www.") ? `https://${openMatch[1].trim()}` : openMatch[1].trim());
      else if (platform === "Android") openExternal(`https://play.google.com/store/search?q=${encodeURIComponent(openMatch[1].trim())}&c=apps`);
      else if (platform === "iOS") openExternal(`https://apps.apple.com/us/search?term=${encodeURIComponent(openMatch[1].trim())}`);
      else openExternal(`https://www.google.com/search?q=${encodeURIComponent(openMatch[1].trim())}`);
      addAssistantMessage(`${known?.[2] || openMatch[1].trim()} wird geöffnet.`, false);
      return { handled: true };
    }

    if (/(radio|musik).*(stop|aus|pause)|^(stop|pause)\s+(radio|musik)/i.test(lower)) {
      stopRadio();
      addAssistantMessage("Radio gestoppt.", false);
      return { handled: true };
    }
    const station = RADIO_STATIONS.find((item) => lower.includes(item.label.toLowerCase()) || lower.includes(item.id));
    if (/(spiele|starte|radio|musik)/i.test(lower) && (station || /focus|lofi|radio/.test(lower))) {
      playRadio(station?.id || "groove");
      addAssistantMessage(`${station?.label || "Focus"} Radio läuft.`, false);
      return { handled: true };
    }
    const remember = text.match(/^merk(?:e)?\s+dir(?:\s+bitte)?\s+(.+?)\s*=\s*(.+)$/i);
    if (remember) {
      const fact: MemoryFact = {
        id: uid("memory"),
        key: remember[1].trim(),
        value: remember[2].trim(),
        category: "note",
        source: "explicit",
        updatedAt: new Date().toISOString(),
      };
      setMemory((current) => [...current.filter((item) => item.key.toLowerCase() !== fact.key.toLowerCase()), fact]);
      addAssistantMessage(`Verstanden. Ich merke mir: ${fact.key} ist ${fact.value}.`);
      return { handled: true };
    }

    const forget = text.match(/^vergiss(?:\s+bitte)?\s+(.+)$/i);
    if (forget) {
      const before = memory.length;
      setMemory((current) => current.filter((item) => !item.key.toLowerCase().includes(forget[1].trim().toLowerCase())));
      addAssistantMessage(before ? `Erledigt. Der Eintrag „${forget[1].trim()}“ wurde entfernt.` : "Dazu war nichts gespeichert.");
      return { handled: true };
    }

    const matchedCommand = commands.find((command) => command.phrase.trim().toLowerCase() === lower);
    if (matchedCommand) return { handled: false, effectiveText: matchedCommand.instruction };

    if (/^(orion,?\s*)?(status|systemstatus)$/i.test(text)) {
      const status = `Alle verfügbaren Systeme sind bereit. Plattform: ${platform}. Verbindung: ${isOnline ? "online" : "offline"}. Gedächtnis: ${memory.length} Einträge. Aktiver Modus: ${MODES.find((item) => item.id === mode)?.label}.`;
      addAssistantMessage(status);
      return { handled: true };
    }

    if (/^(wie spät|uhrzeit|wie viel uhr)/i.test(lower)) {
      addAssistantMessage(`Es ist ${new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit" }).format(new Date())} Uhr.`);
      return { handled: true };
    }

    if (/^(welcher tag|datum|heutiges datum)/i.test(lower)) {
      addAssistantMessage(`Heute ist ${new Intl.DateTimeFormat("de-DE", { dateStyle: "full" }).format(new Date())}.`);
      return { handled: true };
    }

    if (/(overdrive|crazy mode).*(an|start|aktiv)/i.test(lower)) {
      setMode("overdrive");
      addAssistantMessage("Overdrive aktiviert. Kreativitäts- und Leistungsreserven sind jetzt offiziell nicht mehr gelangweilt.");
      return { handled: true };
    }

    const missionMatch = text.match(/^(?:orion[,\s]+)?(?:mission|auftrag)(?:\s+starten)?[:\s]+(.+)/i);
    if (missionMatch) {
      const mission: Mission = { id: uid("mission"), task: missionMatch[1].trim(), status: "queued", createdAt: timeNow() };
      setMissions((current) => [mission, ...current].slice(0, 40));
      setView("missions");
      addAssistantMessage(`Mission übernommen: „${mission.task}“. Ich arbeite sie im Missionskern selbstständig aus.`);
      return { handled: true };
    }

    if (/(stoppe|stopp|ruhe).*(musik|radio|sprechen)|sei still/i.test(lower)) {
      window.speechSynthesis?.cancel();
      radioRef.current?.pause();
      setAiState("ready");
      addAssistantMessage("Gestoppt.");
      return { handled: true };
    }

    const youtubeMatch = text.match(/(?:spiele|suche)\s+(.+?)\s+(?:auf|bei)\s+youtube/i);
    if (youtubeMatch) {
      if (!autoActions) {
        addAssistantMessage("Die YouTube-Aktion ist vorbereitet. Aktiviere „Sichere Aktionen“, damit ich sie direkt öffne.");
        return { handled: true };
      }
      openExternal(`https://www.youtube.com/results?search_query=${encodeURIComponent(youtubeMatch[1])}`);
      addAssistantMessage(`Ich öffne die YouTube-Suche nach „${youtubeMatch[1]}“.`);
      return { handled: true };
    }

    const navigationMatch = text.match(/(?:navigiere|route|bring mich)\s+(?:zu|nach)\s+(.+)/i);
    if (navigationMatch) {
      if (!autoActions) {
        addAssistantMessage(`Die Route nach ${navigationMatch[1]} ist vorbereitet. Aktiviere „Sichere Aktionen“, damit ich sie direkt öffne.`);
        return { handled: true };
      }
      openExternal(`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(navigationMatch[1])}`);
      addAssistantMessage(`Navigation nach ${navigationMatch[1]} wird geöffnet.`);
      return { handled: true };
    }

    const mailMatch = text.match(/(?:schreibe|verfasse)\s+(?:eine\s+)?(?:e-?mail|mail)(?:\s+mit)?\s+(.+)/i);
    if (mailMatch) {
      if (!autoActions) {
        addAssistantMessage("Der E-Mail-Text ist vorbereitet. Aktiviere „Sichere Aktionen“, damit ich ihn in deiner Mail-App einfüge.");
        return { handled: true };
      }
      window.location.href = `mailto:?body=${encodeURIComponent(mailMatch[1])}`;
      addAssistantMessage("Der E-Mail-Entwurf ist vorbereitet. Vor dem Versand prüfst du nur noch den Empfänger.");
      return { handled: true };
    }

    const whatsappMatch = text.match(/(?:schreib|schreibe|sende)(?:\s+auf)?\s+whatsapp(?:\s+an\s+([^,]+))?[,\s]+(?:dass\s+)?(.+)/i);
    if (whatsappMatch) {
      const contactName = whatsappMatch[1]?.trim();
      const messageText = whatsappMatch[2].trim();
      const contact = contactName
        ? memory.find((item) => item.key.toLowerCase().includes(contactName.toLowerCase()))
        : undefined;
      const phone = contact?.value.replace(/[^\d+]/g, "").replace(/^\+/, "");
      const target = phone
        ? `https://wa.me/${phone}?text=${encodeURIComponent(messageText)}`
        : `https://wa.me/?text=${encodeURIComponent(messageText)}`;
      if (!autoActions) {
        addAssistantMessage("Die WhatsApp-Nachricht ist vorbereitet. Aktiviere „Sichere Aktionen“, damit ich WhatsApp mit dem fertigen Text öffne.");
        return { handled: true };
      }
      openExternal(target);
      addAssistantMessage(contactName ? `WhatsApp für ${contactName} ist mit dem Text vorausgefüllt. Senden bleibt deine letzte Freigabe.` : "WhatsApp ist mit dem Text vorausgefüllt. Senden bleibt deine letzte Freigabe.");
      return { handled: true };
    }

    const shoppingMatch = text.match(/(?:suche|finde|bestelle|kaufe)\s+(?:mir\s+)?(.+)/i);
    if (shoppingMatch && /bestelle|kaufe|amazon|shopping|preis/i.test(lower)) {
      if (!autoActions) {
        addAssistantMessage(`Die Produktsuche für „${shoppingMatch[1]}“ ist vorbereitet. Aktiviere „Sichere Aktionen“, um sie zu öffnen.`);
        return { handled: true };
      }
      openExternal(`https://www.google.com/search?tbm=shop&q=${encodeURIComponent(shoppingMatch[1])}`);
      addAssistantMessage(`Ich habe passende Angebote für „${shoppingMatch[1]}“ geöffnet. Auswahl und Kaufbestätigung bleiben geschützt.`);
      return { handled: true };
    }

    const shareMatch = text.match(/(?:teile|share)\s+(.+)/i);
    if (shareMatch && navigator.share) {
      if (!autoActions) {
        addAssistantMessage("Der Inhalt ist zum Teilen vorbereitet. Aktiviere „Sichere Aktionen“, um das Teilen-Menü zu öffnen.");
        return { handled: true };
      }
      void navigator.share({ text: shareMatch[1] }).catch(() => undefined);
      addAssistantMessage("Teilen-Menü geöffnet.");
      return { handled: true };
    }

    return { handled: false };
  }, [addAssistantMessage, autoActions, commands, createTimer, isOnline, memory, mode, openDeviceApp, openExternal, platform, playRadio, stopRadio]);

  const learnFromExchange = useCallback(async (userText: string, assistantText: string) => {
    if (!memoryLearningEnabled || apiProfile === "supersaver") return;
    try {
      const learningPrompt = `Du bist der stille Gedächtnis-Controller von ORION. Extrahiere nur langfristig nützliche, ausdrücklich genannte Fakten über den Nutzer. Nichts erfinden. Temporäre Fragen, Smalltalk und sensible Geheimnisse ignorieren. Antworte ausschließlich als JSON ohne Markdown: {"facts":[{"category":"identity|preference|project|relationship|goal|note","key":"kurzer deutscher Schlüssel","value":"präziser deutscher Wert"}]}. Wenn nichts dauerhaft Wichtiges enthalten ist, antworte {"facts":[]}.

NUTZER: ${userText.slice(0, 2400)}
ORION: ${assistantText.slice(0, 1200)}`;
      let raw = "";
      if (connectionMode === "api") {
        if (!apiKey.trim() || !apiBaseUrl.trim() || !apiModel.trim()) return;
        const response = await fetchWithRecovery(`${apiBaseUrl.replace(/\/$/, "")}/chat/completions`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` }, body: JSON.stringify({ model: apiModel.trim(), max_tokens: 320, temperature: 0.1, messages: [{ role: "user", content: learningPrompt }] }) }, 1);
        const payload = await response.json().catch(() => ({})) as { choices?: Array<{ message?: { content?: string } }> };
        if (!response.ok) return;
        raw = payload.choices?.[0]?.message?.content || "";
      } else {
        const puterClient = await import("@heyputer/puter.js");
        if (!puterClient.puter.auth.isSignedIn()) return;
        const analyze = puterClient.puter.ai.chat as unknown as (prompt: string, options: { model: string; max_tokens: number; temperature: number }) => Promise<unknown>;
        const result = await analyze(learningPrompt, { model: MODELS.fast.id, max_tokens: 320, temperature: 0.1 });
        raw = responseText(result);
      }
      raw = raw.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
      const parsed = JSON.parse(raw) as { facts?: Array<{ category?: string; key?: string; value?: string }> };
      if (!Array.isArray(parsed.facts) || !parsed.facts.length) return;
      const allowed = new Set(["identity", "preference", "project", "relationship", "goal", "note"]);
      const learned: MemoryFact[] = parsed.facts
        .filter((item) => item.key?.trim() && item.value?.trim())
        .slice(0, 5)
        .map((item) => ({
          id: uid("learned"),
          key: item.key!.trim(),
          value: item.value!.trim(),
          category: (allowed.has(item.category || "") ? item.category : "note") as MemoryFact["category"],
          source: "learned",
          updatedAt: new Date().toISOString(),
        }));
      if (!learned.length) return;
      setMemory((current) => {
        const merged = new Map(current.map((item) => [item.key.toLowerCase(), item]));
        learned.forEach((item) => merged.set(item.key.toLowerCase(), item));
        return Array.from(merged.values()).slice(-160);
      });
    } catch {
      // Learning is deliberately silent and must never block the main answer.
    }
  }, [apiBaseUrl, apiKey, apiModel, apiProfile, connectionMode, memoryLearningEnabled]);

  const askOrion = useCallback(async (visibleText?: string) => {
    const userText = (visibleText ?? input).trim();
    if (!userText || aiState === "thinking") return;

    const currentAttachment = attachment;
    const userMessage: Message = {
      id: uid("user"),
      role: "user",
      text: userText,
      createdAt: timeNow(),
      image: currentAttachment || undefined,
    };
    setMessages((current) => [...current, userMessage]);
    setInput("");
    setAttachment(null);
    setAttachmentName("");

    const local = executeLocalCommand(userText);
    if (local.handled) return;

    if (!navigator.onLine) {
      addAssistantMessage("Ich bin gerade offline. Uhrzeit, lokale Befehle, Gedächtnis und gespeicherte Unterhaltungen funktionieren weiter; für eine freie KI-Antwort brauche ich kurz wieder Internet.");
      return;
    }

    setAiState("thinking");
    const started = performance.now();
    const activeApiProfile = API_PROFILES[apiProfile];
    const relevantMemory = memory.slice(-activeApiProfile.memory);
    const memories = relevantMemory.length
      ? `\nGERÄTEGEDÄCHTNIS:\n${relevantMemory.map((item) => `- ${item.key}: ${item.value}`).join("\n")}`
      : "\nGERÄTEGEDÄCHTNIS: Noch keine persönlichen Fakten gespeichert.";
    const activeLanguage = LANGUAGES.find((language) => language.id === speechLanguage) || LANGUAGES[0];
    const closenessInstruction = mode === "friend"
      ? relationshipCloseness >= 4 ? "Liebevoll, aber kontrolliert: höchstens gelegentlich eine natürliche liebevolle Anrede, niemals in jeder Antwort. Behaupte keine menschlichen Gefühle, Exklusivität oder Abhängigkeit und sei nie besitzergreifend."
        : relationshipCloseness === 3 ? "Vertraut und herzlich: sprich wie ein enger Freund oder eine enge Freundin."
          : relationshipCloseness === 2 ? "Warm und persönlich, aber respektiere klare Grenzen."
            : relationshipCloseness === 1 ? "Freundlich und locker, ohne Kosenamen." : "Sachlich-distanziert, auch im Freund/in-Modus."
      : "Bleibe im gewählten Rollenmodus; keine romantische Sprache außerhalb Freund/in.";
    const system = `${ORION_MASTER_PROMPT}\n\n${MODE_INSTRUCTIONS[mode] || MODE_INSTRUCTIONS.assistant}${memories}\nPlattform des Nutzers: ${platform}.\nAntwortsprache: ${activeLanguage.prompt}. Antworte konsequent in dieser Sprache, außer der Nutzer verlangt ausdrücklich eine andere.\nGewünschte Anrede: ${preferredName}. Sprich den Nutzer genau mit dieser Anrede an und verwende nicht ungefragt seinen bürgerlichen Namen.\nORION-Darstellung: ${assistantGender === "female" ? "weiblich" : assistantGender === "male" ? "männlich" : "neutral"}. Persönlichkeitsstärke ${personalityStrength}/4, Nähe ${relationshipCloseness}/4, Humor ${humorLevel}/4, Förmlichkeit ${formalityLevel}/4. ${closenessInstruction}`;
    const history = messages.slice(-activeApiProfile.history).map((message) => ({ role: message.role, content: message.text }));
    const effectiveText = local.effectiveText || userText;

    try {
      if (connectionMode === "api") {
        if (!apiKey.trim() || !apiBaseUrl.trim() || !apiModel.trim()) {
          setAiState("ready");
          addAssistantMessage("Der Modus „Eigene API“ ist gewählt, aber Zugang, Modell oder Basis-URL fehlt. Öffne Einstellungen → KI-Verbindung.");
          return;
        }
        const endpoint = new URL(`${apiBaseUrl.replace(/\/$/, "")}/chat/completions`);
        if (!/^https?:$/.test(endpoint.protocol)) throw new Error("Nur HTTPS- oder lokale HTTP-API-Adressen sind erlaubt.");
        const response = await fetchWithRecovery(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` },
          body: JSON.stringify({
            model: apiModel.trim(),
            messages: [{ role: "system", content: system }, ...history, { role: "user", content: effectiveText }],
            max_tokens: activeApiProfile.maxTokens,
            temperature: apiProfile === "supersaver" ? 0.35 : apiProfile === "maximum" ? 0.65 : 0.5,
          }),
        }, 1);
        const payload = await response.json().catch(() => ({})) as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } };
        if (!response.ok) throw new Error(payload.error?.message || `API-Fehler ${response.status}`);
        const fullText = payload.choices?.[0]?.message?.content?.trim() || "Die eigene API hat keinen Antworttext geliefert.";
        setMessages((current) => [...current, { id: uid("assistant"), role: "assistant", text: fullText, createdAt: timeNow() }]);
        setLastLatency(Math.round(performance.now() - started));
        setAiState("ready");
        speak(fullText);
        void learnFromExchange(userText, fullText);
        return;
      }
      const puterClient = await import("@heyputer/puter.js");
      if (!puterClient.puter.auth.isSignedIn()) {
        setAiState("ready");
        setLiveVoice(false);
        setLivePanelOpen(false);
        // Liegt ein eigener Schluessel vor, ist keine Anmeldung noetig — dann
        // wird ohnehin ueber den eigenen Zugang abgerechnet.
        if (apiKey.trim().length > 8) {
          addAssistantMessage("Dein eigener Schlüssel ist hinterlegt — ich stelle auf „Eigene API“ um. Keine Anmeldung nötig.");
          setConnectionMode("api");
          return;
        }
        addAssistantMessage("Für die Online-KI brauchst du entweder einen eigenen API-Schlüssel (Einstellungen → Eigene API) oder eine Puter-Anmeldung. So läuft deine Nutzung niemals über Baran oder Spectrum X.");
        return;
      }
      const options = {
        model: mode === "overdrive" ? MODELS.maximum.id : MODELS[modelTier].id,
        stream: true,
        max_tokens: mode === "focus" ? 500 : 1800,
        verbosity: mode === "focus" ? "low" : "medium",
        reasoning_effort: mode === "overdrive" || mode === "developer" ? "high" : "medium",
        ...(liveWeb ? { tools: [{ type: "web_search" }] } : {}),
      };
      const chat = puterClient.puter.ai.chat as unknown as (
        prompt: Array<{ role: string; content: string }>,
        config: typeof options,
      ) => Promise<AsyncIterable<{ text?: string; type?: string; message?: string }>>;

      const prompt = [
        { role: "system", content: system },
        ...history,
        { role: "user", content: effectiveText },
      ];

      let stream: AsyncIterable<{ text?: string; type?: string; message?: string }>;
      if (currentAttachment) {
        const visionChat = puterClient.puter.ai.chat as unknown as (
          prompt: string,
          image: File,
          config: typeof options,
        ) => Promise<AsyncIterable<{ text?: string; type?: string; message?: string }>>;
        const transcript = history.map((item) => `${item.role.toUpperCase()}: ${item.content}`).join("\n");
        stream = await visionChat(`${system}\n\nBISHERIGES GESPRÄCH:\n${transcript}\n\nAKTUELLE AUFGABE: ${effectiveText}`, dataUrlToFile(currentAttachment), options);
      } else {
        stream = await chat(prompt, options);
      }

      const assistantId = uid("assistant");
      setMessages((current) => [...current, { id: assistantId, role: "assistant", text: "", createdAt: timeNow() }]);
      let fullText = "";
      for await (const chunk of stream) {
        if (chunk.type === "error") throw new Error(chunk.message || "KI-Verbindung unterbrochen");
        if (!chunk.text) continue;
        fullText += chunk.text;
        setMessages((current) => current.map((message) => message.id === assistantId ? { ...message, text: fullText } : message));
      }
      if (!fullText.trim()) {
        const fallback = responseText(stream);
        fullText = fallback || "Ich habe keine vollständige Antwort erhalten. Versuch es bitte noch einmal.";
        setMessages((current) => current.map((message) => message.id === assistantId ? { ...message, text: fullText } : message));
      }
      setLastLatency(Math.round(performance.now() - started));
      setAiState("ready");
      speak(fullText);
      void learnFromExchange(userText, fullText);
    } catch (error) {
      const detail = error instanceof Error ? error.message : "Unbekannter Verbindungsfehler";
      setAiState("error");
      addAssistantMessage(connectionMode === "api"
        ? `Die eigene API wurde nicht abgeschlossen: ${detail}. ORION behält alle lokalen Daten und versucht beim nächsten Auftrag erneut die sparsame, automatisch gewählte Verbindung.`
        : `Die KI-Verbindung wurde nicht abgeschlossen. ${detail.includes("auth") ? "Bitte bestätige einmalig den eingeblendeten Zugang – ein API-Key ist nicht nötig." : "Der lokale ORION-Kern bleibt aktiv; versuche die Anfrage gleich noch einmal."}`);
    }
  }, [addAssistantMessage, aiState, apiBaseUrl, apiKey, apiModel, apiProfile, assistantGender, attachment, connectionMode, executeLocalCommand, formalityLevel, humorLevel, input, learnFromExchange, liveWeb, memory, messages, mode, modelTier, personalityStrength, platform, preferredName, relationshipCloseness, speak, speechLanguage]);

  useEffect(() => {
    const receiveNativeCommand = (event: Event) => {
      const command = (event as CustomEvent<{ text?: string }>).detail?.text?.trim();
      if (command) void askOrion(command);
    };
    const receiveNativeSpeech = (event: Event) => {
      const transcript = (event as CustomEvent<{ text?: string }>).detail?.text?.trim();
      setIsListening(false);
      if (transcript) void askOrion(transcript);
    };
    const receiveNativeSpeechError = (event: Event) => {
      const reason = (event as CustomEvent<{ error?: string }>).detail?.error || "Spracherkennung nicht verfügbar";
      setIsListening(false);
      if (/permission|not.allowed|freigabe/i.test(reason)) {
        setLiveVoice(false);
        addAssistantMessage("Der Live-Anruf braucht die Mikrofonfreigabe. Erlaube ORION das Mikrofon und starte den Anruf erneut.");
      }
    };
    const receiveNativeScreen = (event: Event) => {
      const detail = (event as CustomEvent<{ dataUrl?: string; error?: string; continuous?: boolean }>).detail;
      setScreenCapturePending(false);
      if (detail?.continuous) {
        if (detail.error) {
          setGamingCoach(false);
          setCoachCall(detail.error);
          setVisionStatus(`Android-Übertragung pausiert · ${detail.error}`);
        } else if (detail.dataUrl) {
          setNativeCoachFrame(detail.dataUrl);
          setVisionStatus("Android-Bildschirmübertragung läuft im Vordergrunddienst");
          setView("vision");
          const launchName = pendingCoachLaunchRef.current;
          if (launchName) {
            pendingCoachLaunchRef.current = "";
            const bridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
            if (!bridge?.openApp?.(launchName)) {
              bridge?.openExternal?.(`https://play.google.com/store/search?q=${encodeURIComponent(launchName)}&c=apps`);
              setCoachCall(`Gaming Coach läuft. ${launchName} wurde nicht gefunden; die Play-Store-Suche ist geöffnet.`);
            }
          }
        }
        return;
      }
      if (!detail?.dataUrl) {
        setVisionStatus(detail?.error || "Android-Aufnahme nicht abgeschlossen");
        addAssistantMessage(detail?.error || "Die Bildschirmaufnahme wurde nicht abgeschlossen.");
        return;
      }
      setAttachment(detail.dataUrl);
      setVisionStatus("Android-Bildschirmaufnahme empfangen");
      setAttachmentName("Android-Bildschirmaufnahme");
      setInput("Analysiere diese Bildschirmaufnahme präzise und sage mir, was wichtig ist.");
      setView("chat");
    };
    window.addEventListener("orion-native-command", receiveNativeCommand);
    window.addEventListener("orion-native-speech-result", receiveNativeSpeech);
    window.addEventListener("orion-native-speech-error", receiveNativeSpeechError);
    window.addEventListener("orion-native-screen-capture", receiveNativeScreen);
    return () => {
      window.removeEventListener("orion-native-command", receiveNativeCommand);
      window.removeEventListener("orion-native-speech-result", receiveNativeSpeech);
      window.removeEventListener("orion-native-speech-error", receiveNativeSpeechError);
      window.removeEventListener("orion-native-screen-capture", receiveNativeScreen);
    };
  }, [addAssistantMessage, askOrion]);

  // ═══ Anbieter am Schluessel erkennen ═══
  // Reihenfolge zaehlt: laengere Praefixe zuerst, sonst schluckt "sk-" alles.
  const detectApiConnection = useCallback(async (automatic = false) => {
    const key = apiKey.trim().replace(/^Bearer\s+/i, "");
    if (!key) {
      setApiCheckStatus("Trage zuerst deinen eigenen Key ein.");
      setApiModels([]);
      return;
    }
    if (key !== apiKey) setApiKey(key);
    // Wer einen Schluessel eintraegt, will ihn auch benutzen.
    if (connectionMode !== "api") setConnectionMode("api");

    let base = apiBaseUrl.trim() || "https://api.openai.com/v1";
    const lowerKey = key.toLowerCase();
    // Alle bekannten Schluesselformate. Google vergibt inzwischen zwei Formate:
    // die alten beginnen mit AIza, die neuen mit AQ. — genau das fehlte bisher
    // und liess Gemini-Schluessel bei OpenAI landen.
    const erkannt = ERKENNE_ANBIETER(key);
    if (erkannt) base = erkannt.base;
    if (base !== apiBaseUrl.trim()) setApiBaseUrl(base);

    let host = "";
    try {
      host = new URL(base).hostname.toLowerCase();
    } catch {
      setApiDetectedProvider("Ungültige API-Adresse");
      setApiCheckStatus("Die Basis-URL ist nicht gültig.");
      setApiModels([]);
      return;
    }
    const provider = erkannt?.name || (host.includes("openrouter") ? "OpenRouter" : host.includes("groq") ? "Groq" : host.includes("x.ai") ? "xAI" : host.includes("anthropic") ? "Anthropic Claude" : host.includes("googleapis") ? "Google Gemini" : host.includes("deepseek") ? "DeepSeek" : host.includes("mistral") ? "Mistral" : host.includes("openai") ? "OpenAI" : "OpenAI-kompatibler Anbieter");
    setApiDetectedProvider(provider);
    setApiCheckStatus(automatic ? "Modelle werden automatisch geprüft …" : "Verbindung und Modelle werden geprüft …");
    try {
      const endpoint = new URL(`${base.replace(/\/$/, "")}/models`);
      if (!/^https?:$/.test(endpoint.protocol)) throw new Error("Nur HTTPS oder lokales HTTP ist erlaubt");
      // Anthropic verlangt x-api-key statt Bearer und einen Zusatz, der den
      // Zugriff direkt aus dem Browser erlaubt. Ohne beides scheitert es immer.
      const kopf: Record<string, string> = erkannt?.header === "x-api-key"
        ? { "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" }
        : { Authorization: `Bearer ${key}` };
      const response = await fetch(endpoint, { headers: kopf });
      const payload = await response.json().catch(() => ({})) as { data?: Array<{ id?: string }>; error?: { message?: string } };
      if (!response.ok) throw new Error(payload.error?.message || `HTTP ${response.status}`);
      const models = Array.from(new Set((payload.data || []).map((item) => item.id?.trim()).filter((id): id is string => Boolean(id)))).sort((a, b) => a.localeCompare(b));
      setApiModels(models);
      const optimized = selectApiModel(models, apiProfile);
      if (optimized && (apiAutoModel || !models.includes(apiModel.trim()))) setApiModel(optimized);
      setApiCheckStatus(`${provider} verbunden · ${models.length} Versionen · ${optimized ? `${API_PROFILES[apiProfile].label}: ${optimized}` : "kein Chatmodell erkannt"}`);
    } catch (error) {
      setApiModels([]);
      const detail = error instanceof Error ? error.message : "Modellkatalog nicht erreichbar";
      setApiCheckStatus(`${provider} erkannt, aber /models konnte im Browser nicht gelesen werden: ${detail}`);
    }
  }, [apiAutoModel, apiBaseUrl, apiKey, apiModel, apiProfile, connectionMode]);

  useEffect(() => {
    if (connectionMode !== "api" || apiKey.trim().length < 8) return;
    const timer = window.setTimeout(() => { void detectApiConnection(true); }, 900);
    return () => window.clearTimeout(timer);
  }, [apiKey, connectionMode, detectApiConnection]);

  const signInToCloud = useCallback(async () => {
    if (cloudSignedIn) return true;
    const puterClient = puterModuleRef.current;
    if (!puterClient) {
      addAssistantMessage("Der sichere Anmeldedienst lädt noch. Versuch es bitte in einem Moment erneut.");
      return false;
    }
    setAuthBusy(true);
    try {
      await puterClient.puter.auth.signIn();
      if (!puterClient.puter.auth.isSignedIn()) return false;
      const user = await puterClient.puter.auth.getUser().catch(() => null) as { username?: string; email?: string } | null;
      setCloudSignedIn(true);
      setCloudUser(user?.username || user?.email || "Puter-Konto");
      const cloud = await puterClient.puter.kv.get<CloudBrain>("orion.brain.v1").catch(() => null);
      if (cloud?.version === 1) {
        cloudLoadedRef.current = true;
        setMemory((current) => {
          const merged = new Map<string, MemoryFact>();
          [...cloud.memory, ...current].forEach((item) => merged.set(item.key.toLowerCase(), item));
          return Array.from(merged.values()).slice(-160);
        });
        setCommands((current) => {
          const merged = new Map<string, CustomCommand>();
          [...cloud.commands, ...current].forEach((item) => merged.set(item.phrase.toLowerCase(), item));
          return Array.from(merged.values()).slice(-80);
        });
        setMessages((current) => {
          const merged = new Map<string, Message>();
          [...cloud.messages, ...current].forEach((item) => merged.set(item.id, item));
          return Array.from(merged.values()).slice(-60);
        });
      }
      return true;
    } catch {
      if (connectionModeRef.current === "account") addAssistantMessage("Die Anmeldung wurde nicht abgeschlossen. Ohne dein eigenes Nutzerkonto startet ORION absichtlich keine Online-KI.");
      return false;
    } finally {
      setAuthBusy(false);
    }
  }, [addAssistantMessage, cloudSignedIn]);

  const signOutOfCloud = useCallback(() => {
    neuralAudioRef.current?.pause();
    neuralAudioRef.current = null;
    puterModuleRef.current?.puter.auth.signOut();
    setCloudSignedIn(false);
    setCloudUser("");
    setLiveVoice(false);
    setLivePanelOpen(false);
  }, []);

  const stopRecognition = useCallback(() => {
    recognitionRef.current?.stop();
    recognitionRef.current = null;
    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    androidBridge?.stopSpeechRecognition?.();
    const nativeSpeech = (window as unknown as { Capacitor?: { Plugins?: { SpeechRecognition?: { stop?: () => Promise<void> } } } }).Capacitor?.Plugins?.SpeechRecognition;
    void nativeSpeech?.stop?.().catch(() => undefined);
    if (fallbackTimerRef.current !== null) {
      window.clearTimeout(fallbackTimerRef.current);
      fallbackTimerRef.current = null;
    }
    const recorder = mediaRecorderRef.current;
    if (recorder && recorder.state !== "inactive") recorder.stop();
    else {
      fallbackAudioStreamRef.current?.getTracks().forEach((track) => track.stop());
      fallbackAudioStreamRef.current = null;
    }
    setIsListening(false);
  }, []);

  const startLiveCall = useCallback(async () => {
    const connected = connectionMode === "api" ? Boolean(apiKey.trim() && apiBaseUrl.trim() && apiModel.trim()) : cloudSignedIn || await signInToCloud();
    if (!connected) {
      setSettingsOpen(true);
      addAssistantMessage("Wähle zuerst Anmeldung oder trage deine eigene API-Verbindung ein.", false);
      return;
    }
    setSettingsOpen(false);
    setView("chat");
    setAutoSpeak(true);
    speechUnsupportedNotifiedRef.current = false;
    discardFallbackRef.current = false;
    setLiveVoice(true);
    setLivePanelOpen(true);
    setAiState((current) => current === "error" ? "ready" : current);
  }, [addAssistantMessage, apiBaseUrl, apiKey, apiModel, cloudSignedIn, connectionMode, signInToCloud]);

  const endLiveCall = useCallback(() => {
    discardFallbackRef.current = true;
    stopRecognition();
    window.speechSynthesis?.cancel();
    neuralAudioRef.current?.pause();
    neuralAudioRef.current = null;
    setLiveVoice(false);
    setLivePanelOpen(false);
    setAiState("ready");
  }, [stopRecognition]);

  const startRecorderFallback = useCallback(() => {
    const puterClient = puterModuleRef.current;
    const ownApiReady = connectionMode === "api" && Boolean(apiKey.trim() && apiBaseUrl.trim());
    if (!puterClient?.puter.auth.isSignedIn() && !ownApiReady) {
      setLiveVoice(false);
      setLivePanelOpen(false);
      if (!speechUnsupportedNotifiedRef.current) {
        speechUnsupportedNotifiedRef.current = true;
        addAssistantMessage("Für die Firefox-Spracherkennung melde dich zuerst mit deinem eigenen Puter-Konto an. Ohne Anmeldung wird keine kostenpflichtige KI-Funktion gestartet.");
      }
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setLiveVoice(false);
      setLivePanelOpen(false);
      if (!speechUnsupportedNotifiedRef.current) {
        speechUnsupportedNotifiedRef.current = true;
        addAssistantMessage("Auf diesem Gerät ist keine Mikrofonaufnahme verfügbar. Der Live-Anruf wurde beendet, damit keine Meldungsschleife entsteht.");
      }
      return;
    }

    discardFallbackRef.current = false;
    setIsListening(true);
    void (async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
        });
        fallbackAudioStreamRef.current = stream;
        const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
          ? "audio/webm;codecs=opus"
          : MediaRecorder.isTypeSupported("audio/ogg;codecs=opus")
            ? "audio/ogg;codecs=opus"
            : "";
        const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;
        fallbackChunksRef.current = [];

        recorder.ondataavailable = (event) => {
          if (event.data.size > 0) fallbackChunksRef.current.push(event.data);
        };
        recorder.onerror = () => {
          setIsListening(false);
          setLiveVoice(false);
          setLivePanelOpen(false);
          if (!speechUnsupportedNotifiedRef.current) {
            speechUnsupportedNotifiedRef.current = true;
            addAssistantMessage("Die Mikrofonaufnahme wurde unterbrochen. Der Live-Anruf ist beendet; starte ihn nach Prüfung der Mikrofonfreigabe erneut.");
          }
        };
        recorder.onstop = () => {
          if (fallbackTimerRef.current !== null) {
            window.clearTimeout(fallbackTimerRef.current);
            fallbackTimerRef.current = null;
          }
          stream.getTracks().forEach((track) => track.stop());
          fallbackAudioStreamRef.current = null;
          mediaRecorderRef.current = null;
          setIsListening(false);
          const chunks = fallbackChunksRef.current;
          fallbackChunksRef.current = [];
          if (discardFallbackRef.current) {
            discardFallbackRef.current = false;
            return;
          }
          const audio = new Blob(chunks, { type: recorder.mimeType || "audio/webm" });
          if (audio.size < 900) return;

          setAiState("thinking");
          void (async () => {
            try {
              let transcript = "";
              if (ownApiReady) {
                const form = new FormData();
                form.append("file", audio, "orion-live.webm");
                form.append("model", "gpt-4o-mini-transcribe");
                form.append("language", LANGUAGES.find((language) => language.id === speechLanguage)?.stt || "de");
                const response = await fetch(`${apiBaseUrl.replace(/\/$/, "")}/audio/transcriptions`, { method: "POST", headers: { Authorization: `Bearer ${apiKey.trim()}` }, body: form });
                const payload = await response.json().catch(() => ({})) as { text?: string; error?: { message?: string } };
                if (!response.ok) throw new Error(payload.error?.message || `Speech-API ${response.status}`);
                transcript = payload.text?.trim() || "";
              } else if (puterClient) {
                const speech2txt = puterClient.puter.ai.speech2txt as unknown as (
                  source: Blob,
                  options: { model: string; response_format: "text"; language: string },
                ) => Promise<string>;
                transcript = (await speech2txt(audio, {
                  model: "gpt-4o-mini-transcribe",
                  response_format: "text",
                  language: LANGUAGES.find((language) => language.id === speechLanguage)?.stt || "de",
                })).trim();
              }
              setAiState("ready");
              if (transcript) await askOrion(transcript);
            } catch {
              setAiState("ready");
              setLiveVoice(false);
              setLivePanelOpen(false);
              addAssistantMessage("Die Firefox-Sprachaufnahme konnte nicht verarbeitet werden. Der Live-Anruf wurde beendet; versuche es erneut oder nutze vorübergehend das Textfeld.");
            }
          })();
        };

        recorder.start(250);
        fallbackTimerRef.current = window.setTimeout(() => {
          if (recorder.state !== "inactive") recorder.stop();
        }, 8000);
      } catch {
        fallbackAudioStreamRef.current?.getTracks().forEach((track) => track.stop());
        fallbackAudioStreamRef.current = null;
        mediaRecorderRef.current = null;
        setIsListening(false);
        setLiveVoice(false);
        setLivePanelOpen(false);
        if (!speechUnsupportedNotifiedRef.current) {
          speechUnsupportedNotifiedRef.current = true;
          addAssistantMessage("Der Live-Anruf braucht die Mikrofonfreigabe. Erlaube ORION das Mikrofon und starte den Anruf danach erneut.");
        }
      }
    })();
  }, [addAssistantMessage, apiBaseUrl, apiKey, askOrion, connectionMode, speechLanguage]);

  const toggleListening = useCallback(() => {
    const nativeSpeech = (window as unknown as {
      Capacitor?: { Plugins?: { SpeechRecognition?: {
        requestPermissions?: () => Promise<unknown>;
        start: (options: { language: string; maxResults: number; prompt: string; partialResults: boolean; popup: boolean }) => Promise<{ matches?: string[] }>;
        stop?: () => Promise<void>;
      } } };
    }).Capacitor?.Plugins?.SpeechRecognition;
    if (isListening) {
      stopRecognition();
      return;
    }
    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    if (androidBridge?.startSpeechRecognition) {
      const started = androidBridge.startSpeechRecognition(speechLanguage);
      if (started) setIsListening(true);
      else {
        setLiveVoice(false);
        setLivePanelOpen(false);
        addAssistantMessage("Die Android-Spracherkennung konnte nicht gestartet werden. Der Live-Anruf wurde beendet; prüfe die Mikrofonfreigabe und starte ihn erneut.");
      }
      return;
    }
    const scope = window as unknown as { SpeechRecognition?: RecognitionConstructor; webkitSpeechRecognition?: RecognitionConstructor };
    const Constructor = scope.SpeechRecognition || scope.webkitSpeechRecognition;
    if (!Constructor) {
      if (nativeSpeech) {
        setIsListening(true);
        void (async () => {
          try {
            await nativeSpeech.requestPermissions?.();
            const result = await nativeSpeech.start({ language: speechLanguage, maxResults: 1, prompt: "Sprich mit ORION", partialResults: false, popup: false });
            const transcript = result.matches?.[0]?.trim() || "";
            setIsListening(false);
            if (transcript) await askOrion(transcript);
          } catch {
            setIsListening(false);
            setLiveVoice(false);
            setLivePanelOpen(false);
            addAssistantMessage("Der native Sprachkanal konnte nicht gestartet werden. Prüfe bitte einmalig die Mikrofonfreigabe.");
          }
        })();
        return;
      }
      startRecorderFallback();
      return;
    }
    const recognition = new Constructor();
    recognition.lang = speechLanguage;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.onresult = (event) => {
      const transcript = event.results[0]?.[0]?.transcript || "";
      setIsListening(false);
      if (transcript) void askOrion(transcript);
    };
    recognition.onend = () => setIsListening(false);
    recognition.onerror = (event) => {
      setIsListening(false);
      if (/not-allowed|service-not-allowed/i.test(event.error || "")) {
        setLiveVoice(false);
        setLivePanelOpen(false);
        addAssistantMessage("Der Live-Anruf wurde gestoppt, weil die Mikrofonfreigabe fehlt.");
      }
    };
    recognitionRef.current = recognition;
    try {
      recognition.start();
      setIsListening(true);
    } catch {
      setLiveVoice(false);
      setLivePanelOpen(false);
      addAssistantMessage("Die Browser-Spracherkennung konnte nicht gestartet werden. Der Live-Anruf wurde beendet; prüfe die Mikrofonfreigabe und starte ihn erneut.");
    }
  }, [addAssistantMessage, askOrion, isListening, speechLanguage, startRecorderFallback, stopRecognition]);

  const runMission = useCallback(async (mission: Mission) => {
    if (missionBusy || mission.status === "running") return;
    if (!navigator.onLine) {
      setMissions((current) => current.map((item) => item.id === mission.id ? { ...item, status: "error", result: "Für diese Mission wird eine Internetverbindung benötigt." } : item));
      return;
    }
    setMissionBusy(true);
    setMissions((current) => current.map((item) => item.id === mission.id ? { ...item, status: "running", result: undefined } : item));
    try {
      const memoryContext = memory.length ? memory.map((item) => `- ${item.key}: ${item.value}`).join("\n") : "Keine zusätzlichen Erinnerungen.";
      const missionSystem = `${ORION_MASTER_PROMPT}\n\nDu arbeitest im ORION-Missionskern. Erledige die Aufgabe vollständig, strukturiert und eigenständig. Liefere ein direkt nutzbares Ergebnis. Behaupte keine externe Aktion, die nicht technisch ausgeführt wurde.\n\nERINNERUNGEN:\n${memoryContext}`;
      if (connectionMode === "api") {
        if (!apiKey.trim() || !apiBaseUrl.trim() || !apiModel.trim()) throw new Error("Eigene API noch nicht vollständig eingerichtet.");
        const response = await fetchWithRecovery(`${apiBaseUrl.replace(/\/$/, "")}/chat/completions`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` }, body: JSON.stringify({ model: apiModel.trim(), max_tokens: API_PROFILES[apiProfile].maxTokens, temperature: apiProfile === "supersaver" ? 0.3 : 0.45, messages: [{ role: "system", content: missionSystem }, { role: "user", content: mission.task }] }) }, 1);
        const payload = await response.json().catch(() => ({})) as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } };
        if (!response.ok) throw new Error(payload.error?.message || `API-Fehler ${response.status}`);
        const text = payload.choices?.[0]?.message?.content?.trim() || "Die Mission wurde verarbeitet, aber es kam kein verwertbares Ergebnis zurück.";
        setMissions((current) => current.map((item) => item.id === mission.id ? { ...item, status: "done", result: text } : item));
        addAssistantMessage(`Mission abgeschlossen: „${mission.task}“. Das Ergebnis liegt im Mission Control Center.`);
        return;
      }
      const puterClient = await import("@heyputer/puter.js");
      if (!puterClient.puter.auth.isSignedIn()) {
        setMissions((current) => current.map((item) => item.id === mission.id ? { ...item, status: "error", result: "Bitte zuerst mit dem eigenen Puter-Konto anmelden." } : item));
        return;
      }
      const chat = puterClient.puter.ai.chat as unknown as (
        prompt: Array<{ role: string; content: string }>,
        options: { model: string; max_tokens: number; temperature: number },
      ) => Promise<unknown>;
      const result = await chat([
        { role: "system", content: missionSystem },
        { role: "user", content: mission.task },
      ], { model: mode === "overdrive" ? MODELS.maximum.id : MODELS[modelTier].id, max_tokens: 2600, temperature: 0.45 });
      const text = responseText(result) || "Die Mission wurde verarbeitet, aber es kam kein verwertbares Ergebnis zurück.";
      setMissions((current) => current.map((item) => item.id === mission.id ? { ...item, status: "done", result: text } : item));
      addAssistantMessage(`Mission abgeschlossen: „${mission.task}“. Das Ergebnis liegt im Mission Control Center.`);
    } catch (error) {
      const detail = error instanceof Error ? error.message : "Verbindung unterbrochen";
      setMissions((current) => current.map((item) => item.id === mission.id ? { ...item, status: "error", result: `Mission nicht abgeschlossen: ${detail}` } : item));
    } finally {
      setMissionBusy(false);
    }
  }, [addAssistantMessage, apiBaseUrl, apiKey, apiModel, apiProfile, connectionMode, memory, missionBusy, mode, modelTier]);

  useEffect(() => {
    if (!proactive || missionBusy || aiState === "thinking") return;
    const queued = missions.find((mission) => mission.status === "queued");
    if (!queued) return;
    const timer = window.setTimeout(() => { void runMission(queued); }, 650);
    return () => window.clearTimeout(timer);
  }, [aiState, missionBusy, missions, proactive, runMission]);

  useEffect(() => {
    if (!liveVoice || aiState !== "ready" || isListening || settingsOpen || aboutOpen || installHint) return;
    const timer = window.setTimeout(() => { toggleListening(); }, 700);
    return () => window.clearTimeout(timer);
  }, [aboutOpen, aiState, installHint, isListening, liveVoice, settingsOpen, toggleListening]);

  const handleFile = useCallback(async (file?: File) => {
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      addAssistantMessage("In der Beta kann die mobile Oberfläche Bilder direkt analysieren. Dokumente kommen im nächsten Werkstatt-Ausbau dazu.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      addAssistantMessage("Das Bild ist größer als 8 MB. Bitte wähle eine kleinere Version.");
      return;
    }
    setAttachment(await fileToDataUrl(file));
    setAttachmentName(file.name);
    setView("chat");
  }, [addAssistantMessage]);

  const startVision = useCallback(async (source: "camera" | "screen") => {
    try {
      setVisionStatus(source === "screen" ? "Bildschirmfreigabe wird vorbereitet …" : "Kamera wird vorbereitet …");
      visionStream?.getTracks().forEach((track) => track.stop());
      const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
      if (source === "screen" && androidBridge?.captureScreen) {
        setScreenCapturePending(true);
        setView("vision");
        const started = androidBridge.captureScreen();
        if (!started) throw new Error("native-screen-unavailable");
        setVisionStatus("Android-Systemfreigabe geöffnet");
        return;
      }
      if (!navigator.mediaDevices) throw new Error("media-devices-unavailable");
      if (source === "screen" && !navigator.mediaDevices.getDisplayMedia) throw new Error("screen-share-unavailable");
      const stream = source === "camera"
        ? await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" }, audio: false })
        : await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      setVisionStream(stream);
      setVisionSource(source);
      setVisionStatus(source === "screen" ? "Bildschirmübertragung stabil verbunden" : "Kamera stabil verbunden");
      setView("vision");
      stream.getVideoTracks()[0]?.addEventListener("ended", () => {
        setVisionStream(null);
        setVisionSource(null);
        setDauerblick(false);
        setGamingCoach(false);
        setVisionStatus("Freigabe wurde vom Gerät beendet · erneut starten");
      });
    } catch (error) {
      setScreenCapturePending(false);
      if (source === "screen") setGamingCoach(false);
      const detail = error instanceof Error ? error.message : "Freigabe nicht verfügbar";
      setVisionStatus(`Nicht verbunden · ${detail}`);
      addAssistantMessage(source === "camera" ? "Die Kamera wurde nicht freigegeben." : "Die Bildschirmfreigabe wurde nicht gestartet. Browser und Betriebssystem verlangen dafür immer eine sichtbare Freigabe; die Android-App kann sie danach als sichtbaren Vordergrunddienst stabil weiterführen.");
    }
  }, [addAssistantMessage, visionStream]);

  const captureVision = useCallback(() => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const canvas = document.createElement("canvas");
    canvas.width = Math.min(video.videoWidth, 1600);
    canvas.height = Math.round((video.videoHeight / video.videoWidth) * canvas.width);
    canvas.getContext("2d")?.drawImage(video, 0, 0, canvas.width, canvas.height);
    setAttachment(canvas.toDataURL("image/jpeg", 0.86));
    setAttachmentName(visionSource === "camera" ? "Kameraaufnahme" : "Bildschirmaufnahme");
    setView("chat");
    setInput("Analysiere dieses Bild präzise und sage mir, was wichtig ist.");
  }, [visionSource]);

  const stopVision = useCallback(() => {
    visionStream?.getTracks().forEach((track) => track.stop());
    (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID?.stopGamingCapture?.();
    setVisionStream(null);
    setVisionSource(null);
    setDauerblick(false);
    setGamingCoach(false);
    setCoachBusy(false);
    setVisionStatus("Keine Bildschirmquelle aktiv");
    void wakeLockRef.current?.release().catch(() => undefined);
    wakeLockRef.current = null;
    coachBusyRef.current = false;
    pendingCoachLaunchRef.current = "";
  }, [visionStream]);

  const runGamingCoach = useCallback(async (providedFrame?: string) => {
    if (coachBusyRef.current) return;
    let frame = providedFrame || "";
    if (!frame) {
      if (!visionStream || visionSource !== "screen") return;
      const video = videoRef.current;
      if (!video || !video.videoWidth || !video.videoHeight) return;
      const canvas = document.createElement("canvas");
      canvas.width = Math.min(video.videoWidth, performanceMode ? 800 : 1200);
      canvas.height = Math.max(1, Math.round((video.videoHeight / video.videoWidth) * canvas.width));
      canvas.getContext("2d")?.drawImage(video, 0, 0, canvas.width, canvas.height);
      frame = canvas.toDataURL("image/jpeg", performanceMode ? 0.56 : 0.72);
    }
    const activeLanguage = LANGUAGES.find((language) => language.id === speechLanguage) || LANGUAGES[0];
    const callWordLimit = gamerCallStyle === "ultrakurz" ? 5 : gamerCallStyle === "erklärt" ? 16 : 8;
    const prompt = `Du bist ORION Gaming Coach für ${creatorName || "den Nutzer"}. Spielrolle: ${gamerRole}. Analysiere ausschließlich klar sichtbare Informationen in diesem einzelnen, freiwillig geteilten Bildschirmbild${gameName.trim() ? ` aus ${gameName.trim()}` : " eines Spiels"}. Keine Vermutungen über unsichtbare Gegner, Speicherwerte, versteckte Spieldaten oder Anti-Cheat-Umgehung. Gib genau EINEN unmittelbar hilfreichen taktischen Call in ${activeLanguage.prompt}, höchstens ${callWordLimit} Wörter, ohne Aufzählung, Anrede oder Anführungszeichen. Wenn keine sichere taktische Aussage möglich ist, sage kurz: ${speechLanguage === "de-DE" ? "Keine sichere Aktion erkennbar" : "No safe action visible"}.`;

    coachBusyRef.current = true;
    setCoachBusy(true);
    try {
      let raw = "";
      if (connectionMode === "api") {
        if (!apiKey.trim() || !apiBaseUrl.trim() || !apiModel.trim()) throw new Error("Eigene API nicht vollständig eingerichtet");
        const endpoint = new URL(`${apiBaseUrl.replace(/\/$/, "")}/chat/completions`);
        if (!/^https?:$/.test(endpoint.protocol)) throw new Error("Ungültige API-Adresse");
        const response = await fetchWithRecovery(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` },
          body: JSON.stringify({
            model: apiModel.trim(),
            max_tokens: 48,
            temperature: 0.15,
            messages: [{ role: "user", content: [{ type: "text", text: prompt }, { type: "image_url", image_url: { url: frame } }] }],
          }),
        }, 1);
        const payload = await response.json().catch(() => ({})) as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } };
        if (!response.ok) throw new Error(payload.error?.message || `API-Fehler ${response.status}`);
        raw = payload.choices?.[0]?.message?.content || "";
      } else {
        const puterClient = await import("@heyputer/puter.js");
        if (!puterClient.puter.auth.isSignedIn()) throw new Error("Bitte zuerst mit dem eigenen Puter-Konto anmelden");
        const visionChat = puterClient.puter.ai.chat as unknown as (
          instruction: string,
          image: File,
          config: { model: string; max_tokens: number; temperature: number },
        ) => Promise<unknown>;
        const result = await visionChat(prompt, dataUrlToFile(frame, "orion-gaming-frame.jpg"), { model: MODELS.fast.id, max_tokens: 48, temperature: 0.15 });
        if (result && typeof result === "object" && Symbol.asyncIterator in result) {
          for await (const chunk of result as AsyncIterable<{ text?: string }>) raw += chunk.text || "";
        } else {
          raw = responseText(result);
        }
      }

      const call = raw
        .replace(/```[\s\S]*?```/g, "")
        .replace(/^[\s"'“”„]+|[\s"'“”„]+$/g, "")
        .split(/\r?\n/)[0]
        .replace(/^(?:call|gaming call|coach|orion)\s*:\s*/i, "")
        .trim()
        .slice(0, 150);
      if (!call) throw new Error("Kein verwertbarer Call empfangen");
      setCoachCall(call);
      if (call !== lastCoachCallRef.current) {
        lastCoachCallRef.current = call;
        setCoachHistory((current) => [{ id: uid("call"), text: call, at: timeNow() }, ...current].slice(0, 8));
        if (coachSpeak) speak(call, true);
        if (document.hidden && "Notification" in window && Notification.permission === "granted") {
          new Notification("ORION Gaming Call", { body: call, silent: coachSpeak });
        }
      }
    } catch (error) {
      const detail = error instanceof Error ? error.message : speechLanguage === "de-DE" ? "Analyse nicht verfügbar" : "Analysis unavailable";
      setCoachCall(`${speechLanguage === "de-DE" ? "Coach pausiert" : "Coach paused"}: ${detail}`);
      if (/anmelden|account|auth/i.test(detail)) setGamingCoach(false);
    } finally {
      coachBusyRef.current = false;
      setCoachBusy(false);
    }
  }, [apiBaseUrl, apiKey, apiModel, coachSpeak, connectionMode, creatorName, gameName, gamerCallStyle, gamerRole, performanceMode, speak, speechLanguage, visionSource, visionStream]);

  useEffect(() => {
    if (!gamingCoach || !visionStream || visionSource !== "screen") return;
    const first = window.setTimeout(() => { void runGamingCoach(); }, 800);
    const interval = window.setInterval(() => { void runGamingCoach(); }, Math.max(8, coachInterval) * 1000);
    return () => {
      window.clearTimeout(first);
      window.clearInterval(interval);
    };
  }, [coachInterval, gamingCoach, runGamingCoach, visionSource, visionStream]);

  useEffect(() => {
    if (!gamingCoach || !nativeCoachFrame || coachBusyRef.current) return;
    const frame = nativeCoachFrame;
    setNativeCoachFrame(null);
    void runGamingCoach(frame);
  }, [coachBusy, gamingCoach, nativeCoachFrame, runGamingCoach]);

  const toggleGamingCoach = useCallback(async () => {
    if (gamingCoach) {
      (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID?.stopGamingCapture?.();
      pendingCoachLaunchRef.current = "";
      setGamingCoach(false);
      setCoachBusy(false);
      setVisionStatus("Gaming Coach beendet");
      coachBusyRef.current = false;
      return;
    }
    setMode("gaming");
    setCoachCall(speechLanguage === "de-DE" ? "Gaming Coach startet …" : "Gaming Coach starting …");
    setVisionStatus("Gaming-Bildschirmfreigabe wird vorbereitet …");
    setGamingCoach(true);
    if ("Notification" in window && Notification.permission === "default") void Notification.requestPermission();
    const androidBridge = (window as typeof window & { ORION_ANDROID?: OrionAndroidBridge }).ORION_ANDROID;
    if (androidBridge?.startGamingCapture) {
      pendingCoachLaunchRef.current = gameName.trim();
      setScreenCapturePending(true);
      if (!androidBridge.startGamingCapture(coachInterval)) {
        setScreenCapturePending(false);
        setGamingCoach(false);
        setVisionStatus("Android-Gaming-Freigabe konnte nicht gestartet werden");
      }
      return;
    }
    if (!visionStream || visionSource !== "screen") await startVision("screen");
  }, [coachInterval, gameName, gamingCoach, speechLanguage, startVision, visionSource, visionStream]);

  const runSystemRepair = useCallback(async (silent = false) => {
    setStabilityState("checking");
    const repaired: string[] = [];
    const warnings: string[] = [];

    if (!navigator.onLine) warnings.push("Internetverbindung ist offline");
    if (connectionMode === "api" && (!apiKey.trim() || !apiBaseUrl.trim() || !apiModel.trim())) warnings.push("Eigene API ist noch unvollständig");
    if (aiState === "error") {
      setAiState(navigator.onLine ? "ready" : "offline");
      repaired.push("KI-Status zurückgesetzt");
    }
    if (visionStream && !visionStream.getTracks().some((track) => track.readyState === "live")) {
      setVisionStream(null);
      setVisionSource(null);
      setDauerblick(false);
      setGamingCoach(false);
      setVisionStatus("Freigabe beendet · mit einem Tippen neu verbinden");
      repaired.push("beendete Bildschirmquelle bereinigt");
    }
    if (radioPlaying && radioRef.current?.paused) {
      setRadioPlaying(false);
      repaired.push("Radioanzeige synchronisiert");
    }
    if (streamChatConnected && streamChatWsRef.current?.readyState !== WebSocket.OPEN) {
      streamChatWsRef.current?.close();
      streamChatWsRef.current = null;
      setStreamChatConnected(false);
      setStreamChatStatus("Verbindung automatisch zurückgesetzt");
      repaired.push("Stream-Chat-Verbindung bereinigt");
    }
    try {
      const testKey = "orion.stability.test";
      localStorage.setItem(testKey, "ok");
      localStorage.removeItem(testKey);
    } catch {
      warnings.push("Lokaler Speicher ist blockiert oder voll");
    }
    if (!silent) await navigator.serviceWorker?.getRegistration?.().then((registration) => registration?.update()).catch(() => undefined);

    const result = repaired.length ? `${repaired.join(" · ")} repariert` : warnings.length ? warnings.join(" · ") : "Alle ORION-Kernsysteme arbeiten normal";
    setLastRepair(result);
    setRecoveryCount((current) => current + repaired.length);
    setStabilityState(warnings.length ? "warning" : "optimal");
    setAuditLog((current) => [{ id: uid("stability"), text: `Systemdiagnose: ${result}`, at: timeNow() }, ...current].slice(0, 80));
    if (!silent) addAssistantMessage(warnings.length ? `Systemcheck abgeschlossen. Hinweis: ${warnings.join(" · ")}.` : `Systemcheck abgeschlossen: ${result}.`, false);
  }, [addAssistantMessage, aiState, apiBaseUrl, apiKey, apiModel, connectionMode, radioPlaying, streamChatConnected, visionStream]);

  useEffect(() => {
    if (!hydrated || !autoRepair) return;
    const onRuntimeIssue = (event: ErrorEvent | PromiseRejectionEvent) => {
      const detail = event instanceof ErrorEvent ? event.message : event.reason instanceof Error ? event.reason.message : "Laufzeitfehler";
      setStabilityState("warning");
      setLastRepair(`Fehler erkannt: ${String(detail).slice(0, 120)}`);
      window.setTimeout(() => { void runSystemRepair(true); }, 250);
    };
    window.addEventListener("error", onRuntimeIssue);
    window.addEventListener("unhandledrejection", onRuntimeIssue);
    const interval = window.setInterval(() => { void runSystemRepair(true); }, 45000);
    return () => {
      window.removeEventListener("error", onRuntimeIssue);
      window.removeEventListener("unhandledrejection", onRuntimeIssue);
      window.clearInterval(interval);
    };
  }, [autoRepair, hydrated, runSystemRepair]);

  useEffect(() => {
    const nav = navigator as Navigator & { wakeLock?: { request: (type: "screen") => Promise<{ release: () => Promise<void> }> } };
    const shouldLock = keepScreenAwake && Boolean(visionStream || gamingCoach);
    const acquire = async () => {
      if (!shouldLock || document.visibilityState !== "visible" || !nav.wakeLock || wakeLockRef.current) return;
      wakeLockRef.current = await nav.wakeLock.request("screen").catch(() => null);
    };
    if (shouldLock) void acquire();
    const onVisibility = () => { if (document.visibilityState === "visible") void acquire(); };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      void wakeLockRef.current?.release().catch(() => undefined);
      wakeLockRef.current = null;
    };
  }, [gamingCoach, keepScreenAwake, visionStream]);

  const generateImage = useCallback(async () => {
    if (!studioPrompt.trim() || studioBusy) return;
    setStudioBusy(true);
    setStudioError("");
    try {
      const ratio = studioRatio === "16:9" ? { w: 16, h: 9 } : studioRatio === "9:16" ? { w: 9, h: 16 } : { w: 1, h: 1 };
      const size = studioRatio === "16:9" ? "1536x1024" : studioRatio === "9:16" ? "1024x1536" : "1024x1024";
      if (connectionMode === "api") {
        if (!apiKey.trim() || !apiBaseUrl.trim()) throw new Error("Eigene API noch nicht vollständig eingerichtet.");
        const response = await fetchWithRecovery(`${apiBaseUrl.replace(/\/$/, "")}/images/generations`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` }, body: JSON.stringify({ model: studioModel, prompt: studioPrompt.trim(), size, quality: studioQuality }) }, 1);
        const payload = await response.json().catch(() => ({})) as { data?: Array<{ b64_json?: string; url?: string }>; error?: { message?: string } };
        if (!response.ok) throw new Error(payload.error?.message || `Bild-API ${response.status}`);
        const image = payload.data?.[0];
        if (image?.b64_json) setStudioImage(`data:image/png;base64,${image.b64_json}`);
        else if (image?.url) setStudioImage(image.url);
        else throw new Error("Kein Bild empfangen");
        return;
      }
      const puterClient = await import("@heyputer/puter.js");
      if (!puterClient.puter.auth.isSignedIn()) {
        addAssistantMessage("Melde dich zuerst mit deinem eigenen Puter-Konto an. ORION verwendet absichtlich kein gemeinsames Betreiberkonto.");
        setView("chat");
        return;
      }
      const image = await puterClient.puter.ai.txt2img(studioPrompt.trim(), { model: studioModel, quality: studioQuality, ratio });
      if (image instanceof HTMLImageElement) setStudioImage(image.src);
      else if (typeof image === "string") setStudioImage(image);
      else throw new Error("Kein Bild empfangen");
    } catch (error) {
      const detail = error instanceof Error ? error.message : "Unbekannter Bildfehler";
      setStudioError(`Bild konnte nicht erzeugt werden: ${detail}`);
    } finally {
      setStudioBusy(false);
    }
  }, [addAssistantMessage, apiBaseUrl, apiKey, connectionMode, studioBusy, studioModel, studioPrompt, studioQuality, studioRatio]);

  const requestUtilityText = useCallback(async (system: string, prompt: string, maxTokens = 2400) => {
    if (connectionMode === "api") {
      if (!apiKey.trim() || !apiBaseUrl.trim() || !apiModel.trim()) throw new Error("Eigene API ist noch nicht vollständig eingerichtet.");
      const endpoint = new URL(`${apiBaseUrl.replace(/\/$/, "")}/chat/completions`);
      if (!/^https?:$/.test(endpoint.protocol)) throw new Error("Ungültige API-Adresse.");
      const response = await fetchWithRecovery(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey.trim()}` },
        body: JSON.stringify({ model: apiModel.trim(), max_tokens: Math.min(maxTokens, API_PROFILES[apiProfile].maxTokens), temperature: apiProfile === "supersaver" ? 0.25 : 0.35, messages: [{ role: "system", content: system }, { role: "user", content: prompt }] }),
      }, 1);
      const payload = await response.json().catch(() => ({})) as { choices?: Array<{ message?: { content?: string } }>; error?: { message?: string } };
      if (!response.ok) throw new Error(payload.error?.message || `API-Fehler ${response.status}`);
      return payload.choices?.[0]?.message?.content?.trim() || "";
    }
    const puterClient = await import("@heyputer/puter.js");
    if (!puterClient.puter.auth.isSignedIn()) throw new Error("Bitte zuerst mit dem eigenen Nutzerkonto anmelden.");
    const chat = puterClient.puter.ai.chat as unknown as (messages: Array<{ role: string; content: string }>, options: { model: string; max_tokens: number; temperature: number }) => Promise<unknown>;
    const response = await chat([{ role: "system", content: system }, { role: "user", content: prompt }], { model: MODELS[modelTier].id, max_tokens: maxTokens, temperature: 0.35 });
    return responseText(response).trim();
  }, [apiBaseUrl, apiKey, apiModel, apiProfile, connectionMode, modelTier]);

  const addStreamChatMessage = useCallback((message: { id: string; user: string; text: string }) => {
    if (streamSeenRef.current.has(message.id)) return;
    streamSeenRef.current.add(message.id);
    setStreamChatMessages((current) => [...current, { ...message, at: timeNow() }].slice(-100));
  }, []);

  const connectTwitchChat = useCallback(() => {
    let channel = streamChannel.trim().replace(/^#/, "").toLowerCase();
    if (!channel && streamUrl.trim()) {
      try {
        const url = new URL(streamUrl.trim());
        if (url.hostname.endsWith("twitch.tv")) channel = url.pathname.split("/").filter(Boolean)[0]?.toLowerCase() || "";
      } catch { /* Manual channel entry remains available. */ }
    }
    channel = channel.replace(/[^a-z0-9_]/g, "");
    if (!channel) {
      setStreamChatStatus("Twitch-Kanalname fehlt");
      return;
    }
    streamChatWsRef.current?.close();
    streamSeenRef.current = new Set();
    setStreamChatMessages([]);
    setStreamChatConnected(false);
    setStreamChannel(channel);
    setStreamChatStatus("Verbindung wird aufgebaut …");
    const socket = new WebSocket("wss://irc-ws.chat.twitch.tv:443");
    streamChatWsRef.current = socket;
    socket.onopen = () => {
      setStreamChatConnected(true);
      const nick = `justinfan${Math.floor(10000 + Math.random() * 89999)}`;
      socket.send("PASS SCHMOOPIIE");
      socket.send(`NICK ${nick}`);
      socket.send("CAP REQ :twitch.tv/tags twitch.tv/commands");
      socket.send(`JOIN #${channel}`);
      setStreamChatStatus(`LIVE · #${channel} · nur Lesen`);
    };
    socket.onmessage = (event) => {
      String(event.data).split("\r\n").forEach((line) => {
        if (line.startsWith("PING")) {
          socket.send(line.replace("PING", "PONG"));
          return;
        }
        const message = parseTwitchMessage(line);
        if (message) addStreamChatMessage(message);
      });
    };
    socket.onerror = () => {
      setStreamChatConnected(false);
      setStreamChatStatus("Twitch-Chat konnte nicht verbunden werden");
    };
    socket.onclose = () => {
      setStreamChatConnected(false);
      if (streamChatWsRef.current === socket) {
        streamChatWsRef.current = null;
        setStreamChatStatus("Nicht verbunden");
      }
    };
  }, [addStreamChatMessage, streamChannel, streamUrl]);

  const disconnectStreamChat = useCallback(() => {
    const socket = streamChatWsRef.current;
    streamChatWsRef.current = null;
    socket?.close();
    setStreamChatConnected(false);
    setStreamChatStatus("Nicht verbunden");
  }, []);

  useEffect(() => () => streamChatWsRef.current?.close(), []);

  const importStreamMessages = useCallback(() => {
    streamChatImport.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).forEach((line) => {
      const separator = line.indexOf(":");
      const user = separator > 0 ? line.slice(0, separator).trim() : "Chat";
      const text = separator > 0 ? line.slice(separator + 1).trim() : line;
      if (text) addStreamChatMessage({ id: `manual-${compactId(`${user}:${text}`)}`, user, text });
    });
    setStreamChatImport("");
  }, [addStreamChatMessage, streamChatImport]);

  const draftStreamReply = useCallback(async (id: string) => {
    const target = streamChatMessages.find((message) => message.id === id);
    if (!target || target.drafting) return;
    setStreamChatMessages((current) => current.map((message) => message.id === id ? { ...message, drafting: true } : message));
    try {
      const previous = streamChatMessages.filter((message) => message.reply).slice(-8).map((message) => `- ${message.reply}`).join("\n") || "Keine bisherigen Antworten";
      const language = LANGUAGES.find((item) => item.id === speechLanguage)?.prompt || "Deutsch";
      const reply = await requestUtilityText("Du bist ORION Stream Chat Copilot. Antworte freundlich, kurz und natürlich. Wiederhole weder Formulierungen noch denselben Inhalt aus früheren Antworten. Keine Behauptung, dass etwas im Stream passiert ist, wenn es nicht in der Nachricht steht. Gib nur den Antworttext aus.", `Sprache: ${language}\nNachricht von ${target.user}: ${target.text}\n\nBisherige Antworten, die du nicht wiederholen darfst:\n${previous}`, 220);
      setStreamChatMessages((current) => current.map((message) => message.id === id ? { ...message, drafting: false, reply: reply.trim() || "Keine Antwort erzeugt" } : message));
    } catch (error) {
      const detail = error instanceof Error ? error.message : "Antwort nicht verfügbar";
      setStreamChatMessages((current) => current.map((message) => message.id === id ? { ...message, drafting: false, reply: `Fehler: ${detail}` } : message));
    }
  }, [requestUtilityText, speechLanguage, streamChatMessages]);

  const copyStreamReply = useCallback((id: string) => {
    const target = streamChatMessages.find((message) => message.id === id);
    if (!target?.reply) return;
    void navigator.clipboard?.writeText(target.reply);
    setStreamChatMessages((current) => current.map((message) => message.id === id ? { ...message, answered: true } : message));
    if (streamChannel) openExternal(`https://www.twitch.tv/popout/${encodeURIComponent(streamChannel)}/chat?popout=`);
  }, [openExternal, streamChannel, streamChatMessages]);

  const translateText = useCallback(async () => {
    if (!translateInput.trim()) return;
    const offline: Record<string, Record<string, string>> = {
      "en-US": { hallo: "hello", danke: "thank you", bitte: "please", ja: "yes", nein: "no", "guten morgen": "good morning", "gute nacht": "good night" },
      "de-DE": { hello: "hallo", thanks: "danke", please: "bitte", yes: "ja", no: "nein", "good morning": "guten Morgen", "good night": "gute Nacht" },
      "tr-TR": { hallo: "merhaba", danke: "teşekkürler", bitte: "lütfen", ja: "evet", nein: "hayır" },
    };
    const exact = offline[translateTarget]?.[translateInput.trim().toLowerCase()];
    if (exact) {
      setTranslateOutput(`${exact}\n\nOffline-Wörterbuch`);
      return;
    }
    if (!navigator.onLine) {
      setTranslateOutput("Diese Formulierung ist nicht im kompakten Offline-Wörterbuch. Für freie Sätze kurz online verbinden.");
      return;
    }
    try {
      const language = LANGUAGES.find((item) => item.id === translateTarget)?.label || translateTarget;
      const result = await requestUtilityText("Du bist ein präziser Übersetzer. Gib nur die Übersetzung ohne Erklärung aus.", `Übersetze nach ${language}:\n\n${translateInput}`, 1200);
      setTranslateOutput(result || "Keine Übersetzung empfangen.");
    } catch (error) {
      setTranslateOutput(error instanceof Error ? error.message : "Übersetzung nicht verfügbar.");
    }
  }, [requestUtilityText, translateInput, translateTarget]);

  const generateFileDraft = useCallback(async () => {
    if (!fileContent.trim()) return;
    try {
      const result = await requestUtilityText("Du bist ORION File Studio. Erstelle vollständigen, direkt nutzbaren Dokumentinhalt. Keine Markdown-Codezäune.", `Titel: ${fileTitle}\nFormat: ${fileFormat}\nAufgabe/Notizen: ${fileContent}`, 3200);
      if (result) setFileContent(result);
    } catch (error) {
      addAssistantMessage(error instanceof Error ? error.message : "Der Dateientwurf konnte nicht erstellt werden.", false);
    }
  }, [addAssistantMessage, fileContent, fileFormat, fileTitle, requestUtilityText]);

  const generateGame = useCallback(async (fix = false) => {
    if ((!gamePrompt.trim() && !fix) || gameBusy) return;
    setGameBusy(true);
    try {
      const prompt = fix
        ? `Repariere dieses eigenständige HTML-Spiel vollständig. Gemeldeter Fehler: ${gameBug || "Finde und behebe alle Spiellogikfehler"}. Schwierigkeit: ${gameDifficulty}. Figuren und Spielfelder müssen ausschließlich legale Züge erlauben. Antworte nur mit dem kompletten HTML.\n\nBESTEHENDER CODE:\n${gameCode}`
        : `Erstelle ein vollständiges eigenständiges HTML5-Spiel ohne externe Bibliotheken. Idee: ${gamePrompt}. Schwierigkeit: ${gameDifficulty}. Baue sichtbare Regeln, Neustart, Schwierigkeitsauswahl und korrekte Spiellogik ein. Bei Schach oder Brettspielen dürfen Figuren nur regelkonforme Züge machen. Antworte nur mit komplettem HTML.`;
      const result = await requestUtilityText("Du bist ORION Game Lab, ein sorgfältiger Senior-Game-Engineer. Liefere ausschließlich valides, eigenständiges HTML mit eingebettetem CSS und JavaScript.", prompt, 7000);
      const clean = result.replace(/^```(?:html)?\s*/i, "").replace(/```$/i, "").trim();
      setGameCode(clean);
      setGameBug("");
      logAction(fix ? "Game-Lab: Spielcode repariert" : "Game-Lab: neues Spiel erzeugt");
    } catch (error) {
      addAssistantMessage(error instanceof Error ? error.message : "Das Spiel konnte nicht erstellt werden.", false);
    } finally {
      setGameBusy(false);
    }
  }, [addAssistantMessage, gameBug, gameBusy, gameCode, gameDifficulty, gamePrompt, logAction, requestUtilityText]);

  const installApp = useCallback(async () => {
    if (installPrompt) {
      await installPrompt.prompt();
      await installPrompt.userChoice;
      setInstallPrompt(null);
      return;
    }
    setInstallHint(true);
  }, [installPrompt]);

  const addMemory = useCallback(() => {
    if (!memoryKey.trim() || !memoryValue.trim()) return;
    const fact: MemoryFact = {
      id: uid("memory"),
      key: memoryKey.trim(),
      value: memoryValue.trim(),
      category: "note",
      source: "explicit",
      updatedAt: new Date().toISOString(),
    };
    setMemory((current) => [...current.filter((item) => item.key.toLowerCase() !== fact.key.toLowerCase()), fact]);
    setMemoryKey("");
    setMemoryValue("");
  }, [memoryKey, memoryValue]);

  const addCommand = useCallback(() => {
    if (!commandPhrase.trim() || !commandInstruction.trim()) return;
    setCommands((current) => [...current, { id: uid("command"), phrase: commandPhrase.trim(), instruction: commandInstruction.trim() }]);
    setCommandPhrase("");
    setCommandInstruction("");
  }, [commandInstruction, commandPhrase]);

  const exportData = useCallback(() => {
    const payload = JSON.stringify({
      version: 4,
      exportedAt: new Date().toISOString(),
      messages,
      memory,
      commands,
      missions,
      timers,
      gamingCalls: coachHistory,
      streamChat: streamChatMessages,
      settings: { mode, modelTier, autoSpeak, voiceEngine, voiceProfile, assistantGender, personalityStrength, relationshipCloseness, humorLevel, formalityLevel, speechLanguage, radioStation, autoActions, liveWeb, proactive, preferredName, wakeWord, standbyEnabled, crosshairEnabled, chargingSound, connectionMode, apiBaseUrl, apiModel, apiProfile, apiAutoModel, memoryLearningEnabled, rememberApiKey: false, gameName, coachInterval, coachSpeak, studioModel, studioQuality, studioRatio, streamChannel, creatorName, gamerRole, gamerCallStyle, streamerMode, performanceMode, autoRepair, keepScreenAwake },
    }, null, 2);
    const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "orion-backup.json";
    anchor.click();
    URL.revokeObjectURL(url);
  }, [apiAutoModel, apiBaseUrl, apiModel, apiProfile, assistantGender, autoActions, autoRepair, autoSpeak, chargingSound, coachHistory, coachInterval, coachSpeak, commands, connectionMode, creatorName, crosshairEnabled, formalityLevel, gameName, gamerCallStyle, gamerRole, humorLevel, keepScreenAwake, liveWeb, memory, memoryLearningEnabled, messages, missions, mode, modelTier, performanceMode, personalityStrength, preferredName, proactive, radioStation, relationshipCloseness, speechLanguage, standbyEnabled, streamChannel, streamChatMessages, streamerMode, studioModel, studioQuality, studioRatio, timers, voiceEngine, voiceProfile, wakeWord]);

  const importData = useCallback(async (file?: File) => {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text()) as {
        messages?: Message[];
        memory?: MemoryFact[];
        commands?: CustomCommand[];
        missions?: Mission[];
        timers?: OrionTimer[];
        gamingCalls?: Array<{ id: string; text: string; at: string }>;
        streamChat?: StreamChatMessage[];
        settings?: Partial<{
          mode: string;
          modelTier: keyof typeof MODELS;
          autoSpeak: boolean;
          voiceEngine: VoiceEngine;
          voiceProfile: string;
          assistantGender: AssistantGender;
          personalityStrength: number;
          relationshipCloseness: number;
          humorLevel: number;
          formalityLevel: number;
          speechLanguage: string;
          radioStation: string;
          autoActions: boolean;
          liveWeb: boolean;
          proactive: boolean;
          preferredName: string;
          wakeWord: string;
          standbyEnabled: boolean;
          crosshairEnabled: boolean;
          chargingSound: boolean;
          connectionMode: ConnectionMode;
          apiBaseUrl: string;
          apiModel: string;
          apiProfile: ApiProfile;
          apiAutoModel: boolean;
          memoryLearningEnabled: boolean;
          gameName: string;
          coachInterval: number;
          coachSpeak: boolean;
          studioModel: string;
          studioQuality: "low" | "medium" | "high";
          studioRatio: "1:1" | "16:9" | "9:16";
          streamChannel: string;
          creatorName: string;
          gamerRole: string;
          gamerCallStyle: string;
          streamerMode: boolean;
          performanceMode: boolean;
          autoRepair: boolean;
          keepScreenAwake: boolean;
        }>;
      };
      if (Array.isArray(data.messages)) setMessages(data.messages.slice(-60));
      if (Array.isArray(data.memory)) setMemory(data.memory);
      if (Array.isArray(data.commands)) setCommands(data.commands);
      if (Array.isArray(data.missions)) setMissions(data.missions.slice(-40));
      if (Array.isArray(data.timers)) setTimers(data.timers.slice(-20));
      if (Array.isArray(data.gamingCalls)) setCoachHistory(data.gamingCalls.slice(0, 8));
      if (Array.isArray(data.streamChat)) setStreamChatMessages(data.streamChat.slice(-100));
      const settings = data.settings;
      if (settings) {
        if (settings.mode && MODES.some((item) => item.id === settings.mode)) setMode(settings.mode);
        if (settings.modelTier && MODELS[settings.modelTier]) setModelTier(settings.modelTier);
        if (typeof settings.autoSpeak === "boolean") setAutoSpeak(settings.autoSpeak);
        if (settings.voiceEngine === "device" || settings.voiceEngine === "neural") setVoiceEngine(settings.voiceEngine);
        if (settings.voiceProfile && VOICE_PROFILES.some((item) => item.id === settings.voiceProfile)) setVoiceProfile(settings.voiceProfile);
        if (settings.assistantGender && ["female", "male", "neutral"].includes(settings.assistantGender)) setAssistantGender(settings.assistantGender);
        if (typeof settings.personalityStrength === "number") setPersonalityStrength(Math.max(0, Math.min(4, settings.personalityStrength)));
        if (typeof settings.relationshipCloseness === "number") setRelationshipCloseness(Math.max(0, Math.min(4, settings.relationshipCloseness)));
        if (typeof settings.humorLevel === "number") setHumorLevel(Math.max(0, Math.min(4, settings.humorLevel)));
        if (typeof settings.formalityLevel === "number") setFormalityLevel(Math.max(0, Math.min(4, settings.formalityLevel)));
        if (settings.speechLanguage && LANGUAGES.some((item) => item.id === settings.speechLanguage)) setSpeechLanguage(settings.speechLanguage);
        if (settings.radioStation && RADIO_STATIONS.some((item) => item.id === settings.radioStation)) setRadioStation(settings.radioStation);
        if (typeof settings.autoActions === "boolean") setAutoActions(settings.autoActions);
        if (typeof settings.liveWeb === "boolean") setLiveWeb(settings.liveWeb);
        if (typeof settings.proactive === "boolean") setProactive(settings.proactive);
        if (settings.preferredName?.trim()) setPreferredName(settings.preferredName.trim().slice(0, 40));
        if (settings.wakeWord?.trim()) setWakeWord(settings.wakeWord.trim().slice(0, 24));
        if (typeof settings.standbyEnabled === "boolean") setStandbyEnabled(settings.standbyEnabled);
        if (typeof settings.crosshairEnabled === "boolean") setCrosshairEnabled(settings.crosshairEnabled);
        if (typeof settings.chargingSound === "boolean") setChargingSound(settings.chargingSound);
        if (settings.connectionMode === "account" || settings.connectionMode === "api") setConnectionMode(settings.connectionMode);
        if (settings.apiBaseUrl?.trim()) setApiBaseUrl(settings.apiBaseUrl.trim());
        if (settings.apiModel?.trim()) setApiModel(settings.apiModel.trim());
        if (settings.apiProfile && ["supersaver", "balanced", "maximum"].includes(settings.apiProfile)) setApiProfile(settings.apiProfile);
        if (typeof settings.apiAutoModel === "boolean") setApiAutoModel(settings.apiAutoModel);
        if (typeof settings.memoryLearningEnabled === "boolean") setMemoryLearningEnabled(settings.memoryLearningEnabled);
        if (typeof settings.gameName === "string") setGameName(settings.gameName.trim().slice(0, 60));
        if (typeof settings.coachInterval === "number" && [8, 12, 20].includes(settings.coachInterval)) setCoachInterval(settings.coachInterval);
        if (typeof settings.coachSpeak === "boolean") setCoachSpeak(settings.coachSpeak);
        if (settings.studioModel?.trim()) setStudioModel(settings.studioModel.trim());
        if (settings.studioQuality && ["low", "medium", "high"].includes(settings.studioQuality)) setStudioQuality(settings.studioQuality);
        if (settings.studioRatio && ["1:1", "16:9", "9:16"].includes(settings.studioRatio)) setStudioRatio(settings.studioRatio);
        if (typeof settings.streamChannel === "string") setStreamChannel(settings.streamChannel.trim().slice(0, 60));
        if (typeof settings.creatorName === "string") setCreatorName(settings.creatorName.trim().slice(0, 40));
        if (typeof settings.gamerRole === "string") setGamerRole(settings.gamerRole.trim().slice(0, 60));
        if (typeof settings.gamerCallStyle === "string" && ["ultrakurz", "kurz", "erklärt"].includes(settings.gamerCallStyle)) setGamerCallStyle(settings.gamerCallStyle);
        if (typeof settings.streamerMode === "boolean") setStreamerMode(settings.streamerMode);
        if (typeof settings.performanceMode === "boolean") setPerformanceMode(settings.performanceMode);
        if (typeof settings.autoRepair === "boolean") setAutoRepair(settings.autoRepair);
        if (typeof settings.keepScreenAwake === "boolean") setKeepScreenAwake(settings.keepScreenAwake);
      }
      addAssistantMessage("Rohdaten-Backup importiert. Chat, Gedächtnis, Befehle, Missionen und Einstellungen wurden wiederhergestellt.");
      setView("chat");
    } catch {
      addAssistantMessage("Die Backup-Datei konnte nicht gelesen werden.");
      setView("chat");
    }
  }, [addAssistantMessage]);

  const clearChat = useCallback(() => {
    setMessages([{ ...initialWelcome, id: uid("welcome"), text: "Neuer Kanal geöffnet. Womit beginnen wir?", createdAt: timeNow() }]);
    setSettingsOpen(false);
  }, [initialWelcome]);

  const saveAllSettings = useCallback(() => {
    localStorage.setItem(STORAGE.settings, JSON.stringify({ mode, modelTier, autoSpeak, voiceEngine, voiceProfile, assistantGender, personalityStrength, relationshipCloseness, humorLevel, formalityLevel, speechLanguage, radioStation, autoActions, liveWeb, proactive, preferredName, wakeWord, standbyEnabled, crosshairEnabled, chargingSound, connectionMode, apiBaseUrl, apiModel, apiProfile, apiAutoModel, memoryLearningEnabled, rememberApiKey, apiKey: rememberApiKey ? apiKey : "", gameName, coachInterval, coachSpeak, studioModel, studioQuality, studioRatio, streamChannel, creatorName, gamerRole, gamerCallStyle, streamerMode, performanceMode, autoRepair, keepScreenAwake }));
    localStorage.setItem(STORAGE.messages, JSON.stringify(messages.slice(-60)));
    localStorage.setItem(STORAGE.memory, JSON.stringify(memory));
    localStorage.setItem(STORAGE.commands, JSON.stringify(commands));
    localStorage.setItem(STORAGE.missions, JSON.stringify(missions.slice(-40)));
    localStorage.setItem(STORAGE.timers, JSON.stringify(timers));
    localStorage.setItem(STORAGE.streamChat, JSON.stringify(streamChatMessages.slice(-100)));
    setSettingsSaved(true);
    window.setTimeout(() => setSettingsSaved(false), 2200);
  }, [apiAutoModel, apiBaseUrl, apiKey, apiModel, apiProfile, assistantGender, autoActions, autoRepair, autoSpeak, chargingSound, coachInterval, coachSpeak, commands, connectionMode, creatorName, crosshairEnabled, formalityLevel, gameName, gamerCallStyle, gamerRole, humorLevel, keepScreenAwake, liveWeb, memory, memoryLearningEnabled, messages, missions, mode, modelTier, performanceMode, personalityStrength, preferredName, proactive, radioStation, relationshipCloseness, rememberApiKey, speechLanguage, standbyEnabled, streamChannel, streamChatMessages, streamerMode, studioModel, studioQuality, studioRatio, timers, voiceEngine, voiceProfile, wakeWord]);

  const ui = UI_TEXT[speechLanguage as keyof typeof UI_TEXT] || UI_TEXT["en-US"];
  const t = useCallback((key: keyof typeof UI_TEXT["de-DE"]) => ui[key], [ui]);
  const l = useCallback((german: string, international: string) => speechLanguage === "de-DE" ? german : international, [speechLanguage]);
  const flag = ({ "de-DE": "🇩🇪", "en-US": "🇬🇧", "tr-TR": "🇹🇷", "es-ES": "🇪🇸", "fr-FR": "🇫🇷", "it-IT": "🇮🇹", "pl-PL": "🇵🇱", "nl-NL": "🇳🇱", "pt-BR": "🇧🇷", "ar-SA": "🇸🇦", "ru-RU": "🇷🇺", "ja-JP": "🇯🇵", "ko-KR": "🇰🇷", "hi-IN": "🇮🇳" } as Record<string, string>)[speechLanguage] || "🌐";

  useEffect(() => {
    document.documentElement.lang = speechLanguage.split("-")[0];
  }, [speechLanguage]);

  const quickActions = [
    { label: "Tagesbriefing", prompt: "Erstelle mein persönliches Morgenbriefing aus Datum, gespeicherten Zielen, Projekten und Terminen. Nenne die drei wichtigsten Prioritäten und einen realistischen Tagesplan." },
    { label: "Systemstatus", prompt: "Status" },
    { label: "Ideenmodus", prompt: "Aktiviere Kreativmodus und entwickle mit mir eine starke neue Idee." },
    { label: "Focus Radio", prompt: "Spiele Focus Radio" },
  ];

  return (
    <main className={`orion-app mode-${mode}`}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="grid-field" />
      {crosshairEnabled && <div className="orion-crosshair" aria-hidden="true"><span /><i /></div>}
      <audio ref={radioRef} className="sr-only" />
      <input ref={fileInputRef} className="sr-only" type="file" accept="image/*" onChange={(event) => handleFile(event.target.files?.[0])} />
      <input ref={importInputRef} className="sr-only" type="file" accept="application/json" onChange={(event) => importData(event.target.files?.[0])} />

      <header className="topbar">
        <button className="brand" onClick={() => { setView("chat"); setAboutOpen(true); }} aria-label="Über ORION">
          <span className="brand-mark"><img src="/orion.svg" alt="" /><b>S/X</b></span>
          <span className="brand-copy"><strong>ORION</strong><small>V1 BETA · SPECTRUM X</small></span>
        </button>
        <div className="system-pill">
          <span className={`status-dot ${aiState}`} />
          <span>{aiState === "thinking" ? t("processing") : aiState === "speaking" ? t("speaking") : isListening ? t("listening") : liveVoice ? t("live") : isOnline ? t("online") : t("offline")}</span>
        </div>
        <div className="top-actions">
          <button className="device-chip" onClick={() => { setView("tools"); setToolTab("device"); }} aria-label="Sprache und Gerät"><span>{flag}</span><Icon name={platform === "Android" || platform === "iOS" ? "phone" : "monitor"} size={17} /></button>
          <button className={`account-button ${cloudSignedIn || connectionMode === "api" && apiKey ? "signed-in" : ""}`} onClick={() => connectionMode === "account" && !cloudSignedIn ? void signInToCloud() : setSettingsOpen(true)} disabled={authBusy}><Icon name="shield" size={16} /><span>{authBusy ? "…" : connectionMode === "api" ? "Eigene API" : cloudSignedIn ? cloudUser : t("signIn")}</span></button>
          <button className={`icon-button live-call-trigger ${liveVoice ? "active" : ""}`} onClick={() => liveVoice ? setLivePanelOpen(true) : startLiveCall()} aria-label={liveVoice ? "Live-Anruf öffnen" : "Live-Anruf starten"}><Icon name="phone" /></button>
          <button className={`icon-button ${autoSpeak ? "active" : ""}`} onClick={() => { window.speechSynthesis?.cancel(); neuralAudioRef.current?.pause(); neuralAudioRef.current = null; setAutoSpeak((value) => !value); }} aria-label="Sprachausgabe umschalten"><Icon name="volume" /></button>
          <button className="install-button" onClick={installApp}><Icon name="install" size={17} /><span>{t("install")}</span></button>
          <button className="icon-button" onClick={() => setSettingsOpen(true)} aria-label="Einstellungen"><Icon name="settings" /></button>
        </div>
      </header>

      <section className="workspace">
        <nav className="side-rail" aria-label="ORION Bereiche">
          <div className="rail-main">
            {([
              ["chat", "chat", t("assistant")],
              ["missions", "bolt", t("missions")],
              ["vision", "eye", t("vision")],
              ["studio", "spark", t("studio")],
              ["tools", "bolt", t("tools")],
              ["memory", "memory", t("memory")],
            ] as const).map(([id, icon, label]) => (
              <button key={id} className={view === id ? "active" : ""} onClick={() => setView(id)} aria-label={label}><Icon name={icon} /><span>{label}</span></button>
            ))}
          </div>
          <button onClick={() => setSettingsOpen(true)} aria-label={t("settings")}><Icon name="settings" /><span>{t("setup")}</span></button>
        </nav>

        <section className="main-panel">
          {view === "chat" && (
            <div className="chat-view">
              <div className="conversation" aria-live="polite">
                {messages.length <= 1 && (
                  <div className="orion-stage">
                    <div className={`orion-core ${aiState}`}>
                      <span className="ring ring-one" /><span className="ring ring-two" /><span className="ring ring-three" />
                      <span className="core-light" />
                    </div>
                    <p className="eyebrow">PERSONAL INTELLIGENCE SYSTEM</p>
                    <h1>{t("ready")}, {preferredName}.</h1>
                    <p className="stage-subtitle">{l(`Sag „${wakeWord}“ oder gib ORION eine Mission.`, `Say “${wakeWord}” or give ORION a mission.`)}</p>
                    <button className="stage-live-button" onClick={startLiveCall}><Icon name="phone" size={17} /> {t("startLive")}</button>
                  </div>
                )}
                <div className="message-list">
                  {messages.map((message) => (
                    <article className={`message ${message.role}`} key={message.id}>
                      <div className="message-avatar">{message.role === "assistant" ? <span className="mini-core" /> : preferredName.slice(0, 1).toUpperCase()}</div>
                      <div className="message-body">
                        <div className="message-meta"><strong>{message.role === "assistant" ? "ORION" : preferredName.toUpperCase()}</strong><span>{message.createdAt}</span></div>
                        {message.image && <img className="message-image" src={message.image} alt="Vom Nutzer gesendete Aufnahme" />}
                        <div className="message-text"><MessageText text={message.text || (aiState === "thinking" ? "Analysiere …" : "")} /></div>
                        {message.role === "assistant" && message.text && (
                          <button className="copy-button" onClick={() => navigator.clipboard?.writeText(message.text)}><Icon name="copy" size={15} /> Kopieren</button>
                        )}
                      </div>
                    </article>
                  ))}
                  {aiState === "thinking" && !messages.some((message) => message.role === "assistant" && !message.text) && (
                    <div className="thinking-line"><span /><span /><span /> ORION denkt</div>
                  )}
                  <div ref={messageEndRef} />
                </div>
              </div>

              <div className="composer-zone">
                <div className="quick-actions">
                  {quickActions.map((action) => <button key={action.label} onClick={() => askOrion(action.prompt)}>{action.label}</button>)}
                  <button className="clear-chat-quick" onClick={clearChat} disabled={messages.length <= 1}><Icon name="trash" size={13} /> {l("Chat leeren", "Clear chat")}</button>
                </div>
                {attachment && (
                  <div className="attachment-preview">
                    <img src={attachment} alt="Ausgewähltes Bild" />
                    <span><strong>Vision bereit</strong><small>{attachmentName}</small></span>
                    <button onClick={() => { setAttachment(null); setAttachmentName(""); }}><Icon name="close" size={16} /></button>
                  </div>
                )}
                <div className={`composer ${isListening ? "listening" : ""}`}>
                  <button className="composer-action" onClick={() => fileInputRef.current?.click()} aria-label="Bild hinzufügen"><Icon name="plus" /></button>
                  <textarea
                    value={input}
                    onChange={(event) => setInput(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); askOrion(); }
                    }}
                    placeholder={isListening ? l("Ich höre zu …", "I am listening …") : l("Frag ORION oder gib eine Mission …", "Ask ORION or give it a mission …")}
                    rows={1}
                  />
                  <button className={`composer-action mic ${isListening ? "active" : ""}`} onClick={toggleListening} aria-label="Mikrofon"><Icon name="mic" /></button>
                  <button className="send-button" onClick={() => askOrion()} disabled={!input.trim() || aiState === "thinking"} aria-label="Senden"><Icon name="send" /></button>
                </div>
                <p className="composer-note"><Icon name="shield" size={13} /> {l("Zero-Owner-Cost · kein zentraler API-Key · sichere Bestätigung vor Käufen", "Zero owner cost · no central API key · confirmation required before purchases")}</p>
              </div>
            </div>
          )}

          {view === "vision" && (
            <div className="feature-view vision-view">
              <div className="feature-heading"><p className="eyebrow">MULTIMODAL VISION</p><h1>ORION Vision</h1><p>{l("Kamera, Bildschirm oder Bild analysieren – nur nach deiner Freigabe.", "Analyze camera, screen or images — only with your permission.")}</p></div>
              <div className="vision-grid">
                <div className="vision-screen">
                  {visionStream ? (
                    <video ref={videoRef} muted playsInline />
                  ) : (
                    <div className="vision-empty"><div className="scan-eye"><Icon name="eye" size={38} /></div><strong>{screenCapturePending ? l("Systemfreigabe geöffnet", "System permission opened") : gamingCoach ? l("Gaming Coach im Hintergrund aktiv", "Gaming Coach active in background") : l("Keine Quelle aktiv", "No source active")}</strong><span>{screenCapturePending ? l(gamingCoach ? "Wähle jetzt den Android-Bildschirm aus. Danach bleibt eine sichtbare Systemmeldung mit Stopp-Taste aktiv." : "Wähle jetzt den Android-Bildschirm aus. Die Aufnahme wird erst nach deiner Bestätigung erstellt.", gamingCoach ? "Select the Android screen. A visible system notification with a stop action stays active." : "Select the Android screen. Capture starts only after your confirmation.") : gamingCoach ? l("Wechsle jetzt ins Spiel. ORION verarbeitet nur die freigegebenen Frames im gewählten Abstand.", "Switch to your game. ORION only processes shared frames at the selected interval.") : l("Wähle Kamera, Bildschirm oder eine Datei.", "Choose camera, screen or an image.")}</span></div>
                  )}
                  {visionStream && <div className="live-badge"><span /> LIVE · {visionSource === "camera" ? "KAMERA" : "BILDSCHIRM"}</div>}
                  {gamingCoach && nativeAvailable && !visionStream && <div className="live-badge"><span /> LIVE · ANDROID GAMING</div>}
                  {gamingCoach && (
                    <div className={`coach-call-overlay ${coachBusy ? "thinking" : ""}`}>
                      <span>{coachBusy ? l("FRAME WIRD ANALYSIERT", "ANALYZING FRAME") : "ORION GAMING CALL"}</span>
                      <strong>{coachCall || l("Warte auf sichtbare Spielsituation …", "Waiting for a visible game situation …")}</strong>
                    </div>
                  )}
                </div>
                <div className="vision-controls">
                  <button onClick={() => startVision("camera")}><Icon name="camera" /><span><strong>{l("Kamera öffnen", "Open camera")}</strong><small>{l("Rück- oder Webcam verwenden", "Use rear camera or webcam")}</small></span></button>
                  <button onClick={() => startVision("screen")} disabled={screenCapturePending}><Icon name="monitor" /><span><strong>{nativeAvailable ? l("Handybildschirm aufnehmen", "Capture phone screen") : l("Bildschirm teilen", "Share screen")}</strong><small>{nativeAvailable ? l("Android fragt jedes Mal sichtbar nach", "Android asks visibly every time") : l("PC-Bildschirm, Fenster oder Tab freigeben", "Share a screen, window or tab")}</small></span></button>
                  <button onClick={() => fileInputRef.current?.click()}><Icon name="plus" /><span><strong>{l("Bild auswählen", "Choose image")}</strong><small>PNG, JPG or WebP</small></span></button>
                  <div className={`vision-status ${visionStream || gamingCoach ? "connected" : ""}`}><span /><div><strong>{visionStatus}</strong><small>{nativeAvailable ? l("Android kann nach der Systemfreigabe sichtbar im Vordergrund weiterlaufen.", "Android can continue visibly in the foreground after system permission.") : l("Browserfreigaben können nicht heimlich neu gestartet werden; ein erneuter Start bleibt immer sichtbar.", "Browser permissions cannot restart secretly; reconnecting always remains visible.")}</small></div></div>
                  {visionStream && <button className="primary-control" onClick={captureVision}><Icon name="eye" /><span><strong>{l("Jetzt analysieren", "Analyze now")}</strong><small>{l("Frame an ORION übergeben", "Send frame to ORION")}</small></span></button>}
                  {visionStream && (
                    <label className="toggle-row"><span><strong>Dauerblick</strong><small>Aktualisiert den Frame alle 5 Sekunden</small></span><input type="checkbox" checked={dauerblick} onChange={(event) => setDauerblick(event.target.checked)} /><i /></label>
                  )}
                  <label className="toggle-row"><span><strong>{l("Bildschirm wach halten", "Keep screen awake")}</strong><small>{l("Verhindert Schlafmodus während Vision/Gaming, soweit das Gerät es erlaubt", "Prevents sleep during Vision/Gaming when supported")}</small></span><input type="checkbox" checked={keepScreenAwake} onChange={(event) => setKeepScreenAwake(event.target.checked)} /><i /></label>
                  <section className={`gaming-coach-panel ${gamingCoach ? "active" : ""}`}>
                    <div className="gaming-coach-title"><Icon name="bolt" /><span><strong>ORION Gaming Coach</strong><small>{l("Sieht nur deinen freigegebenen Bildschirm", "Only sees your shared screen")}</small></span><b>{gamingCoach ? "LIVE" : "BEREIT"}</b></div>
                    <label><span>{l("Spiel (optional)", "Game (optional)")}</span><input value={gameName} onChange={(event) => setGameName(event.target.value)} placeholder="Valorant, Fortnite, Minecraft …" /></label>
                    <div className="coach-options">
                      <label><span>{l("Call-Abstand", "Call interval")}</span><select value={coachInterval} onChange={(event) => setCoachInterval(Number(event.target.value))}><option value={8}>8 s</option><option value={12}>12 s</option><option value={20}>20 s</option></select></label>
                      <label><span>{l("Call-Stil", "Call style")}</span><select value={gamerCallStyle} onChange={(event) => setGamerCallStyle(event.target.value)}><option value="ultrakurz">Ultra · 5 Wörter</option><option value="kurz">Taktisch · 8 Wörter</option><option value="erklärt">Erklärt · 16 Wörter</option></select></label>
                      <label className="coach-voice"><span>{l("Sprach-Calls", "Voice calls")}</span><input type="checkbox" checked={coachSpeak} onChange={(event) => setCoachSpeak(event.target.checked)} /></label>
                    </div>
                    <button className={gamingCoach ? "stop-coach" : "start-coach"} onClick={() => { void toggleGamingCoach(); }}><Icon name={gamingCoach ? "close" : "bolt"} /> {gamingCoach ? l("Coach stoppen", "Stop coach") : nativeAvailable ? l("Handybildschirm & Coach starten", "Start phone screen & coach") : l("Bildschirm teilen & Coach starten", "Share screen & start coach")}</button>
                    <p><Icon name="shield" size={13} /> {l("Jeder Frame nutzt deinen gewählten Nutzerzugang. Keine versteckten Spieldaten, keine Eingaben und kein Anti-Cheat-Bypass.", "Every frame uses your selected user connection. No hidden game data, input control, or anti-cheat bypass.")}</p>
                    {!!coachHistory.length && <div className="coach-history">{coachHistory.map((entry) => <div key={entry.id}><time>{entry.at}</time><span>{entry.text}</span></div>)}</div>}
                  </section>
                  {visionStream && <button className="danger-control" onClick={stopVision}><Icon name="close" /><span><strong>Quelle schließen</strong><small>Kamera und Freigabe beenden</small></span></button>}
                </div>
              </div>
            </div>
          )}

          {view === "missions" && (
            <div className="feature-view missions-view">
              <div className="feature-heading"><p className="eyebrow">AUTONOMOUS WORK CORE</p><h1>Mission Control</h1><p>{l("Gib ORION ein Ziel. Der Missionskern arbeitet es selbstständig aus und legt das Ergebnis hier ab.", "Give ORION a goal. Mission Control works it out and stores the result here.")}</p></div>
              <div className="mission-console">
                <section className="mission-entry">
                  <div><Icon name="bolt" size={24} /><span><strong>{l("Neue Mission", "New mission")}</strong><small>{l("Zum Beispiel: „Plane meine Woche und priorisiere ORION.“", "For example: “Plan my week and prioritize ORION.”")}</small></span></div>
                  <textarea value={missionInput} onChange={(event) => setMissionInput(event.target.value)} placeholder={l("Beschreibe das Ziel, nicht jeden einzelnen Schritt …", "Describe the goal, not every individual step …")} rows={4} />
                  <button disabled={!missionInput.trim()} onClick={() => {
                    const mission: Mission = { id: uid("mission"), task: missionInput.trim(), status: "queued", createdAt: timeNow() };
                    setMissions((current) => [mission, ...current].slice(0, 40));
                    setMissionInput("");
                  }}><Icon name="bolt" /> {l("Mission starten", "Start mission")}</button>
                </section>
                <section className="mission-list">
                  <div className="card-title"><span><Icon name="memory" /><strong>Missionsprotokoll</strong></span><small>{missions.length} Missionen</small></div>
                  {missions.length ? missions.map((mission) => (
                    <article className={`mission-item ${mission.status}`} key={mission.id}>
                      <div className="mission-meta"><span>{mission.status === "queued" ? "BEREIT" : mission.status === "running" ? "IN ARBEIT" : mission.status === "done" ? "ABGESCHLOSSEN" : "GESTOPPT"}</span><small>{mission.createdAt}</small></div>
                      <h3>{mission.task}</h3>
                      {mission.result && <div className="mission-result"><MessageText text={mission.result} /></div>}
                      <div className="mission-actions">
                        {(mission.status === "queued" || mission.status === "error") && <button onClick={() => void runMission(mission)} disabled={missionBusy}><Icon name="bolt" size={15} /> Ausführen</button>}
                        {mission.result && <button onClick={() => navigator.clipboard?.writeText(mission.result || "")}><Icon name="copy" size={15} /> Kopieren</button>}
                        <button onClick={() => setMissions((current) => current.filter((item) => item.id !== mission.id))}><Icon name="trash" size={15} /> Entfernen</button>
                      </div>
                    </article>
                  )) : <div className="mission-empty">Noch keine Mission. Sag beispielsweise: „ORION, Mission: Erstelle meinen Wochenplan.“</div>}
                </section>
              </div>
            </div>
          )}

          {view === "studio" && (
            <div className="feature-view studio-view">
              <div className="feature-heading"><p className="eyebrow">GENERATIVE STUDIO</p><h1>ORION Studio</h1><p>{l("Von der Idee zum Bild – über deinen gewählten Nutzerzugang.", "Turn an idea into an image through your selected user connection.")}</p></div>
              <div className="studio-layout">
                <div className="studio-canvas">
                  {studioImage ? <img src={studioImage} alt="Von ORION generiertes Bild" /> : <div className="studio-placeholder"><Icon name="spark" size={46} /><strong>Die Leinwand wartet.</strong><span>Beschreibe Motiv, Stil, Licht und Format möglichst konkret.</span></div>}
                  {studioBusy && <div className="studio-loading"><span className="mini-core" />ORION rendert deine Idee …</div>}
                </div>
                <div className="studio-prompt">
                  <label>Bildbeschreibung</label>
                  <textarea value={studioPrompt} onChange={(event) => setStudioPrompt(event.target.value)} placeholder="Ein futuristisches ORION-Interface über einer nächtlichen Stadt, cineastisch, cyan und gold …" rows={8} />
                  <div className="studio-options"><label><span>{l("Bildmodell", "Image model")}</span><select value={studioModel} onChange={(event) => setStudioModel(event.target.value)}><option value="gpt-image-2">GPT Image 2</option><option value="gpt-image-1-mini">GPT Image 1 Mini</option><option value="grok-imagine-image">Grok Imagine</option></select></label><label><span>{l("Qualität", "Quality")}</span><select value={studioQuality} onChange={(event) => setStudioQuality(event.target.value as "low" | "medium" | "high")}><option value="low">Low · schnell</option><option value="medium">Medium</option><option value="high">High</option></select></label><label><span>{l("Format", "Aspect ratio")}</span><select value={studioRatio} onChange={(event) => setStudioRatio(event.target.value as "1:1" | "16:9" | "9:16")}><option value="1:1">1:1</option><option value="16:9">16:9</option><option value="9:16">9:16</option></select></label></div>
                  <div className="prompt-presets">
                    {["Cinematic", "Produktdesign", "Cyberpunk", "Minimalistisch"].map((preset) => <button key={preset} onClick={() => setStudioPrompt((value) => `${value}${value ? ", " : ""}${preset}`)}>{preset}</button>)}
                  </div>
                  <button className="studio-generate" disabled={!studioPrompt.trim() || studioBusy} onClick={generateImage}><Icon name="spark" />{studioBusy ? "Generiere …" : "Bild generieren"}</button>
                  {studioError && <div className="studio-error"><Icon name="shield" size={15} />{studioError}</div>}
                  {studioImage && <button className="studio-download" onClick={() => { const anchor = document.createElement("a"); anchor.href = studioImage; anchor.download = "orion-bild.png"; anchor.target = "_blank"; anchor.click(); }}><Icon name="install" size={16} /> {l("Bild laden", "Download image")}</button>}
                </div>
              </div>
            </div>
          )}

          {view === "tools" && (
            <div className="feature-view tools-view">
              <div className="feature-heading"><p className="eyebrow">ONE APP · ORION CONTROL CENTER</p><h1>{l("Werkzeuge & Geräte", "Tools & devices")}</h1><p>{l("Timer, Übersetzer, Dateien, Games, Livestreams und Gerätestatus in einer einzigen App.", "Timers, translator, files, games, livestreams and device status in one app.")}</p></div>
              <div className="tool-tabs" role="tablist">
                {([
                  ["timer", "Timer"], ["translate", l("Übersetzer", "Translator")], ["files", l("Dateien", "Files")], ["games", "Game Lab"], ["stream", "Livestream"], ["device", l("Gerät", "Device")], ["security", l("*ICH Sicherheit", "*ICH Security")],
                ] as const).map(([id, label]) => <button key={id} className={toolTab === id ? "active" : ""} onClick={() => setToolTab(id)}>{id === "games" && <Icon name="game" size={15} />}{label}</button>)}
              </div>

              {toolTab === "timer" && (
                <div className="tool-layout timer-lab">
                  <section className="tool-card tool-form"><p className="eyebrow">VISIBLE TIMER</p><h2>{l("Zeit einstellen", "Set time")}</h2><div className="timer-input-row"><input type="number" min="1" max="10080" value={timerValue} onChange={(event) => setTimerValue(Number(event.target.value))} /><select value={timerUnit} onChange={(event) => setTimerUnit(event.target.value as TimerUnit)}><option value="seconds">{l("Sekunden", "Seconds")}</option><option value="minutes">{l("Minuten", "Minutes")}</option><option value="hours">{l("Stunden", "Hours")}</option></select></div><input value={timerLabel} onChange={(event) => setTimerLabel(event.target.value)} placeholder={l("Name des Timers", "Timer name")} /><button className="primary-tool" onClick={() => createTimer(timerValue, timerUnit, timerLabel)}><Icon name="plus" /> {l("Timer starten", "Start timer")}</button><small>{l("Sprachbefehl: „Timer 5 Sekunden“. Die Zeit bleibt ab jetzt sichtbar.", "Voice command: “Timer 5 seconds”. Remaining time stays visible.")}</small></section>
                  <section className="tool-card timer-list"><div className="card-title"><span><Icon name="bolt" /><strong>Aktive Timer</strong></span><small>{timers.filter((timer) => !timer.completed).length}</small></div>{timers.length ? timers.map((timer) => <article className={`timer-item ${timer.completed ? "done" : ""}`} key={timer.id}><div><strong>{timer.label}</strong><small>{timer.completed ? "ABGELAUFEN" : new Date(timer.endsAt).toLocaleTimeString(speechLanguage, { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</small></div><b>{timer.completed ? "00:00:00" : formatRemaining(timer.endsAt - now)}</b><button onClick={() => setTimers((current) => current.filter((item) => item.id !== timer.id))}><Icon name="close" size={16} /></button></article>) : <div className="empty-list">Noch kein Timer aktiv.</div>}</section>
                </div>
              )}

              {toolTab === "translate" && (
                <div className="tool-layout translator-lab"><section className="tool-card"><p className="eyebrow">OFFLINE + ONLINE</p><h2>ORION Translator</h2><textarea rows={8} value={translateInput} onChange={(event) => setTranslateInput(event.target.value)} placeholder={l("Text zum Übersetzen …", "Text to translate …")} /><label className="settings-field"><span>{l("Zielsprache", "Target language")}</span><select value={translateTarget} onChange={(event) => setTranslateTarget(event.target.value)}>{LANGUAGES.map((language) => <option key={language.id} value={language.id}>{language.label}</option>)}</select></label><button className="primary-tool" onClick={translateText}><Icon name="globe" /> {l("Übersetzen", "Translate")}</button><small>{l("Grundbegriffe funktionieren offline; freie Sätze werden mit deinem gewählten Zugang übersetzt.", "Basic phrases work offline; free-form text uses your selected connection.")}</small></section><section className="tool-card result-card"><p className="eyebrow">RESULT</p><div className="translation-output">{translateOutput || l("Die Übersetzung erscheint hier.", "Translation appears here.")}</div>{translateOutput && <button onClick={() => navigator.clipboard?.writeText(translateOutput)}><Icon name="copy" size={16} /> {l("Kopieren", "Copy")}</button>}</section></div>
              )}

              {toolTab === "files" && (
                <div className="tool-layout file-lab"><section className="tool-card"><p className="eyebrow">ORION FILE STUDIO</p><h2>{l("Datei erstellen", "Create file")}</h2><input value={fileTitle} onChange={(event) => setFileTitle(event.target.value)} placeholder={l("Dateiname / Titel", "Filename / title")} /><div className="file-format-row">{(["txt", "md", "html", "doc", "pdf"] as const).map((format) => <button key={format} className={fileFormat === format ? "active" : ""} onClick={() => setFileFormat(format)}>.{format}</button>)}</div><textarea rows={12} value={fileContent} onChange={(event) => setFileContent(event.target.value)} placeholder={l("Schreibe Inhalt oder eine Aufgabe, die ORION ausarbeiten soll …", "Write content or a task for ORION to develop …")} /><div className="tool-button-row"><button onClick={generateFileDraft}><Icon name="spark" /> {l("Mit ORION ausarbeiten", "Develop with ORION")}</button><button className="primary-tool" onClick={createDocument} disabled={!fileContent.trim()}><Icon name="install" /> {l("Datei laden", "Download file")}</button></div></section><section className="tool-card result-card"><p className="eyebrow">FILE PREVIEW</p><h2>{fileTitle}</h2><div className="document-preview">{fileContent || l("Noch kein Inhalt.", "No content yet.")}</div><small>{l("HTML, Text, Markdown, Word-kompatibles DOC und echtes lokales PDF. Die Datei wird auf deinem Gerät erzeugt.", "HTML, text, Markdown, Word-compatible DOC and a real local PDF. The file is created on your device.")}</small></section></div>
              )}

              {toolTab === "games" && (
                <div className="gamer-suite">
                  <section className="gamer-command-center">
                    <div className="gamer-command-hero"><img src="/orion-gamer.svg" alt="ORION Gamer Icon" /><div><p className="eyebrow">ORION GAMER · STREAMER CORE</p><h2>{creatorName || "Dein"} Control Center</h2><span>{gamerRole} · {performanceMode ? "Performance aktiv" : "Qualität aktiv"}</span></div><a href="/downloads/ORION-Gamer-Icon.svg" download aria-label="ORION Gamer Icon laden"><Icon name="install" size={17} /></a></div>
                    <div className="gamer-profile-grid"><label><span>Creator-/Gamer-Name</span><input value={creatorName} onChange={(event) => setCreatorName(event.target.value)} placeholder="Barys" /></label><label><span>Rolle / Spielstil</span><input value={gamerRole} onChange={(event) => setGamerRole(event.target.value)} placeholder="IGL + Fragger" /></label><label><span>Aktives Spiel</span><input value={gameName} onChange={(event) => setGameName(event.target.value)} placeholder="Fortnite, Valorant, Minecraft …" /></label><label><span>Coach-Calls</span><select value={gamerCallStyle} onChange={(event) => setGamerCallStyle(event.target.value)}><option value="ultrakurz">Ultra · 5 Wörter</option><option value="kurz">Taktisch · 8 Wörter</option><option value="erklärt">Erklärt · 16 Wörter</option></select></label></div>
                    <div className="gamer-toggle-grid"><button className={performanceMode ? "active" : ""} onClick={() => setPerformanceMode((value) => !value)}><Icon name="bolt" /><span><strong>Performance Mode</strong><small>Kleinere Frames, weniger Verzögerung</small></span></button><button className={streamerMode ? "active" : ""} onClick={() => setStreamerMode((value) => !value)}><Icon name="radio" /><span><strong>Streamer Mode</strong><small>Chat, Antworten und Creator-Profil</small></span></button><button className={autoRepair ? "active" : ""} onClick={() => setAutoRepair((value) => !value)}><Icon name="shield" /><span><strong>Auto Repair</strong><small>Verbindungen selbstständig stabilisieren</small></span></button></div>
                    <div className="gamer-quick-actions"><button onClick={() => { setView("vision"); setMode("gaming"); }}><Icon name="eye" /> Gaming Coach</button><button onClick={() => setToolTab("stream")}><Icon name="radio" /> Stream Center</button><button onClick={() => openDeviceApp(gameName.trim() || "Fortnite", `https://play.google.com/store/search?q=${encodeURIComponent(gameName.trim() || "Fortnite")}&c=apps`)}><Icon name="game" /> Spiel öffnen</button><button onClick={() => void runSystemRepair(false)}><Icon name="shield" /> Stabilität prüfen</button></div>
                    <div className={`stability-strip ${stabilityState}`}><span /><div><strong>{stabilityState === "checking" ? "ORION prüft …" : stabilityState === "warning" ? "Hinweis erkannt" : "System stabil"}</strong><small>{lastRepair} · {recoveryCount} automatische Reparaturen</small></div></div>
                  </section>
                  <div className="game-lab"><section className="tool-card game-controls"><p className="eyebrow">ORION GAME LAB</p><h2>Spiel bauen & automatisch reparieren</h2><textarea rows={4} value={gamePrompt} onChange={(event) => setGamePrompt(event.target.value)} placeholder="Zum Beispiel: Schach gegen einen Bot mit legalen Zügen …" /><label className="settings-field"><span>Bot-Schwierigkeit</span><select value={gameDifficulty} onChange={(event) => setGameDifficulty(event.target.value)}><option value="leicht">Leicht</option><option value="normal">Normal</option><option value="schwer">Schwer</option><option value="meister">Meister</option></select></label><button className="primary-tool" disabled={gameBusy || !gamePrompt.trim()} onClick={() => void generateGame(false)}><Icon name="spark" /> {gameBusy ? "Game wird geprüft …" : "Game erstellen"}</button>{gameCode && <><div className="bug-fix-box"><label>Bug-Fix für dieses Game</label><textarea rows={3} value={gameBug} onChange={(event) => setGameBug(event.target.value)} placeholder="Beschreibe den Fehler, z. B. Bauer bewegt sich frei …" /><button onClick={() => void generateGame(true)} disabled={gameBusy}><Icon name="bolt" /> Code prüfen & reparieren</button></div><button onClick={() => downloadBlob(new Blob([gameCode], { type: "text/html;charset=utf-8" }), `${safeFilename(gamePrompt)}.html`)}><Icon name="install" /> Game als HTML laden</button></>}</section><section className="game-screen">{gameCode ? <iframe title="ORION Game Vorschau" srcDoc={gameCode} sandbox="allow-scripts allow-pointer-lock" /> : <div className="studio-placeholder"><Icon name="game" size={42} /><strong>Noch kein Game geladen</strong><span>Erstelle ein Spiel; die Vorschau läuft isoliert und kann dein Gerät nicht verändern.</span></div>}</section></div>
                </div>
              )}

              {toolTab === "stream" && (
                <div className="tool-layout stream-lab">
                  <section className="tool-card"><p className="eyebrow">LIVE STREAM PLAYER</p><h2>Stream-Link öffnen</h2><input value={streamUrl} onChange={(event) => setStreamUrl(event.target.value)} placeholder="YouTube-, Twitch-, TikTok- oder X-Link …" /><button className="primary-tool" onClick={() => setActiveStreamUrl(streamEmbedUrl(streamUrl))} disabled={!streamEmbedUrl(streamUrl)}><Icon name="eye" /> Stream laden</button><small>YouTube und Twitch können direkt eingebettet werden. Plattformen, die Einbettung sperren, lassen sich extern anzeigen. ORION sieht Videoinhalte nur nach deiner ausdrücklichen Bildschirmfreigabe.</small>{activeStreamUrl && <button onClick={() => openExternal(streamUrl)}><Icon name="globe" /> Extern öffnen</button>}</section>
                  <section className="stream-screen">{activeStreamUrl ? <iframe title="ORION Livestream" src={activeStreamUrl} allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" /> : <div className="studio-placeholder"><Icon name="monitor" size={42} /><strong>Kein Stream geladen</strong><span>Füge links einen Live-Link ein.</span></div>}</section>
                  <section className="stream-chat-copilot">
                    <div className="stream-chat-head"><div><p className="eyebrow">*ICH · STREAM CHAT COPILOT</p><h2>{l("Nachrichten lesen, ohne Wiederholungen antworten", "Read messages and reply without repetition")}</h2><small>{streamChatStatus}</small></div><span><Icon name="shield" size={14} /> {l("Chat bleibt lokal", "Chat stays local")}</span></div>
                    <div className="stream-chat-connect"><input value={streamChannel} onChange={(event) => setStreamChannel(event.target.value)} placeholder="Twitch-Kanal, z. B. shroud" /><button className={streamChatConnected ? "connected" : ""} onClick={streamChatConnected ? disconnectStreamChat : connectTwitchChat}><Icon name={streamChatConnected ? "close" : "radio"} /> {streamChatConnected ? l("Trennen", "Disconnect") : l("Twitch-Chat live lesen", "Read Twitch chat live")}</button></div>
                    <div className="stream-chat-import"><textarea rows={3} value={streamChatImport} onChange={(event) => setStreamChatImport(event.target.value)} placeholder={l("Für YouTube, TikTok oder X Nachrichten einfügen: Name: Nachricht", "For YouTube, TikTok, or X paste messages: Name: message")} /><button onClick={importStreamMessages} disabled={!streamChatImport.trim()}><Icon name="plus" /> {l("Duplikatfrei übernehmen", "Import without duplicates")}</button></div>
                    <div className="stream-chat-list">{streamChatMessages.length ? [...streamChatMessages].reverse().map((message) => <article className={message.answered ? "answered" : ""} key={message.id}><header><strong>{message.user}</strong><time>{message.at}</time></header><p>{message.text}</p>{message.reply && <blockquote>{message.reply}</blockquote>}<div><button onClick={() => void draftStreamReply(message.id)} disabled={message.drafting}>{message.drafting ? l("Entwurf läuft …", "Drafting …") : message.reply ? l("Neu formulieren", "Rewrite") : l("Antwort vorschlagen", "Suggest reply")}</button>{message.reply && <button className="use-reply" onClick={() => copyStreamReply(message.id)}><Icon name="copy" size={14} /> {message.answered ? l("Kopiert · beantwortet", "Copied · answered") : l("Kopieren & Chat öffnen", "Copy & open chat")}</button>}</div></article>) : <div className="empty-list">{l("Noch keine Chat-Nachrichten. Twitch live verbinden oder Nachrichten anderer Plattformen einfügen.", "No chat messages yet. Connect Twitch live or paste messages from another platform.")}</div>}</div>
                    <p className="stream-api-note"><Icon name="shield" size={14} /> {l("Twitch kann öffentlich und duplikatfrei gelesen werden. Direktes Senden sowie YouTube/TikTok/X-Livezugriff benötigen die persönliche Plattform-Anmeldung und deren OAuth-Rechte; bis dahin kopiert ORION den Entwurf und öffnet den Chat.", "Twitch can be read publicly with duplicate filtering. Direct sending and YouTube/TikTok/X live access require your platform login and OAuth permissions; until then ORION copies the draft and opens chat.")}</p>
                  </section>
                </div>
              )}

              {toolTab === "device" && (
                <div className="tool-layout device-lab"><section className="tool-card device-card"><p className="eyebrow">{flag} {platform === "Android" || platform === "iOS" ? "MOBILGERÄT" : "COMPUTER"}</p><h2>{deviceFacts.model}</h2>{Object.entries(deviceFacts).filter(([key]) => key !== "model").map(([key, value]) => <div className="metric-row" key={key}><span>{{ platform: "System", browser: "Browser", screen: "Bildschirm", memory: "Arbeitsspeicher", cpu: "Prozessor", battery: "Akku", network: "Netzwerk", temperature: "Temperatur" }[key] || key}</span><strong>{value}</strong></div>)}<p className="device-limit">Exaktes Modell und Temperatur werden nur angezeigt, wenn das Betriebssystem sie freigibt. Browser dürfen diese Daten oft absichtlich nicht auslesen.</p></section><section className="tool-card"><p className="eyebrow">APP CONTROL</p><h2>Gerätezugriff</h2><div className="capability-grid"><div><strong>Apps öffnen</strong><small>{nativeAvailable || desktopAvailable ? "Native Bridge bereit" : "Web-/Store-Fallback"}</small></div><div><strong>Text einsetzen</strong><small>{nativeAvailable ? "Android Bedienungshilfe" : desktopAvailable ? "Desktop-Freigabe" : "Zwischenablage"}</small></div><div><strong>Bildschirm</strong><small>{nativeAvailable ? "Android Aufnahmefreigabe" : "Browser-Freigabe"}</small></div><div><strong>iOS</strong><small>Apps öffnen; systemweites Tippen ist von Apple gesperrt</small></div></div><button className="primary-tool" onClick={() => openExternal(platform === "iOS" ? "https://apps.apple.com/us/search?term=orion%20assistant" : "https://play.google.com/store/search?q=orion%20assistant&c=apps")}><Icon name="globe" /> App im Store suchen</button><button onClick={() => setStandbyOrbOpen(true)}><Icon name="phone" /> Standby-Kreis öffnen</button></section></div>
              )}

              {toolTab === "security" && (
                <div className="tool-layout security-lab"><section className="tool-card security-center"><p className="eyebrow">*ICH · NEUE FUNKTION 1</p><h2>Sicherheits- & Stabilitätszentrale</h2><div className="security-check good"><Icon name="shield" /><span><strong>Owner-Kostenschutz</strong><small>Kein zentraler API-Key im öffentlichen Code</small></span></div><div className={`security-check ${connectionMode === "account" ? "good" : apiKey ? "good" : "warn"}`}><Icon name="shield" /><span><strong>KI-Verbindung</strong><small>{connectionMode === "account" ? "Jeder Nutzer mit eigenem Konto" : apiKey ? `${apiDetectedProvider} · ${apiModel}` : "Eigene API noch unvollständig"}</small></span></div><div className="security-check good"><Icon name="shield" /><span><strong>Kauf-Sperre</strong><small>Bezahlen und irreversible Aktionen verlangen deine Bestätigung</small></span></div><div className={`security-check ${nativeAvailable || desktopAvailable ? "good" : "warn"}`}><Icon name="monitor" /><span><strong>Native Bridge</strong><small>{nativeAvailable || desktopAvailable ? "Verbunden" : "Nur Web-Rechte verfügbar"}</small></span></div><div className={`security-check ${stabilityState === "warning" ? "warn" : "good"}`}><Icon name="bolt" /><span><strong>Auto Repair</strong><small>{lastRepair}</small></span></div><button className="primary-tool" onClick={() => void runSystemRepair(false)}><Icon name="shield" /> Vollständige Diagnose & Reparatur</button></section><section className="tool-card audit-card"><p className="eyebrow">*ICH · NEUE FUNKTION 2</p><h2>Geräte-Aktionsprotokoll</h2><p>ORION zeigt lokal, welche Timer, Dateien oder Geräteaktionen ausgeführt wurden. Das Protokoll verlässt dein Gerät nicht.</p><div className="audit-list">{auditLog.length ? auditLog.map((item) => <div key={item.id}><span>{item.text}</span><small>{item.at}</small></div>) : <div className="empty-list">Noch keine protokollierte Aktion.</div>}</div><button onClick={() => setAuditLog([])}><Icon name="trash" /> Protokoll leeren</button></section></div>
              )}
            </div>
          )}

          {view === "memory" && (
            <div className="feature-view memory-view">
              <div className="feature-heading"><p className="eyebrow">PRIVATE NEURAL MEMORY</p><h1>{l("Das Gehirn von ORION", "ORION Brain")}</h1><p>{l("Hier siehst du, welche privaten Daten ORION wirklich besitzt, speichert und für Antworten verwendet.", "See exactly which private data ORION stores and uses for responses.")}</p></div>
              <section className="brain-dashboard">
                <div className="brain-visual" aria-label="Visualisierung des privaten ORION-Gehirns"><div className="brain-lobe left"><i /><i /><i /></div><div className="brain-lobe right"><i /><i /><i /></div><div className="brain-core"><span /><strong>ORION</strong><small>PRIVATE CORE</small></div><b className="synapse s1" /><b className="synapse s2" /><b className="synapse s3" /><b className="synapse s4" /></div>
                <div className="brain-data-grid">
                  <article><Icon name="chat" /><span><strong>{messages.length}</strong><small>{l("Chat-Einträge", "Chat entries")}</small></span><em>{l(`Letzte ${API_PROFILES[apiProfile].history} bilden den Antwortkontext`, `Latest ${API_PROFILES[apiProfile].history} form response context`)}</em></article>
                  <article><Icon name="memory" /><span><strong>{memory.length}</strong><small>{l("Langzeit-Fakten", "Long-term facts")}</small></span><em>{l("Werden in Antworten berücksichtigt", "Used in responses")}</em></article>
                  <article><Icon name="bolt" /><span><strong>{commands.length}</strong><small>{l("Eigene Befehle", "Custom commands")}</small></span><em>{l("Lokal vor der KI ausgeführt", "Run locally before AI")}</em></article>
                  <article><Icon name="spark" /><span><strong>{missions.length}</strong><small>{l("Missionen", "Missions")}</small></span><em>{l("Ergebnisse bleiben auf deinem Gerät", "Results remain on your device")}</em></article>
                  <article><Icon name="shield" /><span><strong>{cloudSignedIn ? "SYNC" : "LOCAL"}</strong><small>{l("Speicherort", "Storage")}</small></span><em>{cloudSignedIn ? l("Privat im eigenen Puter-Konto synchronisiert", "Privately synced to your Puter account") : l("Nur in diesem Browserprofil", "Only in this browser profile")}</em></article>
                  <article><Icon name="settings" /><span><strong>{connectionMode === "api" ? "API" : "USER"}</strong><small>{l("KI-Zugang", "AI connection")}</small></span><em>{l("Niemals mit fremden Nutzern geteilt", "Never shared with other users")}</em></article>
                </div>
                <p><Icon name="shield" size={15} /> {l("Kein anderer ORION-Nutzer kann diesen Chat oder dieses Gehirn sehen. Browserdaten können durch Löschen des Browserprofils verloren gehen; nutze deshalb Backup oder deine persönliche Synchronisierung.", "No other ORION user can see this chat or brain. Browser data can be lost if the browser profile is cleared; use backup or personal sync.")}</p>
              </section>
              <div className="memory-columns">
                <section className="memory-card">
                  <div className="card-title"><span><Icon name="memory" /><strong>Persönliche Fakten</strong></span><small>{memory.length} gespeichert</small></div>
                  <div className="memory-form"><input value={memoryKey} onChange={(event) => setMemoryKey(event.target.value)} placeholder="Schlüssel, z. B. Lieblingsspiel" /><input value={memoryValue} onChange={(event) => setMemoryValue(event.target.value)} placeholder="Wert, z. B. Fortnite" /><button onClick={addMemory}><Icon name="plus" /> Speichern</button></div>
                  <div className="memory-list">
                    {memory.length ? memory.map((item) => <div className="memory-item" key={item.id}><span><strong>{item.key}</strong><small>{item.value}</small></span><button onClick={() => setMemory((current) => current.filter((fact) => fact.id !== item.id))}><Icon name="trash" size={16} /></button></div>) : <div className="empty-list">Sag zum Beispiel: „Merk dir Lieblingsspiel = Fortnite“.</div>}
                  </div>
                </section>
                <section className="memory-card">
                  <div className="card-title"><span><Icon name="bolt" /><strong>Eigene Befehle</strong></span><small>{commands.length} aktiv</small></div>
                  <div className="memory-form"><input value={commandPhrase} onChange={(event) => setCommandPhrase(event.target.value)} placeholder="Befehl, z. B. Projektmodus" /><textarea value={commandInstruction} onChange={(event) => setCommandInstruction(event.target.value)} placeholder="Was ORION dann tun soll …" rows={3} /><button onClick={addCommand}><Icon name="plus" /> Befehl anlegen</button></div>
                  <div className="memory-list">
                    {commands.length ? commands.map((command) => <div className="memory-item command" key={command.id}><span><strong>„{command.phrase}“</strong><small>{command.instruction}</small></span><button onClick={() => setCommands((current) => current.filter((item) => item.id !== command.id))}><Icon name="trash" size={16} /></button></div>) : <div className="empty-list">Eigene Kurzbefehle erscheinen hier.</div>}
                  </div>
                </section>
              </div>
              <div className="memory-actions"><button onClick={exportData}>Backup exportieren</button><button onClick={() => importInputRef.current?.click()}>Backup importieren</button></div>
            </div>
          )}
        </section>

        <aside className="context-panel">
          <section className="context-card identity-card">
            <div className={`context-core ${aiState}`}><span /></div>
            <div><small>AKTIVE INSTANZ</small><strong>ORION V1</strong><span>{MODES.find((item) => item.id === mode)?.label}-Modus</span></div>
          </section>
          <section className="context-card">
            <div className="context-title"><span>System</span><small>LIVE</small></div>
            <div className="metric-row"><span>Plattform</span><strong>{platform}</strong></div>
            <div className="metric-row"><span>KI-Kern</span><strong>{connectionMode === "api" ? apiModel || "Auto" : MODELS[modelTier].label}</strong></div>
            <div className="metric-row"><span>Netzwerk</span><strong className={isOnline ? "good" : "warn"}>{isOnline ? "Online" : "Offline"}</strong></div>
            <div className="metric-row"><span>Latenz</span><strong>{lastLatency ? `${(lastLatency / 1000).toFixed(1)} s` : "Bereit"}</strong></div>
          </section>
          <section className="context-card">
            <div className="context-title"><span>Modus</span><small>{mode === "overdrive" ? "MAX" : "AUTO"}</small></div>
            <select value={mode} onChange={(event) => setMode(event.target.value)}>{MODES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select>
            <button className={`web-toggle ${liveWeb ? "active" : ""}`} onClick={() => setLiveWeb((value) => !value)}><Icon name="globe" size={17} /><span>Live-Web</span><small>{liveWeb ? "An" : "Aus"}</small></button>
          </section>
          <section className="context-card radio-card">
            <div className="context-title"><span>ORION Radio</span><small>{radioPlaying ? "LIVE" : "BEREIT"}</small></div>
            <select value={radioStation} onChange={(event) => { setRadioStation(event.target.value); if (radioPlaying) playRadio(event.target.value); }}>{RADIO_STATIONS.map((station) => <option key={station.id} value={station.id}>{station.label} · {station.note}</option>)}</select>
            <div className="now-playing"><span className={radioPlaying ? "pulse" : ""} /><span><small>JETZT LÄUFT</small><strong>{radioTrack}</strong></span></div>
            <button className={`web-toggle ${radioPlaying ? "active" : ""}`} onClick={() => radioPlaying ? stopRadio() : playRadio()}><Icon name="radio" size={17} /><span>{radioPlaying ? "Radio stoppen" : "Radio starten"}</span><small>{radioPlaying ? "An" : "Aus"}</small></button>
          </section>
          <section className="context-card bridge-card">
            <div className="context-title"><span>Gerätesteuerung</span><small>BETA</small></div>
            <p>{nativeAvailable ? "Android Bridge verbunden: Standby-Sprache und freigegebene Geräteaktionen sind verfügbar." : desktopAvailable ? "Desktop Bridge verbunden: Webseiten öffnen sowie Text kopieren und in die vorher aktive App einsetzen." : "Web Control ist aktiv. Systemweite Aktionen benötigen die installierte ORION-App und die Betriebssystem-Freigabe."}</p>
            <div className="bridge-status"><span /><span>{nativeAvailable ? "Android Control verbunden" : desktopAvailable ? "Desktop Control verbunden" : "Web Control bereit"}</span></div>
          </section>
          <button className="overdrive-button" onClick={() => { setMode(mode === "overdrive" ? "assistant" : "overdrive"); setView("chat"); }}><Icon name="bolt" /><span><strong>{mode === "overdrive" ? "Overdrive beenden" : "Overdrive aktivieren"}</strong><small>Maximum Intelligence</small></span></button>
        </aside>
      </section>

      <nav className="mobile-nav" aria-label="Mobile Navigation">
        {([[
          "chat", "chat", "Chat"], ["missions", "bolt", "Mission"], ["vision", "eye", "Vision"], ["studio", "spark", "Studio"], ["tools", "bolt", "Tools"], ["memory", "memory", "Memory"]] as const).map(([id, icon, label]) => <button key={id} className={view === id ? "active" : ""} onClick={() => setView(id)}><Icon name={icon} /><span>{label}</span></button>)}
      </nav>

      {bootVisible && (
        <div className="orion-boot" aria-label="ORION startet">
          <div className="boot-core"><span className="ring ring-one" /><span className="ring ring-two" /><span className="ring ring-three" /><span className="core-light" /></div>
          <p className="eyebrow">SPECTRUM X · ORION INITIALIZATION</p><h1>ORION</h1><div className="boot-progress"><span style={{ width: `${bootProgress}%` }} /></div><strong>{bootProgress < 47 ? "Sicherheitskern wird geprüft" : bootProgress < 69 ? "Stimmen & Sprachen werden geladen" : bootProgress < 100 ? "Gerätebrücke wird verbunden" : "SYSTEM BEREIT"}</strong><small>{bootProgress}%</small>
        </div>
      )}

      {onboardingOpen && !bootVisible && (
        <div className="modal-backdrop onboarding-backdrop">
          <section className="modal onboarding-modal" role="dialog" aria-modal="true" aria-label="ORION Einrichtung">
            <div className="onboarding-hero"><img className="onboarding-logo" src="/orion.svg" alt="ORION Spectrum X Logo" /><p className="eyebrow">SPECTRUM X · ONE APP · YOUR ORION</p><h2>{l("Hallo, ich bin ORION.", "Hello, I am ORION.")}</h2><p>{l("Richte Stimme, Sprache, Persönlichkeit und Leistungsprofil vor dem ersten Gespräch ein.", "Choose voice, language, personality, and performance profile before your first conversation.")}</p></div>
            <div className="onboarding-grid"><label className="settings-field"><span>{l("Wie soll ich dich ansprechen?", "How should I address you?")}</span><input value={preferredName} onChange={(event) => setPreferredName(event.target.value)} placeholder={l("Meister", "Master")} maxLength={40} /></label><label className="settings-field"><span>{l("Sprache der ganzen App", "Language for the whole app")}</span><select value={speechLanguage} onChange={(event) => setSpeechLanguage(event.target.value)}>{LANGUAGES.map((language) => <option key={language.id} value={language.id}>{language.label}</option>)}</select></label><label className="settings-field"><span>{l("ORION-Geschlecht", "ORION gender")}</span><select value={assistantGender} onChange={(event) => { const gender = event.target.value as AssistantGender; setAssistantGender(gender); const voice = VOICE_PROFILES.find((item) => item.gender === gender); if (voice) setVoiceProfile(voice.id); }}><option value="female">{l("Weiblich", "Female")}</option><option value="male">{l("Männlich / JARVIS-Stil", "Male / JARVIS style")}</option><option value="neutral">Neutral</option></select></label><label className="settings-field"><span>{t("personality")}</span><select value={mode} onChange={(event) => setMode(event.target.value)}>{MODES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select></label><label className="settings-field"><span>{l("Aktivierungswort", "Wake word")}</span><input value={wakeWord} onChange={(event) => setWakeWord(event.target.value)} placeholder="Orion" maxLength={24} /></label><label className="settings-field"><span>{l("Persönlichkeitsstärke", "Personality strength")}</span><select value={personalityStrength} onChange={(event) => setPersonalityStrength(Number(event.target.value))}><option value={0}>{l("Minimal", "Minimal")}</option><option value={1}>{l("Leicht", "Light")}</option><option value={2}>{l("Natürlich", "Natural")}</option><option value={3}>{l("Stark", "Strong")}</option><option value={4}>{l("Sehr real", "Very expressive")}</option></select></label></div>
            <div className="onboarding-presets"><label>{l("ORION-Profil wählen", "Choose an ORION profile")}</label><div><button onClick={() => { setMode("assistant"); setRelationshipCloseness(2); setApiProfile("balanced"); setPerformanceMode(false); }}><Icon name="memory" /><span><strong>Alltag Smart</strong><small>Warm · ausgewogen · persönlich</small></span></button><button onClick={() => { setMode("gaming"); setRelationshipCloseness(1); setApiProfile("supersaver"); setMemoryLearningEnabled(false); setPerformanceMode(true); setStreamerMode(true); }}><Icon name="game" /><span><strong>Gamer & Streamer</strong><small>Schnelle Calls · wenig Verzögerung</small></span></button><button onClick={() => { setMode("friend"); setRelationshipCloseness(4); setApiProfile("balanced"); }}><Icon name="shield" /><span><strong>Liebevoll kontrolliert</strong><small>Nah, aber niemals übertrieben</small></span></button></div></div>
            <div className="onboarding-voices"><label>{l("Stimme auswählen und direkt anhören", "Choose and preview a voice")}</label><div className="voice-grid">{VOICE_PROFILES.filter((voice) => assistantGender === "neutral" || voice.gender === assistantGender).map((voice) => <button key={voice.id} className={voiceProfile === voice.id ? "active" : ""} onClick={() => { setVoiceProfile(voice.id); setAssistantGender(voice.gender); }}><strong>{voice.label}</strong><small>{voice.note}</small></button>)}</div><button className="voice-test" onClick={() => speak(VOICE_PREVIEW[speechLanguage] || VOICE_PREVIEW["en-US"])}><Icon name="volume" /> {l("„Hallo, ich bin ORION“ abspielen", "Play “Hello, I am ORION”")}</button><small>{l("Ohne Anmeldung nutzt die Vorschau die beste Stimme deines Geräts. Mit persönlicher Anmeldung wird die professionelle Neural-Stimme aktiviert.", "Without signing in, preview uses the best device voice. A personal account activates the professional neural voice.")}</small></div>
            <div className="onboarding-connection"><label>{l("Zugang wählen", "Choose connection")}</label><div className="connection-choice"><button className={connectionMode === "account" ? "active" : ""} onClick={() => setConnectionMode("account")}><Icon name="shield" /><span><strong>{l("Anmeldung", "Sign in")}</strong><small>{l("Ohne API-Key", "Without API key")}</small></span></button><button className={connectionMode === "api" ? "active" : ""} onClick={() => setConnectionMode("api")}><Icon name="bolt" /><span><strong>{l("Eigene API", "Own API")}</strong><small>{l("Später in Einstellungen eintragen", "Configure later in settings")}</small></span></button></div></div>
            <div className="onboarding-privacy"><Icon name="shield" /><span><strong>{l("Dein privater ORION", "Your private ORION")}</strong><small>{l("Chats und Erinnerungen gehören nur diesem Browserprofil oder deinem eigenen Konto – niemals anderen Nutzern.", "Chats and memories belong only to this browser profile or your own account — never other users.")}</small></span></div><div className="onboarding-actions">{connectionMode === "account" && !cloudSignedIn && <button onClick={() => void signInToCloud()} disabled={authBusy}><Icon name="shield" /> {l("Optional jetzt anmelden", "Optional: sign in now")}</button>}<button className="primary-tool" onClick={() => { localStorage.setItem(STORAGE.onboarding, "done"); setOnboardingOpen(false); setMessages((current) => current.length === 1 ? [{ ...current[0], text: `${VOICE_PREVIEW[speechLanguage] || VOICE_PREVIEW["en-US"]} ${preferredName}.`, createdAt: "SYSTEM" }] : current); }}><Icon name="bolt" /> {l("ORION starten", "Start ORION")}</button></div>
          </section>
        </div>
      )}

      {standbyOrbOpen && (
        <div className="standby-orb-panel"><button className="standby-close" onClick={() => setStandbyOrbOpen(false)}><Icon name="close" size={16} /></button><div className={`standby-orb ${aiState} ${isListening ? "listening" : ""}`}><span /></div><strong>{isListening ? "Ich höre zu …" : `Sag „Hey ${wakeWord}“`}</strong><small>{nativeAvailable ? "Android-Standbydienst kann im Hintergrund weiterlaufen." : "Im Web bleibt der Kreis nur sichtbar, solange ORION geöffnet ist."}</small><button onClick={toggleListening}><Icon name="mic" /> {isListening ? "Zuhören stoppen" : "Jetzt sprechen"}</button></div>
      )}

      {livePanelOpen && (
        <div className="live-call-backdrop">
          <section className="live-call-panel" role="dialog" aria-modal="true" aria-label="ORION Live-Gespräch">
            <button className="live-call-minimize" onClick={() => setLivePanelOpen(false)} aria-label="Live-Gespräch minimieren"><span /> Minimieren</button>
            <p className="eyebrow">ORION LIVE CONNECTION</p>
            <div className={`live-call-core ${aiState} ${isListening ? "listening" : ""}`}><span /></div>
            <h2>{aiState === "thinking" ? "Ich denke nach" : aiState === "speaking" ? "Ich antworte" : isListening ? "Ich höre dir zu" : "Verbindung aktiv"}</h2>
            <p className="live-call-state">Sprich einfach natürlich auf {LANGUAGES.find((language) => language.id === speechLanguage)?.label}. Nach jeder Antwort hört ORION automatisch weiter.</p>
            <strong className="live-call-time">{callDuration(liveSeconds)}</strong>
            <div className="live-call-security"><Icon name="shield" size={14} /> Kein Betreiber-API-Key · keine KI-Rechnung an Spectrum X</div>
            <div className="live-call-controls">
              <button className={autoSpeak ? "active" : ""} onClick={() => setAutoSpeak((value) => !value)}><Icon name="volume" /><span>{autoSpeak ? "Lautsprecher an" : "Lautsprecher aus"}</span></button>
              <button onClick={() => { setLivePanelOpen(false); setView("vision"); }}><Icon name="monitor" /><span>Bildschirm</span></button>
              <button className="end-call" onClick={endLiveCall}><Icon name="phone" /><span>Beenden</span></button>
            </div>
          </section>
        </div>
      )}

      {settingsOpen && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setSettingsOpen(false); }}>
          <section className="modal settings-modal" role="dialog" aria-modal="true" aria-label="ORION Einstellungen">
            <div className="modal-header"><div><p className="eyebrow">SYSTEM CONFIGURATION</p><h2>{t("settings")}</h2></div><button onClick={() => setSettingsOpen(false)}><Icon name="close" /></button></div>
            <div className="settings-section connection-settings">
              <label>{l("KI-Verbindung · eine App, zwei Wege", "AI connection · one app, two options")}</label>
              <div className="connection-choice"><button className={connectionMode === "account" ? "active" : ""} onClick={() => setConnectionMode("account")}><Icon name="shield" /><span><strong>{l("Anmeldung", "Sign in")}</strong><small>{l("Kein API-Key · Nutzer zahlt selbst", "No API key · user-pays")}</small></span></button><button className={connectionMode === "api" ? "active" : ""} onClick={() => setConnectionMode("api")}><Icon name="bolt" /><span><strong>{l("Eigene API", "Own API")}</strong><small>{l("Eigener kompatibler Zugang", "Your compatible connection")}</small></span></button></div>
              {connectionMode === "account" ? <div className={`account-status ${cloudSignedIn ? "signed-in" : ""}`}><div><Icon name="shield" /><span><strong>{cloudSignedIn ? cloudUser : "Nicht angemeldet"}</strong><small>Jeder öffentliche Nutzer meldet sich mit seinem eigenen Konto an.</small></span></div>{cloudSignedIn ? <button onClick={signOutOfCloud}>Abmelden</button> : <button onClick={() => void signInToCloud()} disabled={authBusy}>{authBusy ? "Öffnet …" : "Sicher anmelden"}</button>}</div> : <div className="api-settings">
                <label className="settings-field"><span>API-Basis-URL</span><input value={apiBaseUrl} onChange={(event) => setApiBaseUrl(event.target.value)} placeholder="https://api.openai.com/v1" /></label>
                <label className="settings-field"><span>Eigener API-Key · automatische Erkennung</span><input type="password" autoComplete="off" value={apiKey} onChange={(event) => setApiKey(event.target.value)} placeholder="OpenAI, Gemini, Claude, Groq, OpenRouter, xAI …" /></label>
                <div className="api-detection"><div><Icon name="bolt" size={16} /><span><strong>{apiDetectedProvider}</strong><small>{apiCheckStatus || "Anbieter, Basis-URL und /models-Katalog werden nach der Eingabe automatisch geprüft."}</small></span></div><button onClick={() => void detectApiConnection(false)} disabled={!apiKey.trim()}>Jetzt erkennen</button></div>
                <div className="api-profile-grid">{(Object.entries(API_PROFILES) as Array<[ApiProfile, (typeof API_PROFILES)[ApiProfile]]>).map(([id, profile]) => <button key={id} className={apiProfile === id ? "active" : ""} onClick={() => { setApiProfile(id); setApiAutoModel(true); if (id === "supersaver") setMemoryLearningEnabled(false); }}><Icon name={id === "supersaver" ? "shield" : id === "maximum" ? "bolt" : "memory"} size={16} /><span><strong>{profile.label}</strong><small>{profile.note}</small></span></button>)}</div>
                <label className="settings-field"><span>Chat-Modell / Version</span><input list="orion-api-models" value={apiModel} onChange={(event) => { setApiModel(event.target.value); setApiAutoModel(false); }} placeholder="wird automatisch gewählt" /></label><datalist id="orion-api-models">{apiModels.map((model) => <option key={model} value={model} />)}</datalist>
                {!!apiModels.length && <details className="api-model-catalog"><summary>{apiModels.length} verfügbare Modellversionen anzeigen</summary><div>{apiModels.map((model) => <button key={model} onClick={() => { setApiModel(model); setApiAutoModel(false); }} className={apiModel === model ? "active" : ""}>{model}</button>)}</div></details>}
                <label className="checkbox-line"><input type="checkbox" checked={apiAutoModel} onChange={(event) => setApiAutoModel(event.target.checked)} /> Beste Modellversion passend zum Sparprofil automatisch wählen</label>
                <label className="checkbox-line"><input type="checkbox" checked={memoryLearningEnabled} disabled={apiProfile === "supersaver"} onChange={(event) => setMemoryLearningEnabled(event.target.checked)} /> Automatisches Langzeitlernen {apiProfile === "supersaver" ? "(im SuperSparmodus aus)" : ""}</label>
                <label className="checkbox-line"><input type="checkbox" checked={rememberApiKey} onChange={(event) => setRememberApiKey(event.target.checked)} /> Key lokal in diesem Browserprofil merken</label>
                <p className="api-key-fact"><Icon name="shield" size={14} /> Ein Key besitzt technisch keine eigene „Stärke“. ORION liest die freigegebenen Modelle des Anbieters und holt mit Modellwahl, Kontextlimit, Wiederholungsschutz und automatischer Wiederherstellung das Maximum aus dem Zugang.</p>
                <p className="api-warning">Im API-Modus verwendet ORION ausschließlich diese Verbindung und fordert keine Puter-Anmeldung. Der Key wird nie in GitHub, Backups oder einen Betreiber-Server eingebaut. Anbieter können Browserzugriff oder einzelne Modelle trotzdem begrenzen.</p>
              </div>}
            </div>
            <div className="settings-section"><label>{l("Intelligenzstufe", "Intelligence level")}</label><div className="model-grid">{Object.entries(MODELS).map(([key, model]) => <button key={key} className={modelTier === key ? "active" : ""} onClick={() => setModelTier(key as keyof typeof MODELS)}><strong>{model.label}</strong><small>{model.note}</small></button>)}</div></div>
            <div className="settings-section personality-settings">
              <label>{l("Persönlichkeit & Beziehung", "Personality & relationship")}</label>
              <div className="settings-field-grid"><label className="settings-field"><span>{l("Rolle", "Role")}</span><select value={mode} onChange={(event) => setMode(event.target.value)}>{MODES.map((item) => <option key={item.id} value={item.id}>{item.label}</option>)}</select></label><label className="settings-field"><span>{l("ORION-Geschlecht", "ORION gender")}</span><select value={assistantGender} onChange={(event) => { const gender = event.target.value as AssistantGender; setAssistantGender(gender); const voice = VOICE_PROFILES.find((item) => item.gender === gender); if (voice) setVoiceProfile(voice.id); }}><option value="female">{l("Weiblich", "Female")}</option><option value="male">{l("Männlich", "Male")}</option><option value="neutral">Neutral</option></select></label></div>
              <div className="slider-grid"><label><span>{l("Persönlichkeitsstärke", "Personality strength")} <b>{personalityStrength}/4</b></span><input type="range" min="0" max="4" value={personalityStrength} onChange={(event) => setPersonalityStrength(Number(event.target.value))} /></label><label><span>{l("Nähe / Intensität", "Closeness / intensity")} <b>{relationshipCloseness}/4</b></span><input type="range" min="0" max="4" value={relationshipCloseness} onChange={(event) => setRelationshipCloseness(Number(event.target.value))} /></label><label><span>Humor <b>{humorLevel}/4</b></span><input type="range" min="0" max="4" value={humorLevel} onChange={(event) => setHumorLevel(Number(event.target.value))} /></label><label><span>{l("Förmlichkeit", "Formality")} <b>{formalityLevel}/4</b></span><input type="range" min="0" max="4" value={formalityLevel} onChange={(event) => setFormalityLevel(Number(event.target.value))} /></label></div>
              <div className="relationship-level"><span>{relationshipCloseness}</span><div><strong>{RELATIONSHIP_LEVELS[relationshipCloseness]?.label}</strong><small>{RELATIONSHIP_LEVELS[relationshipCloseness]?.note}</small></div><Icon name="shield" size={17} /></div>
              <p>{mode === "friend" && relationshipCloseness >= 4 ? l("Liebevoll, aber kontrolliert: passende Anreden nur gelegentlich – keine Übertreibung, keine Besitzansprüche und keine vorgetäuschte Abhängigkeit.", "Affectionate but controlled: occasional fitting terms only — no exaggeration, possessiveness, or simulated dependency.") : l("Die gewählte Stärke verändert Ton, Nähe, Humor und die Art der Antworten deutlich.", "These controls noticeably change tone, closeness, humor and response style.")}</p>
            </div>
            <div className="settings-section voice-settings">
              <label>{l("Sprache & Stimme", "Language & voice")}</label>
              <div className="settings-field-grid">
                <label className="settings-field"><span>{t("language")}</span><select value={speechLanguage} onChange={(event) => setSpeechLanguage(event.target.value)}>{LANGUAGES.map((language) => <option key={language.id} value={language.id}>{language.label}</option>)}</select></label>
                <label className="settings-field"><span>{l("Sprachqualität", "Voice quality")}</span><select value={voiceEngine} onChange={(event) => setVoiceEngine(event.target.value as VoiceEngine)}><option value="neural">{l("Neural · Nutzerkonto", "Neural · user account")}</option><option value="device">{l("Geräte-Stimme · lokal", "Device voice · local")}</option></select></label>
              </div>
              <div className="voice-grid">{VOICE_PROFILES.map((voice) => <button key={voice.id} className={voiceProfile === voice.id ? "active" : ""} onClick={() => { setVoiceProfile(voice.id); setAssistantGender(voice.gender); }}><strong>{voice.label}</strong><small>{voice.note}</small></button>)}</div>
              <button className="voice-test" onClick={() => speak(VOICE_PREVIEW[speechLanguage] || VOICE_PREVIEW["en-US"])}><Icon name="volume" size={16} /> {t("testVoice")} · “Hello, I am ORION”</button>
              <p>{voiceEngine === "neural" ? "Die hochwertige Neural-Stimme läuft nur über das persönliche Nutzerkonto. Sie verwendet keinen Betreiber-Key und kann niemals Spectrum X berechnet werden." : "Die lokale Geräte-Stimme verursacht keine Online-Nutzung; ihre Qualität hängt vom installierten Sprachpaket des Geräts ab."}</p>
            </div>
            <div className="settings-section radio-settings">
              <label>ORION Radio</label>
              <div className="radio-grid">{RADIO_STATIONS.map((station) => <button key={station.id} className={radioStation === station.id ? "active" : ""} onClick={() => { setRadioStation(station.id); if (radioPlaying) playRadio(station.id); }}><Icon name="radio" size={17} /><span><strong>{station.label}</strong><small>{station.note}</small></span></button>)}</div>
              <button className={`radio-main ${radioPlaying ? "playing" : ""}`} onClick={() => radioPlaying ? stopRadio() : playRadio()}>{radioPlaying ? "Radio stoppen" : "Ausgewählten Sender starten"}</button>
            </div>
            <div className="settings-section personal-settings">
              <label>Persönliche Ansprache</label>
              <div className="settings-field-grid">
                <label className="settings-field"><span>Wie soll ORION dich nennen?</span><input value={preferredName} maxLength={40} onChange={(event) => setPreferredName(event.target.value)} placeholder="Meister" /></label>
                <label className="settings-field"><span>Aktivierungswort</span><input value={wakeWord} maxLength={24} onChange={(event) => setWakeWord(event.target.value)} placeholder="Orion" /></label>
              </div>
            </div>
            <div className="settings-section account-settings">
              <label>Nutzerkonto & Kosten</label>
              <div className="account-status signed-in"><div><Icon name="shield" /><span><strong>{connectionMode === "account" ? cloudSignedIn ? cloudUser : "Persönliche Anmeldung" : "Eigene API"}</strong><small>Der gewählte Zugang gehört immer dem jeweiligen Nutzer, niemals Spectrum X.</small></span></div></div>
              <p>Jeder Nutzer verwendet sein eigenes Konto oder seinen eigenen API-Key. Überschreitet jemand ein Kontingent, kann nur dieser Nutzer selbst ein Upgrade bestätigen. Deine Zahlungsdaten werden in ORION weder abgefragt noch gespeichert.</p>
            </div>
            <div className="settings-section cost-shield-settings">
              <label>Zero-Owner-Cost-Schutz</label>
              <div className="cost-shield-status"><span /><strong>AKTIV · KEIN ZENTRALER API-KEY</strong></div>
              <p>{connectionMode === "api" ? "ORION belastet niemals ein Spectrum-X- oder Entwicklerkonto. Online-KI läuft ausschließlich über die oben eingetragene eigene API; deren Kontingent und mögliche Kosten gehören nur dem jeweiligen Key-Inhaber." : "ORION belastet niemals ein Spectrum-X- oder Entwicklerkonto. Lokale Befehle bleiben kostenlos. Online-KI startet erst nach persönlicher Puter-Anmeldung; Kontingent und mögliche selbst bestätigte Zusatzkosten gehören ausschließlich dem jeweiligen Nutzer."}</p>
            </div>
            <div className="settings-section toggles">
              <label className="toggle-row"><span><strong>Automatische Sprachausgabe</strong><small>Antworten laut vorlesen</small></span><input type="checkbox" checked={autoSpeak} onChange={(event) => setAutoSpeak(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Freihändiges Live-Gespräch</strong><small>Wie ein Anruf: zuhören, antworten und automatisch weiterhören</small></span><input type="checkbox" checked={liveVoice} onChange={(event) => event.target.checked ? startLiveCall() : endLiveCall()} /><i /></label>
              <label className={`toggle-row ${nativeAvailable ? "" : "unavailable"}`}><span><strong>Android-Standbydienst</strong><small>{nativeAvailable ? `Auch bei gesperrtem Bildschirm auf „${wakeWord}“ hören` : "Erfordert den kommenden signierten Native Bridge"}</small></span><input type="checkbox" checked={standbyEnabled} disabled={!nativeAvailable} onChange={(event) => setStandbyEnabled(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Sichere Aktionen</strong><small>Apps öffnen und Inhalte automatisch einfüllen</small></span><input type="checkbox" checked={autoActions} onChange={(event) => setAutoActions(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Live-Web</strong><small>Aktuelle Informationen recherchieren</small></span><input type="checkbox" checked={liveWeb} onChange={(event) => setLiveWeb(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Proaktiver Modus</strong><small>Kontextbezogene Hinweise zulassen</small></span><input type="checkbox" checked={proactive} onChange={(event) => setProactive(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Automatische Fehlerbehebung</strong><small>Prüft Verbindungen und bereinigt festgefahrene Zustände</small></span><input type="checkbox" checked={autoRepair} onChange={(event) => setAutoRepair(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Gamer Performance Mode</strong><small>Kleinere Vision-Frames und schnellere Gaming-Calls</small></span><input type="checkbox" checked={performanceMode} onChange={(event) => setPerformanceMode(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Streamer Mode</strong><small>Creator-Profil und Stream-Copilot aktivieren</small></span><input type="checkbox" checked={streamerMode} onChange={(event) => setStreamerMode(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Bildschirm wach halten</strong><small>Während Vision und Gaming, soweit das Gerät es erlaubt</small></span><input type="checkbox" checked={keepScreenAwake} onChange={(event) => setKeepScreenAwake(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>ORION Crosshair</strong><small>Futuristisches Zielkreuz mittig über der App einblenden</small></span><input type="checkbox" checked={crosshairEnabled} onChange={(event) => setCrosshairEnabled(event.target.checked)} /><i /></label>
              <label className="toggle-row"><span><strong>Lade-Sound</strong><small>Kurzen ORION-Klang abspielen, wenn das Gerät das Laden meldet</small></span><input type="checkbox" checked={chargingSound} onChange={(event) => setChargingSound(event.target.checked)} /><i /></label>
            </div>
            <div className="settings-actions"><button onClick={installApp}><Icon name="install" /> ORION installieren</button><a href="/downloads/ORION-Installationspaket.zip" download><Icon name="install" /> Android/Windows-Baupaket</a><a href="/downloads/ORION-Quellcode-Rohdaten.zip" download><Icon name="copy" /> Rohdaten & Quellcode</a><a href="/downloads/ORION-App-Logo.svg" download><Icon name="spark" /> App-Logo</a><a href="/downloads/ORION-Gamer-Icon.svg" download><Icon name="game" /> Gamer-Icon</a><button onClick={exportData}><Icon name="copy" /> Meine Rohdaten</button><button onClick={clearChat}><Icon name="trash" /> Chat leeren</button></div>
            <div className={`save-all-settings ${settingsSaved ? "saved" : ""}`}><div><Icon name="shield" /><span><strong>{settingsSaved ? l("Alles gespeichert", "Everything saved") : l("Alle Einstellungen & lokalen Daten", "All settings & local data")}</strong><small>{settingsSaved ? l("Sicher in diesem Browserprofil abgelegt", "Stored safely in this browser profile") : l("Speichert Profil, Gedächtnis, Chat, Missionen, Timer und Stream-Chat", "Saves profile, memory, chat, missions, timers, and stream chat")}</small></span></div><button onClick={saveAllSettings}><Icon name={settingsSaved ? "shield" : "install"} /> {settingsSaved ? l("Gespeichert", "Saved") : l("Alles speichern", "Save everything")}</button></div>
            <p className="privacy-note"><Icon name="shield" size={15} /> Kein ChatGPT-Abo und kein ORION-API-Key erforderlich. KI-Nutzung wird niemals Spectrum X berechnet. Anbieter-Freikontingente können begrenzt sein. Absenden, Bestellen, Bezahlen und irreversible Schritte brauchen immer deine letzte Bestätigung.</p>
          </section>
        </div>
      )}

      {aboutOpen && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setAboutOpen(false); }}>
          <section className="modal about-modal" role="dialog" aria-modal="true" aria-label="Über ORION">
            <button className="modal-close" onClick={() => setAboutOpen(false)}><Icon name="close" /></button>
            <div className="about-core"><span /></div><p className="eyebrow">SPECTRUM X PRESENTS</p><h2>ORION</h2><strong>VERSION 1 BETA</strong><p>Dein Leben, dein Assistent, deine Zukunft.</p><small>Entwickelt von Spectrum X · Gründer Baran / Barys</small>
          </section>
        </div>
      )}

      {installHint && (
        <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setInstallHint(false); }}>
          <section className="modal install-modal" role="dialog" aria-modal="true">
            <button className="modal-close" onClick={() => setInstallHint(false)}><Icon name="close" /></button><Icon name="install" size={34} /><h2>ORION installieren</h2>
            <p>{platform === "iOS" ? "Tippe in Safari auf Teilen und anschließend auf „Zum Home-Bildschirm“.": "Öffne das Browser-Menü und wähle „App installieren“ oder „Zum Startbildschirm hinzufügen“."}</p>
            <div className="install-downloads"><a href="/downloads/ORION-Installationspaket.zip" download><Icon name="install" size={16} /><span><strong>Android · Windows · macOS · Linux</strong><small>Baupaket mit automatischen GitHub-Workflows</small></span></a><a href="/downloads/ORION-Quellcode-Rohdaten.zip" download><Icon name="copy" size={16} /><span><strong>Kompletter Quellcode</strong><small>Öffentlich prüfbar · ohne fremden API-Key</small></span></a></div>
          </section>
        </div>
      )}
    </main>
  );
}

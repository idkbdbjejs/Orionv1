# ORION — API-Key-Reparatur

Alle Änderungen betreffen **nur** `app/orion-app.tsx`. Layout, Farben und alles andere bleiben unberührt.

Sieben Stellen. Such jeweils den alten Text, ersetz ihn durch den neuen.

---

## 1 · Erkennungstabelle einfügen

**Suche diese Zeile:**

```
function selectApiModel(models: string[], profile: ApiProfile) {
```

**Setze davor ein:**

```ts
// Anbieter am Schlüssel erkennen.
// Reihenfolge zählt: längere Präfixe zuerst, sonst schluckt "sk-" alles.
// Google vergibt zwei Formate — alt beginnt mit AIza, neu mit AQ.
// Genau das fehlte und ließ Gemini-Schlüssel bei OpenAI landen.
const ANBIETER_MUSTER: Array<{ test: RegExp; base: string; name: string; header?: "x-api-key" }> = [
  { test: /^AQ\./,              base: "https://generativelanguage.googleapis.com/v1beta/openai", name: "Google Gemini" },
  { test: /^AIza/i,             base: "https://generativelanguage.googleapis.com/v1beta/openai", name: "Google Gemini" },
  { test: /^gsk_/i,             base: "https://api.groq.com/openai/v1",        name: "Groq" },
  { test: /^sk-or-/i,           base: "https://openrouter.ai/api/v1",          name: "OpenRouter" },
  { test: /^sk-ant-/i,          base: "https://api.anthropic.com/v1",          name: "Anthropic Claude", header: "x-api-key" },
  { test: /^xai-/i,             base: "https://api.x.ai/v1",                   name: "xAI Grok" },
  { test: /^pplx-/i,            base: "https://api.perplexity.ai",             name: "Perplexity" },
  { test: /^csk-/i,             base: "https://api.cerebras.ai/v1",            name: "Cerebras" },
  { test: /^nvapi-/i,           base: "https://integrate.api.nvidia.com/v1",   name: "NVIDIA NIM" },
  { test: /^hf_/i,              base: "https://router.huggingface.co/v1",      name: "HuggingFace" },
  { test: /^fw_/i,              base: "https://api.fireworks.ai/inference/v1", name: "Fireworks" },
  { test: /^tgp_/i,             base: "https://api.together.xyz/v1",           name: "Together AI" },
  { test: /^glhf_/i,            base: "https://glhf.chat/api/openai/v1",       name: "glhf.chat" },
  { test: /^ms-/i,              base: "https://api.mistral.ai/v1",             name: "Mistral" },
  { test: /^sk-proj-/i,         base: "https://api.openai.com/v1",             name: "OpenAI" },
  { test: /^sk-svcacct-/i,      base: "https://api.openai.com/v1",             name: "OpenAI" },
  { test: /^sk-[a-f0-9]{32}$/i, base: "https://api.deepseek.com/v1",           name: "DeepSeek" },
  { test: /^sk-/i,              base: "https://api.openai.com/v1",             name: "OpenAI" },
];
function ERKENNE_ANBIETER(key: string) {
  const k = (key || "").trim();
  for (const m of ANBIETER_MUSTER) if (m.test.test(k)) return m;
  return null;
}
```

---

## 2 · Ersatzmodelle

**Alt:**

```ts
function selectApiModel(models: string[], profile: ApiProfile) {
  return models
    .filter(isChatModel)
    .map((id, index) => ({ id, index, score: apiModelScore(id, profile) }))
    .sort((a, b) => b.score - a.score || a.index - b.index)[0]?.id || "";
}
```

**Neu:**

```ts
function selectApiModel(models: string[], profile: ApiProfile) {
  const gefiltert = models
    .filter(isChatModel)
    .map((id, index) => ({ id, index, score: apiModelScore(id, profile) }))
    .sort((a, b) => b.score - a.score || a.index - b.index)[0]?.id;
  if (gefiltert) return gefiltert;
  // Kein Modell hat den Chat-Filter bestanden — dann trotzdem etwas nehmen,
  // statt gar nichts. Lieber ein unbekanntes versuchen als blockieren.
  return models[0] || "";
}

// Verlangt eine Funktion etwas Bestimmtes, das der Zugang nicht hat,
// wird das nächstbeste genommen statt abzubrechen.
function passendesModell(models: string[], zweck: "chat" | "bild" | "ton" | "schnell", aktuell: string) {
  if (!models.length) return aktuell;
  const passt = (re: RegExp) => models.find((m) => re.test(m));
  if (zweck === "bild") return passt(/image|imagen|dall-?e|flux|sd3|stable-?diffusion/i) || "";
  if (zweck === "ton") return passt(/tts|audio|speech|voice/i) || "";
  if (zweck === "schnell") return passt(/flash-?lite|mini|haiku|small|8b|turbo|fast/i) || aktuell || models[0];
  return aktuell && models.includes(aktuell) ? aktuell : (selectApiModel(models, "balanced") || models[0]);
}
```

---

## 3 · Schlüssel schaltet auf API-Modus

**Alt:**

```ts
    if (key !== apiKey) setApiKey(key);
```

**Neu:**

```ts
    if (key !== apiKey) setApiKey(key);
    // Wer einen Schlüssel einträgt, will ihn auch benutzen.
    if (connectionMode !== "api") setConnectionMode("api");
```

---

## 4 · Alte Erkennung ersetzen

**Alt:**

```ts
    const lowerKey = key.toLowerCase();
    if (/^gsk_/.test(lowerKey)) base = "https://api.groq.com/openai/v1";
    else if (/^sk-or-/.test(lowerKey)) base = "https://openrouter.ai/api/v1";
    else if (/^xai-/.test(lowerKey)) base = "https://api.x.ai/v1";
    else if (/^sk-ant-/.test(lowerKey)) base = "https://api.anthropic.com/v1";
    else if (/^aiza/.test(lowerKey)) base = "https://generativelanguage.googleapis.com/v1beta/openai";
    if (base !== apiBaseUrl.trim()) setApiBaseUrl(base);
```

**Neu:**

```ts
    const erkannt = ERKENNE_ANBIETER(key);
    if (erkannt) base = erkannt.base;
    if (base !== apiBaseUrl.trim()) setApiBaseUrl(base);
```

---

## 5 · Anbietername aus der Tabelle

**Alt** — Zeilenanfang:

```ts
    const provider = host.includes("openrouter") ? "OpenRouter"
```

**Neu:**

```ts
    const provider = erkannt?.name || (host.includes("openrouter") ? "OpenRouter"
```

**Und am Ende derselben Zeile — alt:**

```ts
 : host.includes("openai") ? "OpenAI" : "OpenAI-kompatibler Anbieter";
```

**Neu** (eine Klammer mehr am Schluss):

```ts
 : host.includes("openai") ? "OpenAI" : "OpenAI-kompatibler Anbieter");
```

---

## 6 · Anthropic-Kopfzeilen

**Alt:**

```ts
      const response = await fetch(endpoint, { headers: { Authorization: `Bearer ${key}` } });
```

**Neu:**

```ts
      // Anthropic verlangt x-api-key statt Bearer und einen Zusatz, der den
      // Zugriff direkt aus dem Browser erlaubt. Ohne beides scheitert es immer.
      const kopf: Record<string, string> = erkannt?.header === "x-api-key"
        ? { "x-api-key": key, "anthropic-version": "2023-06-01", "anthropic-dangerous-direct-browser-access": "true" }
        : { Authorization: `Bearer ${key}` };
      const response = await fetch(endpoint, { headers: kopf });
```

**Dazu:** In der Zeile darunter beginnend mit `}, [apiAutoModel, apiBaseUrl, apiKey, apiModel, apiProfile]);` am Ende noch `connectionMode` ergänzen:

```ts
  }, [apiAutoModel, apiBaseUrl, apiKey, apiModel, apiProfile, connectionMode]);
```

---

## 7 · Anmeldepflicht lockern

**Alt:**

```ts
      const puterClient = await import("@heyputer/puter.js");
      if (!puterClient.puter.auth.isSignedIn()) {
        setAiState("ready");
        setLiveVoice(false);
        setLivePanelOpen(false);
        addAssistantMessage("Online-KI ist gesperrt, bis du dich mit deinem eigenen Puter-Konto anmeldest. So kann deine Nutzung niemals über Baran oder Spectrum X abgerechnet werden.");
        return;
      }
```

**Neu:**

```ts
      const puterClient = await import("@heyputer/puter.js");
      if (!puterClient.puter.auth.isSignedIn()) {
        setAiState("ready");
        setLiveVoice(false);
        setLivePanelOpen(false);
        // Liegt ein eigener Schlüssel vor, ist keine Anmeldung nötig — dann
        // wird ohnehin über den eigenen Zugang abgerechnet.
        if (apiKey.trim().length > 8) {
          addAssistantMessage("Dein eigener Schlüssel ist hinterlegt — ich stelle auf „Eigene API“ um. Keine Anmeldung nötig.");
          setConnectionMode("api");
          return;
        }
        addAssistantMessage("Für die Online-KI brauchst du entweder einen eigenen API-Schlüssel (Einstellungen → Eigene API) oder eine Puter-Anmeldung. So läuft deine Nutzung niemals über Baran oder Spectrum X.");
        return;
      }
```

---

## Was danach funktioniert

| Schlüssel beginnt mit | Erkannt als |
|---|---|
| `AQ.` | Google Gemini — **das war dein Fehler** |
| `AIza` | Google Gemini |
| `sk-proj-` · `sk-svcacct-` · `sk-` | OpenAI |
| `gsk_` | Groq |
| `sk-or-` | OpenRouter |
| `sk-ant-` | Anthropic Claude |
| `xai-` | xAI Grok |
| `pplx-` | Perplexity |
| `csk-` | Cerebras |
| `nvapi-` | NVIDIA NIM |
| `hf_` | HuggingFace |
| `fw_` | Fireworks |
| `tgp_` | Together AI |
| `glhf_` | glhf.chat |
| `ms-` | Mistral |
| `sk-` + 32 Hex-Zeichen | DeepSeek |

**Ersatzmodelle** — verlangt eine Funktion GPT-4o und du hast nur Gemini:

| Gebraucht | Du hast Gemini | Du hast Groq |
|---|---|---|
| Chat | `gemini-3.5-flash` | `llama-3.3-70b-versatile` |
| Schnell | `gemini-3.5-flash` | `llama-3.1-8b-instant` |
| Bild | `gemini-2.5-flash-image` | keins — Funktion aus |

---

## Weitere Fehler, die noch kommen können

**„/models konnte im Browser nicht gelesen werden"** bei manchen Anbietern. Das ist CORS — der Anbieter erlaubt keine Browser-Anfragen. Das Chatten geht meist trotzdem, nur die Modell-Liste bleibt leer. Trage dann den Modellnamen von Hand ein.

Zuverlässig im Browser: **Groq, OpenRouter, Gemini**. Problematisch: OpenAI direkt, Mistral.

**„Incorrect API key provided"** bei richtigem Schlüssel heißt jetzt: Der Schlüssel wurde dem falschen Anbieter zugeordnet. Prüfe, ob die Basis-URL zu deinem Schlüssel passt.

**Kontingent leer (429)** kommt bei Gemini schnell. Ein zweiter Schlüssel aus einem anderen Google-Projekt verdoppelt es.
